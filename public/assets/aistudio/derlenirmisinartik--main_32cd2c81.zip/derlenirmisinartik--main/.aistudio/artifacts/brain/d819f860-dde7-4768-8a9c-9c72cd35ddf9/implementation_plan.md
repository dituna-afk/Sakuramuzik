# Application Enhancement Plan: Performance, Anime Artwork & Typography

## Overview
Based on your feedback, we will optimize performance, generate custom high-quality AI visual artworks for all anime themes, and ensure custom anime typography is seamlessly applied across all headings, song titles, and player components.

---

## Key Objectives

### 1. Performance Optimization
- **Particle Animation Guard**: Restrict floating petal particle rendering in `SakuraBlossomCanvas.kt` and `HomeScreen.kt` strictly to Sakura themes (`SAKURA_LIGHT` & `SAKURA_DARK`).
- **Complete Bypass for Anime Themes**: For all anime themes (Evangelion, Berserk, Chainsaw Man, Cowboy Bebop), completely disable canvas particle drawing to eliminate GPU/CPU overhead and lag.

### 2. High-Quality AI Anime Artwork Generation
Using AI Image Generation (`generate_image`), we will create custom visual assets for each theme:
- **Evangelion (EVA-01)**: Futuristic mecha cyberpunk synthwave aesthetic (purple, neon green, orange glow).
- **Berserk Guts**: Dark fantasy artwork with Dragonslayer blade and eclipse crimson shadows.
- **Berserk Griffith**: Majestic White Hawk aesthetic with ethereal silver and crimson eclipse mood.
- **Chainsaw Man**: High-octane vibrant anime artwork with Pochita/chainsaw neon yellow-orange accents.
- **Cowboy Bebop Faye**: Retro 90s anime space synthwave lounge vibe (violet, gold, jazz aesthetic).
- **Cowboy Bebop Spike**: Retro 90s anime noir jazz aesthetic (deep indigo, magenta, space cowboy style).
- **Sakura Themes**: Aesthetic cherry blossom night and daylight anime music art.

All assets will be integrated into `AnimeArtRegistry.kt` and updated across `HomeScreen.kt`, `PlayerScreen.kt`, `MiniPlayer`, and `SettingsScreen.kt`.

### 3. Global Theme Typography
- Update `AnimeTypography.kt` and Composable text styles so that when anime fonts are enabled, the designated font (`Oswald`, `Cinzel`, `Bangers`, `Righteous`) is applied universally to:
  - Song titles in track lists, player screens, mini-player, top played cards, and search items.
  - Screen titles, tab titles, and dialog headers.

---

## Verification Plan
1. Generate all required AI image assets.
2. Update Kotlin theme, rendering, and typography files.
3. Verify compilation using `compile_applet`.
