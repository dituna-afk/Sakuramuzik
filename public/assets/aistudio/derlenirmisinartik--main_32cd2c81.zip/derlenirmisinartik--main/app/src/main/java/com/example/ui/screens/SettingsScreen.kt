package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import com.example.downloader.DownloadFormatOption
import com.example.downloader.LikedSongsSourceType
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AppIconOption
import com.example.data.EffectIntensityLevel
import com.example.data.FeatureTogglesConfig
import com.example.data.NowPlayingSceneMode
import com.example.data.PetalDensityLevel
import com.example.data.SakuraAnimationConfig
import com.example.data.SakuraAnimationProfile
import com.example.data.SakuraTreeForm
import com.example.data.SakuraTreeStyle
import com.example.data.TransitionSpeedLevel
import com.example.downloader.TranslationEngine
import com.example.player.StudioDspConfig
import com.example.ui.player.StudioDspDialog
import com.example.ui.theme.AppTheme
import com.example.ui.theme.LocalAppThemePalette
import com.example.ui.theme.toPalette

@Composable
fun SettingsScreen(
    selectedTheme: AppTheme,
    selectedTreeStyle: SakuraTreeStyle,
    selectedTreeForm: SakuraTreeForm,
    animationConfig: SakuraAnimationConfig,
    youtubeDLVersion: String,
    isYtdlpEngineReady: Boolean,
    isFFmpegReady: Boolean,
    isAria2cReady: Boolean,
    isUpdatingYoutubeDL: Boolean,
    autoTranslateLyricsToTurkish: Boolean,
    translationEngine: TranslationEngine = TranslationEngine.GOOGLE_TRANSLATE,
    selectedAppIcon: AppIconOption = AppIconOption.DEFAULT,
    volumeBoostPercent: Int = 100,
    isVolumeBoosterEnabled: Boolean = false,
    featureToggles: FeatureTogglesConfig = FeatureTogglesConfig(),
    studioDspConfig: StudioDspConfig = StudioDspConfig(),
    onUpdateFeatureToggles: ((FeatureTogglesConfig) -> FeatureTogglesConfig) -> Unit = {},
    onUpdateStudioDspConfig: ((StudioDspConfig) -> StudioDspConfig) -> Unit = {},
    onSelectTheme: (AppTheme) -> Unit,
    onSelectTreeStyle: (SakuraTreeStyle) -> Unit,
    onSelectTreeForm: (SakuraTreeForm) -> Unit,
    onSelectAppIcon: (AppIconOption) -> Unit = {},
    selectedDownloadFormat: DownloadFormatOption = DownloadFormatOption.AUDIO_M4A_HIGH,
    onSelectDownloadFormat: (DownloadFormatOption) -> Unit = {},
    onDownloadAccountLibraryWithCookies: (LikedSongsSourceType) -> Unit = {},
    onSelectAnimationProfile: (SakuraAnimationProfile) -> Unit,
    onSetAnimationsMasterEnabled: (Boolean) -> Unit,
    onSelectPetalDensity: (PetalDensityLevel) -> Unit,
    onSelectTransitionSpeed: (TransitionSpeedLevel) -> Unit,
    onSelectEffectIntensity: (EffectIntensityLevel) -> Unit,
    onSetFloatingPetalsEnabled: (Boolean) -> Unit,
    onSetAudioReactiveWavesEnabled: (Boolean) -> Unit,
    onSetInteractiveBurstEnabled: (Boolean) -> Unit,
    onSetScreenTransitionsEnabled: (Boolean) -> Unit,
    onSetPowerSaveAutoReduce: (Boolean) -> Unit,
    onSetAutoTranslateLyricsToTurkish: (Boolean) -> Unit,
    onSelectTranslationEngine: (TranslationEngine) -> Unit,
    onSetVolumeBoost: (Int, Boolean) -> Unit = { _, _ -> },
    onUpdateYoutubeDL: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalAppThemePalette.current
    var showStudioDspDialog by remember { mutableStateOf(false) }

    // Tüm kategori sekmeleri varsayılan olarak kapalıdır (0ms yükleme & maksimum akıcılık).
    // Tıklayınca açılır, tekrar tıklayınca kapanır.
    val expandedSections = remember { mutableStateMapOf<String, Boolean>() }
    fun isExpanded(key: String): Boolean = expandedSections[key] == true
    fun toggleSection(key: String) {
        expandedSections[key] = !(expandedSections[key] ?: false)
    }

    if (showStudioDspDialog) {
        StudioDspDialog(
            dspConfig = studioDspConfig,
            featureToggles = featureToggles,
            onUpdateDspConfig = onUpdateStudioDspConfig,
            onUpdateFeatureToggles = onUpdateFeatureToggles,
            onDismiss = { showStudioDspDialog = false }
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Üst Başlık ve Sürüm Bilgisi
        item(key = "settings_header") {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Sakura Ayarlar & Sekmeler",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.onBackground
                        )
                        Text(
                            text = "İstediğiniz sekmeye dokunarak açın, işiniz bitince tekrar dokunarak kapatın",
                            fontSize = 11.sp,
                            color = palette.onSurfaceMuted
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(palette.primaryAccent.copy(alpha = 0.18f))
                            .border(1.dp, palette.primaryAccent, RoundedCornerShape(10.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "v2.7.0 (Build 7 • 60 FPS)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.primaryAccent
                        )
                    }
                }

                if (expandedSections.values.any { it }) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { expandedSections.clear() },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Açık Tüm Sekmeleri Kapat",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = palette.primaryAccent
                            )
                        }
                    }
                }
            }
        }

        // SEKME 1: Oynatıcı Şarkı Kapağı Sahneleri & Görsel Özellikler
        item(key = "sec_player_visuals") {
            ExpandableSettingsSection(
                title = "1. Şarkı Kapağı Sahneleri & Oynatıcı Özellikleri",
                subtitle = "Varsayılan: Sade Kapak • Sakura Ağacı, Zen Nilüfer, Japon Feneri & Kısayollar",
                icon = Icons.Default.Album,
                expanded = isExpanded("player_visuals"),
                onToggle = { toggleSection("player_visuals") },
                testTag = "section_player_visuals"
            ) {
                SettingToggleItem(
                    label = "Şarkıya Göre Dinamik Renk Değişimi (Aç / Kapa)",
                    checked = featureToggles.dynamicCoverPaletteEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(dynamicCoverPaletteEnabled = enabled) }
                    }
                )

                Text(
                    text = "Not: Kapalıyken seçtiğiniz Sakura teması ve ağaç rengi sabit kalır, şarkı geçişlerinde ekstra renk hesaplaması yapılmaz.",
                    fontSize = 11.sp,
                    color = palette.onSurfaceMuted
                )

                SettingToggleItem(
                    label = "Şarkı Kapağı Yanı / Arkası Görsel Sahneleri (Aç / Kapa)",
                    checked = featureToggles.playerScenesEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(playerScenesEnabled = enabled) }
                    }
                )

                if (featureToggles.playerScenesEnabled) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(palette.surface.copy(alpha = 0.75f))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "Tam Ekran Şarkı Kapağı Sahnesi Seçin (Varsayılan: Yok / Sade):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.primaryAccent
                        )
                        NowPlayingSceneMode.entries.forEach { scene ->
                            val isSelected = featureToggles.selectedPlayerScene == scene
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        if (isSelected) palette.primaryAccent.copy(alpha = 0.18f)
                                        else palette.surfaceContainer
                                    )
                                    .border(
                                        width = if (isSelected) 1.5.dp else 1.dp,
                                        color = if (isSelected) palette.primaryAccent else palette.dividerOrBorder,
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                    .clickable {
                                        onUpdateFeatureToggles { it.copy(selectedPlayerScene = scene) }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = scene.displayName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = palette.onSurface
                                    )
                                    Text(
                                        text = scene.description,
                                        fontSize = 10.sp,
                                        color = palette.onSurfaceMuted
                                    )
                                }
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Seçili",
                                        tint = palette.primaryAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                SettingToggleItem(
                    label = "Dokunmada Kiraz Çiçeği Çıkma Efekti (Aç / Kapa)",
                    checked = animationConfig.interactiveBurstEnabled,
                    onCheckedChange = onSetInteractiveBurstEnabled
                )

                SettingToggleItem(
                    label = "İnteraktif Canlı Ses Dalgası Çubuğu (Waveform Seekbar)",
                    checked = featureToggles.waveformSeekbarEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(waveformSeekbarEnabled = enabled) }
                    }
                )

                SettingToggleItem(
                    label = "Şarkı Kapağına Çift Dokunarak ±10 Sn İleri/Geri Sarma",
                    checked = featureToggles.doubleTapSeekEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(doubleTapSeekEnabled = enabled) }
                    }
                )

                SettingToggleItem(
                    label = "A-B Nakarat Döngüsü (Bölüm Tekrarlama Modülü)",
                    checked = featureToggles.abLoopEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(abLoopEnabled = enabled) }
                    }
                )
            }
        }

        // SEKME 2: Sakura Renk Temaları & Ağaç Tasarımı
        item(key = "sec_themes_and_tree") {
            ExpandableSettingsSection(
                title = "2. Sakura Renk Temaları & Ağaç Tasarımı",
                subtitle = "Seçili Tema: ${selectedTheme.displayName} • Ağaç: ${selectedTreeStyle.displayName}",
                icon = Icons.Default.Palette,
                expanded = isExpanded("themes_and_tree"),
                onToggle = { toggleSection("themes_and_tree") },
                testTag = "section_themes_and_tree"
            ) {
                SettingToggleItem(
                    label = "Şarkıya Göre Dinamik Renk Değişimi (Aç / Kapa)",
                    checked = featureToggles.dynamicCoverPaletteEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(dynamicCoverPaletteEnabled = enabled) }
                    }
                )

                SettingToggleItem(
                    label = "🖼️ Anime Karakter Duvar Kağıtları & Posterler",
                    checked = featureToggles.animeArtworkBackgroundEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(animeArtworkBackgroundEnabled = enabled) }
                    }
                )
                Text(
                    text = "Açıkken ana ekranda ve oynatıcıda seçili animeye (Berserk Guts, Griffith, Evangelion, Cowboy Bebop) ait sanatsal karakter posterleri gösterilir.",
                    fontSize = 11.sp,
                    color = palette.onSurfaceMuted
                )

                SettingToggleItem(
                    label = "𔐬 Temaya Özel Anime Yazı Tipleri (Evangelion Oswald, Berserk Cinzel)",
                    checked = featureToggles.animeThemeFontsEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(animeThemeFontsEnabled = enabled) }
                    }
                )
                Text(
                    text = "Açıkken Evangelion için 'Oswald', Berserk için 'Cinzel', Chainsaw Man için 'Bangers' ve Cowboy Bebop için 'Righteous' özel font stilleri uygulanır.",
                    fontSize = 11.sp,
                    color = palette.onSurfaceMuted
                )

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Uygulama Teması & Anime Karakter Renkleri:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.primaryAccent
                )

                AppTheme.entries.forEach { theme ->
                    val themePalette = theme.toPalette()
                    val isSelected = theme == selectedTheme
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) palette.primaryAccent.copy(alpha = 0.16f) else palette.surface)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) palette.primaryAccent else palette.dividerOrBorder,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { onSelectTheme(theme) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val animeMeta = remember(theme) { com.example.ui.theme.AnimeArtRegistry.getMetadata(theme) }
                        if (animeMeta?.primaryAssetPath != null) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(1.5.dp, themePalette.primaryAccent, RoundedCornerShape(10.dp))
                            ) {
                                AsyncImage(
                                    model = animeMeta.primaryAssetPath,
                                    contentDescription = animeMeta.characterName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        } else {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(themePalette.background)
                                        .border(1.dp, themePalette.primaryAccent, CircleShape)
                                )
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(themePalette.primaryAccent)
                                )
                                Box(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(themePalette.petalPrimary)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = theme.displayName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = palette.onSurface
                            )
                            Text(
                                text = theme.subtitle,
                                fontSize = 11.sp,
                                color = palette.onSurfaceMuted
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Seçili",
                                tint = palette.primaryAccent
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Sakura Ağacı Özel Renk Stili:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.primaryAccent
                )
                Text(
                    text = "Varsayılan 'Temayla Uyumlu Sakura' seçiliyken ağacın çiçekleri aktif temanın rengini alır.",
                    fontSize = 11.sp,
                    color = palette.onSurfaceMuted
                )

                SakuraTreeStyle.entries.forEach { style ->
                    val isSelected = style == selectedTreeStyle
                    val previewPrimary = if (style == SakuraTreeStyle.TRADITIONAL_SAKURA) palette.petalPrimary else style.petalPrimary
                    val previewSecondary = if (style == SakuraTreeStyle.TRADITIONAL_SAKURA) palette.petalSecondary else style.petalSecondary
                    val previewAccent = if (style == SakuraTreeStyle.TRADITIONAL_SAKURA) palette.primaryAccent else style.primaryAccent

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) palette.primaryAccent.copy(alpha = 0.16f) else palette.surface)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) palette.primaryAccent else palette.dividerOrBorder,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { onSelectTreeStyle(style) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(previewPrimary)
                                    .border(1.dp, style.barkMidColor, CircleShape)
                            )
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(previewSecondary)
                            )
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .clip(CircleShape)
                                    .background(previewAccent)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = style.displayName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = palette.onSurface
                            )
                            Text(
                                text = style.description,
                                fontSize = 11.sp,
                                color = palette.onSurfaceMuted
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Seçili",
                                tint = palette.primaryAccent
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Sakura Ağaç Formu (Gövde & Dal Çizim Mimarisi):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.primaryAccent
                )

                SakuraTreeForm.entries.forEach { form ->
                    val isSelected = form == selectedTreeForm
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(if (isSelected) palette.primaryAccent.copy(alpha = 0.16f) else palette.surface)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) palette.primaryAccent else palette.dividerOrBorder,
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable { onSelectTreeForm(form) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = form.displayName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = palette.onSurface
                            )
                            Text(
                                text = form.description,
                                fontSize = 11.sp,
                                color = palette.onSurfaceMuted
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Seçili",
                                tint = palette.primaryAccent
                            )
                        }
                    }
                }
            }
        }

        // SEKME 3: Stüdyo & DSP Ses Efekt Modülleri
        item(key = "sec_studio_dsp") {
            ExpandableSettingsSection(
                title = "3. Stüdyo & DSP Ses Efekt Modülleri",
                subtitle = "5-Bant Ekolayzer, Slowed+Reverb, 8D Uzamsal Ses, Vokal Azaltıcı & Ambiyans",
                icon = Icons.Default.GraphicEq,
                expanded = isExpanded("studio_dsp"),
                onToggle = { toggleSection("studio_dsp") },
                testTag = "section_studio_dsp"
            ) {
                SettingToggleItem(
                    label = "5-Bant Grafik Ekolayzer & Bass Boost Modülü",
                    checked = featureToggles.equalizerEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(equalizerEnabled = enabled) }
                    }
                )
                if (featureToggles.equalizerEnabled) {
                    SettingToggleItem(
                        label = "   ↳ Ekolayzer & Bass Boost Efektini Aktif Et (${studioDspConfig.eqPresetName})",
                        checked = studioDspConfig.isEqualizerActive,
                        onCheckedChange = { active ->
                            onUpdateStudioDspConfig { it.copy(isEqualizerActive = active) }
                        }
                    )
                }

                SettingToggleItem(
                    label = "Slowed + Reverb & Nightcore (Pitch/Tempo Modülü)",
                    checked = featureToggles.pitchAndReverbEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(pitchAndReverbEnabled = enabled) }
                    }
                )
                if (featureToggles.pitchAndReverbEnabled) {
                    SettingToggleItem(
                        label = "   ↳ Slowed + Reverb / Nightcore Efektini Aktif Et (${studioDspConfig.pitchReverbPreset})",
                        checked = studioDspConfig.isPitchReverbActive,
                        onCheckedChange = { active ->
                            onUpdateStudioDspConfig { it.copy(isPitchReverbActive = active) }
                        }
                    )
                }

                SettingToggleItem(
                    label = "8D / 360° Uzamsal Ses (Spatial Panning Modülü)",
                    checked = featureToggles.spatial8DAudioEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(spatial8DAudioEnabled = enabled) }
                    }
                )
                if (featureToggles.spatial8DAudioEnabled) {
                    SettingToggleItem(
                        label = "   ↳ 8D 360° Dönen Sahne Efektini Aktif Et",
                        checked = studioDspConfig.isSpatial8DActive,
                        onCheckedChange = { active ->
                            onUpdateStudioDspConfig { it.copy(isSpatial8DActive = active) }
                        }
                    )
                }

                SettingToggleItem(
                    label = "Karaoke / Vokal Azaltıcı Mod (Enstrümantal Odak Modülü)",
                    checked = featureToggles.vocalReducerEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(vocalReducerEnabled = enabled) }
                    }
                )
                if (featureToggles.vocalReducerEnabled) {
                    SettingToggleItem(
                        label = "   ↳ Karaoke / Vokal Baskılama Efektini Aktif Et (%${studioDspConfig.vocalReductionPercent})",
                        checked = studioDspConfig.isVocalReducerActive,
                        onCheckedChange = { active ->
                            onUpdateStudioDspConfig { it.copy(isVocalReducerActive = active) }
                        }
                    )
                }

                SettingToggleItem(
                    label = "Arka Plan Ambiyans & Plak Çıtırtısı Mikseri Modülü",
                    checked = featureToggles.ambientMixerEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(ambientMixerEnabled = enabled) }
                    }
                )
                if (featureToggles.ambientMixerEnabled) {
                    SettingToggleItem(
                        label = "   ↳ Arka Plan Yağmur / Plak Çıtırtısı Mikserini Aktif Et",
                        checked = studioDspConfig.isAmbientMixerActive,
                        onCheckedChange = { active ->
                            onUpdateStudioDspConfig { it.copy(isAmbientMixerActive = active) }
                        }
                    )
                }

                Button(
                    onClick = { showStudioDspDialog = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.GraphicEq, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Stüdyo FX & Detaylı DSP Kontrol Panelini Aç", fontWeight = FontWeight.Bold)
                }
            }
        }

        // SEKME 4: Şarkı Ses Seviyesi Yükseltici (+20 dB Gain)
        item(key = "sec_volume_booster") {
            ExpandableSettingsSection(
                title = "4. Şarkı Ses Seviyesi Yükseltici (+20 dB)",
                subtitle = if (isVolumeBoosterEnabled) "Aktif: %$volumeBoostPercent Amplifikasyon" else "Kapalı (%100 Standart Ses)",
                icon = Icons.Default.VolumeUp,
                expanded = isExpanded("volume_booster"),
                onToggle = { toggleSection("volume_booster") },
                testTag = "section_volume_booster"
            ) {
                Text(
                    text = "Kulaklık ve hoparlörlerde ses seviyesini standart %100 sınırının %300 üzerine kadar donanım DSP + yazılım ön-kazanç (pre-gain) ile yükseltir.",
                    fontSize = 12.sp,
                    color = palette.onSurfaceMuted
                )

                SettingToggleItem(
                    label = "Ses Yükselticiyi Etkinleştir",
                    checked = isVolumeBoosterEnabled,
                    onCheckedChange = { enabled ->
                        onSetVolumeBoost(volumeBoostPercent, enabled)
                    }
                )

                if (isVolumeBoosterEnabled) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Amplifikasyon Seviyesi:",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = palette.onSurface
                        )
                        Text(
                            text = "%$volumeBoostPercent (+${(volumeBoostPercent - 100) / 10} dB)",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.primaryAccent
                        )
                    }

                    Slider(
                        value = volumeBoostPercent.toFloat(),
                        onValueChange = { newPct ->
                            onSetVolumeBoost(newPct.toInt(), true)
                        },
                        valueRange = 100f..300f,
                        steps = 19,
                        colors = SliderDefaults.colors(
                            thumbColor = palette.primaryAccent,
                            activeTrackColor = palette.primaryAccent,
                            inactiveTrackColor = palette.surfaceVariant
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf(100, 150, 200, 250, 300).forEach { preset ->
                            val isSelected = volumeBoostPercent == preset
                            Button(
                                onClick = { onSetVolumeBoost(preset, true) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) palette.primaryAccent else palette.surface,
                                    contentColor = if (isSelected) palette.onPrimary else palette.onSurface
                                ),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier.height(32.dp)
                            ) {
                                Text("%$preset", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // SEKME 5: Akıllı Kütüphane, İstatistik & Paylaşım Araçları
        item(key = "sec_library_tools") {
            ExpandableSettingsSection(
                title = "5. Akıllı Kütüphane & Paylaşım Araçları",
                subtitle = "Söz Kartı, ID3 Etiket Düzenleyici, Kütüphane Doktoru, İstatistik & Auto-Play",
                icon = Icons.Default.LibraryMusic,
                expanded = isExpanded("library_tools"),
                onToggle = { toggleSection("library_tools") },
                testTag = "section_library_tools"
            ) {
                SettingToggleItem(
                    label = "Şarkı Sözü Kartı Oluşturucu (Lyric Card Tasarımcısı)",
                    checked = featureToggles.lyricCardGeneratorEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(lyricCardGeneratorEnabled = enabled) }
                    }
                )

                SettingToggleItem(
                    label = "Çevrimdışı ID3 Etiket & Kapak Düzenleyici",
                    checked = featureToggles.tagEditorEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(tagEditorEnabled = enabled) }
                    }
                )

                SettingToggleItem(
                    label = "Kütüphane Doktoru (Kopya & Bozuk Dosya Temizleyici)",
                    checked = featureToggles.libraryDoctorEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(libraryDoctorEnabled = enabled) }
                    }
                )

                SettingToggleItem(
                    label = "Akıllı Otomatik Sıradaki Şarkı (Smart Auto-Play)",
                    checked = featureToggles.smartAutoplayEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(smartAutoplayEnabled = enabled) }
                    }
                )

                SettingToggleItem(
                    label = "Müzik Dinleme İstatistikleri & Özet (Wrapped)",
                    checked = featureToggles.musicStatsEnabled,
                    onCheckedChange = { enabled ->
                        onUpdateFeatureToggles { it.copy(musicStatsEnabled = enabled) }
                    }
                )
            }
        }

        // SEKME 6: Sakura Animasyon & Dokunuş Efektleri
        item(key = "sec_animations") {
            val touchBurstStatusText = if (animationConfig.interactiveBurstEnabled) "Açık" else "Kapalı"
            ExpandableSettingsSection(
                title = "6. Sakura Animasyon & Dokunuş Sistemi",
                subtitle = if (animationConfig.masterEnabled) {
                    "${animationConfig.profile.displayName} • Dokunma Çiçekleri: $touchBurstStatusText"
                } else "Tüm Efektler Kapalı",
                icon = Icons.Default.AutoAwesome,
                expanded = isExpanded("animations"),
                onToggle = { toggleSection("animations") },
                testTag = "section_animations"
            ) {
                SettingToggleItem(
                    label = "Tüm Sakura Animasyonlarını Etkinleştir (Ana Şalter)",
                    checked = animationConfig.masterEnabled,
                    onCheckedChange = onSetAnimationsMasterEnabled
                )

                // Kullanıcının özel istediği: Dokunmada çıkan çiçekleri kapatma/açma ayarı
                SettingToggleItem(
                    label = "Dokunmada Kiraz Çiçeği Açma (Touch Burst)",
                    checked = animationConfig.interactiveBurstEnabled,
                    onCheckedChange = onSetInteractiveBurstEnabled
                )
                Text(
                    text = "Ekrana dokunulduğunda parmak ucundan kiraz çiçeği parçacıkları fışkırtır. Kapatıldığında dokunmatik gecikmesi sıfırlanır ve tüm sekmeler maksimum akıcılıkta çalışır.",
                    fontSize = 11.sp,
                    color = palette.onSurfaceMuted,
                    modifier = Modifier.padding(start = 12.dp, bottom = 8.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    SakuraAnimationProfile.entries.forEach { profile ->
                        FilterChip(
                            selected = animationConfig.profile == profile,
                            onClick = { onSelectAnimationProfile(profile) },
                            label = { Text(profile.displayName) }
                        )
                    }
                }

                Text("Yaprak Yoğunluğu", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = palette.onSurface)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    PetalDensityLevel.entries.forEach { d ->
                        FilterChip(
                            selected = animationConfig.petalDensity == d,
                            onClick = { onSelectPetalDensity(d) },
                            label = { Text(d.displayName) }
                        )
                    }
                }

                Text("Geçiş Hızı", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = palette.onSurface)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    TransitionSpeedLevel.entries.forEach { s ->
                        FilterChip(
                            selected = animationConfig.transitionSpeed == s,
                            onClick = { onSelectTransitionSpeed(s) },
                            label = { Text(s.displayName) }
                        )
                    }
                }

                Text("Efekt Şiddeti", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = palette.onSurface)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    EffectIntensityLevel.entries.forEach { i ->
                        FilterChip(
                            selected = animationConfig.effectIntensity == i,
                            onClick = { onSelectEffectIntensity(i) },
                            label = { Text(i.displayName) }
                        )
                    }
                }

                SettingToggleItem("Süzülen Kiraz Çiçeği Yaprakları", animationConfig.floatingPetalsEnabled, onSetFloatingPetalsEnabled)
                SettingToggleItem("Ses Reaktif Halo & Ritim Dalgaları", animationConfig.audioReactiveWavesEnabled, onSetAudioReactiveWavesEnabled)
                SettingToggleItem("Akıcı Ekran Geçiş Animasyonları", animationConfig.screenTransitionsEnabled, onSetScreenTransitionsEnabled)
                SettingToggleItem("Pil Tasarrufunda Otomatik Azalt", animationConfig.powerSaveAutoReduce, onSetPowerSaveAutoReduce)
            }
        }

        // SEKME 7: Şarkı Sözü & Türkçe Çeviri Motoru
        item(key = "sec_translation") {
            ExpandableSettingsSection(
                title = "7. Şarkı Sözü & Türkçe Çeviri Motoru",
                subtitle = "Çeviri Servisi: ${translationEngine.displayName}",
                icon = Icons.Default.Translate,
                expanded = isExpanded("translation"),
                onToggle = { toggleSection("translation") },
                testTag = "section_translation"
            ) {
                Text(
                    text = "Yabancı dildeki şarkı sözlerini (İngilizce, Japonca, Korece, Almanca vb.) otomatik olarak Türkçe'ye çevirir ve sözler panelinde orijinal satırın altında görüntüler.",
                    fontSize = 12.sp,
                    color = palette.onSurfaceMuted
                )

                SettingToggleItem(
                    label = "Şarkı Sözlerini Türkçe'ye Çevir",
                    checked = autoTranslateLyricsToTurkish,
                    onCheckedChange = onSetAutoTranslateLyricsToTurkish
                )

                if (autoTranslateLyricsToTurkish) {
                    Text(
                        text = "Çeviri Motoru Seçimi:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = palette.onSurface
                    )

                    TranslationEngine.entries.forEach { engine ->
                        val isSelected = engine == translationEngine
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (isSelected) palette.primaryAccent.copy(alpha = 0.16f) else palette.surface)
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) palette.primaryAccent else palette.dividerOrBorder,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { onSelectTranslationEngine(engine) }
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = engine.displayName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = palette.onSurface
                                )
                                Text(
                                    text = engine.subtitle,
                                    fontSize = 11.sp,
                                    color = palette.onSurfaceMuted
                                )
                            }
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Seçili",
                                    tint = palette.primaryAccent
                                )
                            }
                        }
                    }
                }
            }
        }

        // SEKME 8: Hesap Kütüphanesi, Uygulama Simgesi & ytdlnis İndirme Motoru
        item(key = "sec_system_and_engine") {
            ExpandableSettingsSection(
                title = "8. Hesap Senkronizasyonu, Simge & ytdlnis Motoru",
                subtitle = "yt-dlp ($youtubeDLVersion) • Çerezlerle Beğenilenleri İndir • Uygulama Simgesi",
                icon = Icons.Default.Verified,
                expanded = isExpanded("system_and_engine"),
                onToggle = { toggleSection("system_and_engine") },
                testTag = "section_system_and_engine"
            ) {
                Text(
                    text = "Varsayılan İndirme Türü & Format Tercihi:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.onSurface
                )
                Text(
                    text = "İndirmelerin sadece şarkı (ses) veya video olarak yapılması bu ayara göre belirlenir. 'Sadece Şarkı' seçildiğinde videolar asla indirilmez.",
                    fontSize = 12.sp,
                    color = palette.onSurfaceMuted
                )

                DownloadFormatOption.entries.forEach { formatOpt ->
                    val isSelected = formatOpt == selectedDownloadFormat
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isSelected) palette.primaryAccent.copy(alpha = 0.16f)
                                else palette.surfaceVariant
                            )
                            .border(
                                1.dp,
                                if (isSelected) palette.primaryAccent else palette.dividerOrBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { onSelectDownloadFormat(formatOpt) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = formatOpt.displayName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = palette.onSurface
                                )
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(
                                            if (formatOpt.isAudioExtraction) palette.primaryAccent.copy(alpha = 0.2f)
                                            else palette.secondaryAccent.copy(alpha = 0.2f)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = if (formatOpt.isAudioExtraction) "Sadece Şarkı / Ses" else "Video + Ses",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (formatOpt.isAudioExtraction) palette.primaryAccent else palette.secondaryAccent
                                    )
                                }
                            }
                            Text(
                                text = "${formatOpt.description} (${formatOpt.expectedExtension.uppercase()})",
                                fontSize = 11.sp,
                                color = palette.onSurfaceMuted
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Seçili Format",
                                tint = palette.primaryAccent
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Hesap Kütüphanesi & Beğenilen Müzikler (Çerez Destekli)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.onSurface
                )
                Text(
                    text = "YouTube Music beğenilenleri (LM) ile ana YouTube beğenilen videoları (LL) birbirinden bağımsız olarak çözümlenir ve seçmeli olarak listelenir.",
                    fontSize = 12.sp,
                    color = palette.onSurfaceMuted
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onDownloadAccountLibraryWithCookies(LikedSongsSourceType.YOUTUBE_MUSIC) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.primaryAccent)
                    ) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("YT Müzik (LM)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Button(
                        onClick = { onDownloadAccountLibraryWithCookies(LikedSongsSourceType.YOUTUBE_VIDEOS) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.secondaryAccent)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("YT Videolar (LL)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Uygulama Simgesi Değiştirme:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.onSurface
                )

                AppIconOption.entries.forEach { iconOpt ->
                    val isSelected = iconOpt == selectedAppIcon
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isSelected) palette.primaryAccent.copy(alpha = 0.16f)
                                else palette.surfaceVariant
                            )
                            .border(
                                1.dp,
                                if (isSelected) palette.primaryAccent else palette.dividerOrBorder,
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { onSelectAppIcon(iconOpt) }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val (previewBg, previewFg, previewGlyph) = remember(iconOpt) {
                            when (iconOpt) {
                                AppIconOption.DEFAULT -> Triple(Color(0xFFFFB7C5), Color(0xFFFF4081), "🌸")
                                AppIconOption.NEON -> Triple(Color(0xFF0F172A), Color(0xFF00F0FF), "⚡")
                                AppIconOption.DARK -> Triple(Color(0xFF1E102F), Color(0xFFD4AF37), "🌙")
                                AppIconOption.GOLDEN -> Triple(Color(0xFF452205), Color(0xFFFFB300), "🍂")
                                AppIconOption.BERSERK_GUTS -> Triple(Color(0xFF140808), Color(0xFFFF1E27), "⚔")
                                AppIconOption.BERSERK_GRIFFITH -> Triple(Color(0xFF0A1828), Color(0xFF70D6FF), "𓅃")
                                AppIconOption.EVANGELION_01 -> Triple(Color(0xFF1B0B2E), Color(0xFF39FF14), "01")
                                AppIconOption.CHAINSAW_MAN -> Triple(Color(0xFF2B0E04), Color(0xFFFF5722), "⚙")
                                AppIconOption.COWBOY_BEBOP -> Triple(Color(0xFF0A1128), Color(0xFFFFD700), "✦")
                            }
                        }
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(previewBg)
                                .border(1.dp, previewFg.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = previewGlyph,
                                fontSize = 14.sp,
                                color = previewFg,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = iconOpt.displayName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = palette.onSurface
                            )
                            Text(
                                text = iconOpt.description,
                                fontSize = 11.sp,
                                color = palette.onSurfaceMuted
                            )
                        }
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Seçili",
                                tint = palette.primaryAccent
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "ytdlnis İndirme Motoru Durumu:",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.onSurface
                )
                Text(
                    text = "• yt-dlp Çekirdek Sürümü: $youtubeDLVersion (${if (isYtdlpEngineReady) "Aktif" else "Devre Dışı"})\n" +
                        "• FFmpeg Post-Processing: ${if (isFFmpegReady) "Aktif" else "Devre Dışı"}\n" +
                        "• Aria2c Çoklu Bağlantı: ${if (isAria2cReady) "Aktif" else "Devre Dışı"}",
                    fontSize = 12.sp,
                    color = palette.onSurfaceMuted
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onUpdateYoutubeDL(false) },
                        enabled = !isUpdatingYoutubeDL,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Kararlı Güncelle", fontSize = 12.sp)
                    }
                    Button(
                        onClick = { onUpdateYoutubeDL(true) },
                        enabled = !isUpdatingYoutubeDL,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Nightly Güncelle", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun ExpandableSettingsSection(
    title: String,
    subtitle: String,
    icon: ImageVector,
    expanded: Boolean,
    onToggle: () -> Unit,
    testTag: String,
    content: @Composable ColumnScope.() -> Unit
) {
    val palette = LocalAppThemePalette.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(palette.surfaceContainer)
            .border(
                width = if (expanded) 1.5.dp else 1.dp,
                color = if (expanded) palette.primaryAccent else palette.dividerOrBorder,
                shape = RoundedCornerShape(18.dp)
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onToggle)
                .padding(horizontal = 16.dp, vertical = 14.dp)
                .testTag(testTag),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            if (expanded) palette.primaryAccent
                            else palette.primaryAccent.copy(alpha = 0.16f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (expanded) palette.onPrimary else palette.primaryAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.onSurface
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = if (expanded) palette.primaryAccent else palette.onSurfaceMuted
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
                imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                contentDescription = if (expanded) "Sekmeyi Kapat" else "Sekmeyi Aç",
                tint = palette.primaryAccent
            )
        }

        AnimatedVisibility(
            visible = expanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                content = content
            )
        }
    }
}

@Composable
private fun SettingToggleItem(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalAppThemePalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.surface.copy(alpha = 0.55f))
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 12.sp, color = palette.onSurface, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
