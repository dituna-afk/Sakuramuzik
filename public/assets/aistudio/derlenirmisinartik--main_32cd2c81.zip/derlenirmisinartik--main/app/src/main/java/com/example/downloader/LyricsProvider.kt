package com.example.downloader

import android.content.Context
import android.util.LruCache
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

object LyricsProvider {

    private val rawLrcMemoryCache = LruCache<String, String>(64)
    @Volatile
    private var persistentDir: File? = null

    fun init(context: Context) {
        val dir = File(context.filesDir, "LyricsCache")
        if (!dir.exists()) {
            dir.mkdirs()
        }
        persistentDir = dir
    }

    private fun buildCacheKey(title: String, artist: String, localAudioFile: File?): String {
        if (localAudioFile != null) {
            return "file:${localAudioFile.absolutePath}"
        }
        return buildMetaKey(title, artist)
    }

    private fun buildMetaKey(title: String, artist: String): String {
        return "meta:${artist.lowercase(Locale.US).trim()}|${title.lowercase(Locale.US).trim()}"
    }

    private fun getPersistentFile(title: String, artist: String): File? {
        val dir = persistentDir ?: return null
        val safeArtist = artist.lowercase(Locale.US).replace(Regex("[^a-z0-9]"), "_").take(32)
        val safeTitle = title.lowercase(Locale.US).replace(Regex("[^a-z0-9]"), "_").take(48)
        return File(dir, "${safeArtist}_${safeTitle}.lrc")
    }

    fun saveCustomLyrics(
        title: String,
        artist: String,
        lrcText: String,
        localAudioFile: File? = null
    ) {
        val fileKey = buildCacheKey(title, artist, localAudioFile)
        val metaKey = buildMetaKey(title, artist)

        rawLrcMemoryCache.put(fileKey, lrcText)
        rawLrcMemoryCache.put(metaKey, lrcText)

        // 1. Write sidecar .lrc beside local audio file
        if (localAudioFile != null && localAudioFile.exists()) {
            try {
                val sidecarLrc = File(localAudioFile.parentFile, "${localAudioFile.nameWithoutExtension}.lrc")
                sidecarLrc.writeText(lrcText, Charsets.UTF_8)
            } catch (_: Exception) {
            }
        }

        // 2. Write to persistent app LyricsCache directory
        try {
            val diskFile = getPersistentFile(title, artist)
            diskFile?.writeText(lrcText, Charsets.UTF_8)
        } catch (_: Exception) {
        }
    }

    fun getCachedRawLyrics(title: String, artist: String, localAudioFile: File? = null): String? {
        val fileKey = buildCacheKey(title, artist, localAudioFile)
        val metaKey = buildMetaKey(title, artist)

        val memFile = rawLrcMemoryCache.get(fileKey)
        if (!memFile.isNullOrBlank()) return memFile

        val memMeta = rawLrcMemoryCache.get(metaKey)
        if (!memMeta.isNullOrBlank()) return memMeta

        // Check sidecar file
        if (localAudioFile != null && localAudioFile.exists()) {
            val sidecarLrc = File(localAudioFile.parentFile, "${localAudioFile.nameWithoutExtension}.lrc")
            if (sidecarLrc.exists() && sidecarLrc.length() > 0L) {
                val diskText = try {
                    sidecarLrc.readText(Charsets.UTF_8)
                } catch (_: Exception) {
                    null
                }
                if (!diskText.isNullOrBlank()) {
                    rawLrcMemoryCache.put(fileKey, diskText)
                    rawLrcMemoryCache.put(metaKey, diskText)
                    return diskText
                }
            }
        }

        // Check persistent lyrics cache directory
        val diskFile = getPersistentFile(title, artist)
        if (diskFile != null && diskFile.exists() && diskFile.length() > 0L) {
            val persistentText = try {
                diskFile.readText(Charsets.UTF_8)
            } catch (_: Exception) {
                null
            }
            if (!persistentText.isNullOrBlank()) {
                rawLrcMemoryCache.put(fileKey, persistentText)
                rawLrcMemoryCache.put(metaKey, persistentText)
                return persistentText
            }
        }

        return null
    }

    suspend fun fetchSyncedLyrics(
        title: String,
        artist: String,
        durationSeconds: Long,
        localAudioFile: File? = null
    ): String? = withContext(Dispatchers.IO) {
        val cachedDiskOrMem = getCachedRawLyrics(title, artist, localAudioFile)
        if (!cachedDiskOrMem.isNullOrBlank()) {
            return@withContext cachedDiskOrMem
        }

        val cleanTitle = title
            .replace(Regex("\\((?i)(official|video|audio|lyrics|hd|4k|visualizer|mv).*?\\)"), "")
            .replace(Regex("\\[(?i)(official|video|audio|lyrics|hd|4k|visualizer|mv).*?]"), "")
            .trim()
        val cleanArtist = artist.removeSuffix(" - Topic").trim()

        if (cleanTitle.isBlank()) return@withContext null

        val fetchedLrc = queryLrclib(cleanTitle, cleanArtist, durationSeconds)
        if (!fetchedLrc.isNullOrBlank()) {
            saveCustomLyrics(title, artist, fetchedLrc, localAudioFile)
        }
        fetchedLrc
    }

    private fun queryLrclib(title: String, artist: String, durationSeconds: Long): String? {
        return try {
            val encodedQuery = URLEncoder.encode("$artist $title".trim(), "UTF-8")
            val endpoint = URL("https://lrclib.net/api/search?q=$encodedQuery")
            val conn = (endpoint.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 6_000
                readTimeout = 6_000
                setRequestProperty("User-Agent", "SakuraMusic/1.0 (https://github.com/deniscerri/ytdlnis)")
            }
            val code = conn.responseCode
            if (code !in 200..299) {
                conn.disconnect()
                return null
            }

            val body = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use {
                it.readText()
            }
            conn.disconnect()

            val arr = JSONArray(body)
            var bestSynced: String? = null
            var bestPlainAsLrc: String? = null
            var smallestDurationDiff = Long.MAX_VALUE

            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val synced = item.optString("syncedLyrics", "").trim()
                val plain = item.optString("plainLyrics", "").trim()
                val itemDuration = item.optDouble("duration", 0.0).toLong()
                val diff = if (durationSeconds > 0L && itemDuration > 0L) {
                    kotlin.math.abs(durationSeconds - itemDuration)
                } else {
                    0L
                }

                if (synced.isNotEmpty() && diff < smallestDurationDiff) {
                    smallestDurationDiff = diff
                    bestSynced = synced
                } else if (bestPlainAsLrc == null && plain.isNotEmpty()) {
                    bestPlainAsLrc = convertPlainLyricsToTimedLrc(plain, durationSeconds)
                }
            }

            bestSynced ?: bestPlainAsLrc
        } catch (_: Exception) {
            null
        }
    }

    private fun convertPlainLyricsToTimedLrc(plain: String, durationSeconds: Long): String {
        val lines = plain.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return ""
        val totalMs = (durationSeconds.takeIf { it > 15L } ?: 180L) * 1000L
        val stepMs = (totalMs / (lines.size + 1)).coerceAtLeast(3_000L)
        val sb = StringBuilder()
        lines.forEachIndexed { idx, line ->
            val timeMs = idx * stepMs
            val mins = (timeMs / 60_000L)
            val secs = (timeMs % 60_000L) / 1000L
            val hundredths = (timeMs % 1000L) / 10L
            sb.append(String.format("[%02d:%02d.%02d]%s\n", mins, secs, hundredths, line))
        }
        return sb.toString()
    }
}
