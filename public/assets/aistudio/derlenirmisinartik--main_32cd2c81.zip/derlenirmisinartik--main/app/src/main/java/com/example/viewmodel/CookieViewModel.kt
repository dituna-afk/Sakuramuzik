package com.example.viewmodel

import android.app.Application
import android.webkit.CookieManager
import androidx.lifecycle.AndroidViewModel
import com.example.data.CookieStorageHelper
import com.example.downloader.NetscapeCookieHelper
import com.example.model.CookieItem
import com.example.model.CookieLogEntry
import com.example.model.CookieParser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class CookieUiState(
    val currentUrl: String = "https://music.youtube.com",
    val pageTitle: String = "YouTube Music",
    val isLoading: Boolean = false,
    val cookies: List<CookieItem> = emptyList(),
    val searchQuery: String = "",
    val logEntries: List<CookieLogEntry> = emptyList(),
    val statusMessage: String? = null
) {
    val filteredCookies: List<CookieItem>
        get() {
            if (searchQuery.isBlank()) return cookies
            val q = searchQuery.trim().lowercase()
            return cookies.filter {
                it.name.lowercase().contains(q) ||
                    it.value.lowercase().contains(q) ||
                    it.domain.lowercase().contains(q)
            }
        }
}

class CookieViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext = application.applicationContext
    private val storageHelper = CookieStorageHelper(appContext)
    private val cookieManager: CookieManager = CookieManager.getInstance()

    private val _uiState = MutableStateFlow(CookieUiState())
    val uiState: StateFlow<CookieUiState> = _uiState.asStateFlow()

    init {
        try {
            cookieManager.setAcceptCookie(true)
        } catch (_: Throwable) {
        }
        val (savedUrl, savedCookies) = storageHelper.loadCookies()
        val activeCookies = NetscapeCookieHelper.resolveActiveCookies(appContext, savedCookies)
        if (activeCookies.isNotEmpty()) {
            NetscapeCookieHelper.writeNetscapeCookieFile(appContext, activeCookies)
            _uiState.update {
                it.copy(
                    currentUrl = savedUrl.ifBlank { it.currentUrl },
                    cookies = activeCookies
                )
            }
        }
    }

    fun updateUrl(newUrl: String) {
        val normalized = normalizeUrl(newUrl)
        _uiState.update { it.copy(currentUrl = normalized) }
    }

    fun onPageStarted(url: String) {
        _uiState.update { it.copy(currentUrl = url, isLoading = true) }
    }

    fun onPageFinished(url: String, title: String?) {
        try {
            cookieManager.flush()
        } catch (_: Throwable) {
        }
        val rawCookies = try {
            cookieManager.getCookie(url)
        } catch (_: Throwable) {
            null
        }
        val parsed = CookieParser.parseRawCookies(rawCookies, url)
        val merged = NetscapeCookieHelper.resolveActiveCookies(
            context = appContext,
            explicitCookies = if (parsed.isNotEmpty()) parsed else _uiState.value.cookies
        )

        if (merged.isNotEmpty()) {
            storageHelper.saveCookies(url, merged)
            NetscapeCookieHelper.writeNetscapeCookieFile(appContext, merged)
        }

        val logEntry = if (!rawCookies.isNullOrBlank()) {
            CookieLogEntry(
                url = url,
                rawCookieHeader = rawCookies,
                cookieCount = merged.size
            )
        } else null

        _uiState.update { state ->
            state.copy(
                currentUrl = url,
                pageTitle = title?.takeIf { it.isNotBlank() } ?: state.pageTitle,
                isLoading = false,
                cookies = merged,
                logEntries = if (logEntry != null) {
                    (listOf(logEntry) + state.logEntries).take(40)
                } else state.logEntries
            )
        }
    }

    fun refreshCookiesForCurrentUrl() {
        try {
            cookieManager.flush()
        } catch (_: Throwable) {
        }
        val url = _uiState.value.currentUrl
        val rawCookies = try {
            cookieManager.getCookie(url)
        } catch (_: Throwable) {
            null
        }
        val parsed = CookieParser.parseRawCookies(rawCookies, url)
        val allMerged = NetscapeCookieHelper.resolveActiveCookies(appContext, parsed)
        if (allMerged.isNotEmpty()) {
            storageHelper.saveCookies(url, allMerged)
            NetscapeCookieHelper.writeNetscapeCookieFile(appContext, allMerged)
            val hasAuth = NetscapeCookieHelper.hasYouTubeAuthCookies(allMerged)
            _uiState.update {
                it.copy(
                    cookies = allMerged,
                    statusMessage = if (hasAuth) {
                        "${allMerged.size} çerez yakalandı (Oturum / Beğenilenler yetkisi aktif, ytdlnis ile senkronize edildi)."
                    } else {
                        "${allMerged.size} çerez yakalandı ve ytdlnis için şifreli depoya kaydedildi."
                    }
                )
            }
        } else {
            _uiState.update {
                it.copy(statusMessage = "Bu sayfa için aktif çerez bulunamadı.")
            }
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun addOrUpdateCookie(cookie: CookieItem) {
        val url = _uiState.value.currentUrl
        try {
            cookieManager.setCookie(url, cookie.toRawCookieString())
            cookieManager.setCookie("https://music.youtube.com", cookie.toRawCookieString())
            cookieManager.setCookie("https://www.youtube.com", cookie.toRawCookieString())
            cookieManager.flush()
        } catch (_: Throwable) {
        }
        val updated = _uiState.value.cookies.toMutableList().apply {
            val idx = indexOfFirst { it.id == cookie.id || it.name == cookie.name }
            if (idx >= 0) set(idx, cookie) else add(0, cookie)
        }
        storageHelper.saveCookies(url, updated)
        NetscapeCookieHelper.writeNetscapeCookieFile(appContext, updated)
        _uiState.update {
            it.copy(
                cookies = updated,
                statusMessage = "'${cookie.name}' çerezi ytdlnis ve oynatıcı için kaydedildi."
            )
        }
    }

    fun deleteCookie(cookie: CookieItem) {
        val updated = _uiState.value.cookies.filterNot { it.id == cookie.id }
        storageHelper.saveCookies(_uiState.value.currentUrl, updated)
        NetscapeCookieHelper.writeNetscapeCookieFile(appContext, updated)
        _uiState.update {
            it.copy(
                cookies = updated,
                statusMessage = "'${cookie.name}' silindi."
            )
        }
    }

    fun clearAllCookies() {
        try {
            cookieManager.removeAllCookies(null)
            cookieManager.flush()
        } catch (_: Throwable) {
        }
        storageHelper.clearSavedCookies()
        _uiState.update {
            it.copy(
                cookies = emptyList(),
                statusMessage = "Tüm çerezler temizlendi."
            )
        }
    }

    fun saveCurrentCookiesToStorage() {
        val state = _uiState.value
        val merged = NetscapeCookieHelper.resolveActiveCookies(appContext, state.cookies)
        storageHelper.saveCookies(state.currentUrl, merged)
        NetscapeCookieHelper.writeNetscapeCookieFile(appContext, merged)
        _uiState.update {
            it.copy(
                cookies = merged,
                statusMessage = "${merged.size} çerez ytdlnis ve oynatıcı kullanımı için kaydedildi."
            )
        }
    }

    fun loadCookiesFromStorage() {
        val (savedUrl, savedCookies) = storageHelper.loadCookies()
        val merged = NetscapeCookieHelper.resolveActiveCookies(appContext, savedCookies)
        NetscapeCookieHelper.writeNetscapeCookieFile(appContext, merged)
        _uiState.update {
            it.copy(
                currentUrl = savedUrl.ifBlank { it.currentUrl },
                cookies = merged,
                statusMessage = "${merged.size} kayıtlı çerez yüklendi ve ytdlnis'e aktarıldı."
            )
        }
    }

    fun exportCookiesAsJson(): String {
        val state = _uiState.value
        val merged = NetscapeCookieHelper.resolveActiveCookies(appContext, state.cookies)
        return storageHelper.exportCookiesAsJson(state.currentUrl, merged)
    }

    fun clearLogs() {
        _uiState.update { it.copy(logEntries = emptyList()) }
    }

    fun clearStatusMessage() {
        _uiState.update { it.copy(statusMessage = null) }
    }

    private fun normalizeUrl(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return "https://music.youtube.com"
        return if (trimmed.startsWith("http://", ignoreCase = true) ||
            trimmed.startsWith("https://", ignoreCase = true)
        ) {
            trimmed
        } else {
            "https://$trimmed"
        }
    }
}
