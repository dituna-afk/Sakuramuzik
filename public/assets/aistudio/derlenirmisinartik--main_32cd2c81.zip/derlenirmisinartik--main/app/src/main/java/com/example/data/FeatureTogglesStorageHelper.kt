package com.example.data

import android.content.Context

enum class NowPlayingSceneMode(
    val id: String,
    val shortTitle: String,
    val displayName: String,
    val description: String
) {
    DEFAULT_CLASSIC(
        id = "default_classic",
        shortTitle = "Sade Kapak",
        displayName = "1. Yok (Sade Kapak - Varsayılan)",
        description = "Kapak etrafında hiçbir ekstra çizim veya efekt olmaz; en sade ve akıcı görünüm"
    ),
    SAKURA_TREE_STAGE(
        id = "sakura_tree_stage",
        shortTitle = "🌸 Sakura Ağacı",
        displayName = "2. Albüm Arkası Canlı Sakura Ağacı",
        description = "Albüm kapağının arkasından uzanan, seçili temayla renk değiştiren rüzgarlı Sakura dalları ve dökülen yapraklar"
    ),
    ZEN_LOTUS_RIPPLES(
        id = "zen_lotus_ripples",
        shortTitle = "🪷 Zen Su & Nilüfer",
        displayName = "3. Zen Su Halkaları & Nilüfer (Suikinkutsu)",
        description = "Kapağın etrafında müziğin ritmiyle yayılan duru su halkaları ve su üstünde süzülen ışıklı nilüfer çiçekleri"
    ),
    PAPER_LANTERNS_FIREFLIES(
        id = "paper_lanterns_fireflies",
        shortTitle = "🏮 Japon Fenerleri",
        displayName = "4. Japon Kağıt Fenerleri & Ateşböceği (Tōrō)",
        description = "Kapağın yanlarından göğe süzülen sıcak Japon dilek fenerleri (Chōchin) ve ritimle parıldayan ateşböcekleri"
    );

    companion object {
        val DEFAULT = DEFAULT_CLASSIC

        fun fromId(id: String?): NowPlayingSceneMode {
            return when (id) {
                "cyber_neon_vinyl", "starlight_aurora" -> DEFAULT_CLASSIC
                else -> entries.find { it.id == id } ?: DEFAULT
            }
        }
    }
}

data class FeatureTogglesConfig(
    val waveformSeekbarEnabled: Boolean = true,
    val doubleTapSeekEnabled: Boolean = true,
    val dynamicCoverPaletteEnabled: Boolean = false,
    val abLoopEnabled: Boolean = false,
    val playerScenesEnabled: Boolean = true,
    val selectedPlayerScene: NowPlayingSceneMode = NowPlayingSceneMode.DEFAULT_CLASSIC,
    val equalizerEnabled: Boolean = true,
    val pitchAndReverbEnabled: Boolean = false,
    val spatial8DAudioEnabled: Boolean = false,
    val ambientMixerEnabled: Boolean = false,
    val vocalReducerEnabled: Boolean = false,
    val lyricCardGeneratorEnabled: Boolean = true,
    val tagEditorEnabled: Boolean = true,
    val libraryDoctorEnabled: Boolean = true,
    val smartAutoplayEnabled: Boolean = true,
    val musicStatsEnabled: Boolean = true,
    val animeArtworkBackgroundEnabled: Boolean = true,
    val animeThemeFontsEnabled: Boolean = true
)

class FeatureTogglesStorageHelper(context: Context) {
    private val prefs = context.getSharedPreferences("sakura_feature_toggles", Context.MODE_PRIVATE)

    fun loadConfig(): FeatureTogglesConfig {
        return FeatureTogglesConfig(
            waveformSeekbarEnabled = prefs.getBoolean(KEY_WAVEFORM_SEEKBAR, true),
            doubleTapSeekEnabled = prefs.getBoolean(KEY_DOUBLE_TAP_SEEK, true),
            dynamicCoverPaletteEnabled = prefs.getBoolean(KEY_DYNAMIC_COVER_PALETTE, false),
            abLoopEnabled = prefs.getBoolean(KEY_AB_LOOP, false),
            playerScenesEnabled = prefs.getBoolean(KEY_PLAYER_SCENES_ENABLED, true),
            selectedPlayerScene = NowPlayingSceneMode.fromId(
                prefs.getString(KEY_SELECTED_PLAYER_SCENE, NowPlayingSceneMode.DEFAULT_CLASSIC.id)
            ),
            equalizerEnabled = prefs.getBoolean(KEY_EQUALIZER, true),
            pitchAndReverbEnabled = prefs.getBoolean(KEY_PITCH_REVERB, false),
            spatial8DAudioEnabled = prefs.getBoolean(KEY_SPATIAL_8D, false),
            ambientMixerEnabled = prefs.getBoolean(KEY_AMBIENT_MIXER, false),
            vocalReducerEnabled = prefs.getBoolean(KEY_VOCAL_REDUCER, false),
            lyricCardGeneratorEnabled = prefs.getBoolean(KEY_LYRIC_CARD, true),
            tagEditorEnabled = prefs.getBoolean(KEY_TAG_EDITOR, true),
            libraryDoctorEnabled = prefs.getBoolean(KEY_LIBRARY_DOCTOR, true),
            smartAutoplayEnabled = prefs.getBoolean(KEY_SMART_AUTOPLAY, true),
            musicStatsEnabled = prefs.getBoolean(KEY_MUSIC_STATS, true),
            animeArtworkBackgroundEnabled = prefs.getBoolean(KEY_ANIME_ARTWORK_BG, true),
            animeThemeFontsEnabled = prefs.getBoolean(KEY_ANIME_THEME_FONTS, true)
        )
    }

    fun saveConfig(config: FeatureTogglesConfig) {
        prefs.edit()
            .putBoolean(KEY_WAVEFORM_SEEKBAR, config.waveformSeekbarEnabled)
            .putBoolean(KEY_DOUBLE_TAP_SEEK, config.doubleTapSeekEnabled)
            .putBoolean(KEY_DYNAMIC_COVER_PALETTE, config.dynamicCoverPaletteEnabled)
            .putBoolean(KEY_AB_LOOP, config.abLoopEnabled)
            .putBoolean(KEY_PLAYER_SCENES_ENABLED, config.playerScenesEnabled)
            .putString(KEY_SELECTED_PLAYER_SCENE, config.selectedPlayerScene.id)
            .putBoolean(KEY_EQUALIZER, config.equalizerEnabled)
            .putBoolean(KEY_PITCH_REVERB, config.pitchAndReverbEnabled)
            .putBoolean(KEY_SPATIAL_8D, config.spatial8DAudioEnabled)
            .putBoolean(KEY_AMBIENT_MIXER, config.ambientMixerEnabled)
            .putBoolean(KEY_VOCAL_REDUCER, config.vocalReducerEnabled)
            .putBoolean(KEY_LYRIC_CARD, config.lyricCardGeneratorEnabled)
            .putBoolean(KEY_TAG_EDITOR, config.tagEditorEnabled)
            .putBoolean(KEY_LIBRARY_DOCTOR, config.libraryDoctorEnabled)
            .putBoolean(KEY_SMART_AUTOPLAY, config.smartAutoplayEnabled)
            .putBoolean(KEY_MUSIC_STATS, config.musicStatsEnabled)
            .putBoolean(KEY_ANIME_ARTWORK_BG, config.animeArtworkBackgroundEnabled)
            .putBoolean(KEY_ANIME_THEME_FONTS, config.animeThemeFontsEnabled)
            .apply()
    }

    companion object {
        private const val KEY_WAVEFORM_SEEKBAR = "waveform_seekbar_enabled"
        private const val KEY_DOUBLE_TAP_SEEK = "double_tap_seek_enabled"
        private const val KEY_DYNAMIC_COVER_PALETTE = "dynamic_cover_palette_v27_enabled"
        private const val KEY_AB_LOOP = "ab_loop_v27_enabled"
        private const val KEY_PLAYER_SCENES_ENABLED = "player_scenes_v27_enabled"
        private const val KEY_SELECTED_PLAYER_SCENE = "selected_player_scene_v27"
        private const val KEY_EQUALIZER = "equalizer_enabled"
        private const val KEY_PITCH_REVERB = "pitch_reverb_enabled"
        private const val KEY_SPATIAL_8D = "spatial_8d_enabled"
        private const val KEY_AMBIENT_MIXER = "ambient_mixer_enabled"
        private const val KEY_VOCAL_REDUCER = "vocal_reducer_enabled"
        private const val KEY_LYRIC_CARD = "lyric_card_enabled"
        private const val KEY_TAG_EDITOR = "tag_editor_enabled"
        private const val KEY_LIBRARY_DOCTOR = "library_doctor_enabled"
        private const val KEY_SMART_AUTOPLAY = "smart_autoplay_enabled"
        private const val KEY_MUSIC_STATS = "music_stats_enabled"
        private const val KEY_ANIME_ARTWORK_BG = "anime_artwork_bg_enabled"
        private const val KEY_ANIME_THEME_FONTS = "anime_theme_fonts_enabled"
    }
}
