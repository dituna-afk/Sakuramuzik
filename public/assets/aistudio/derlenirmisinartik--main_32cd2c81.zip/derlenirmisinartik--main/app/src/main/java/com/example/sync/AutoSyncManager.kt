package com.example.sync

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.data.CookieStorageHelper
import com.example.downloader.DownloadFormatOption
import com.example.downloader.DownloadPreferencesManager
import com.example.downloader.MediaMetadataManager
import com.example.downloader.YTDlpResolver
import com.example.downloader.YouTubeStreamResolver
import com.example.downloader.YoutubeDLDownloadManager
import com.example.downloader.YoutubeDLDownloadState
import java.util.UUID
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class SubscriptionSource(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val url: String,
    val preferredFormatName: String = DownloadFormatOption.AUDIO_M4A_HIGH.name,
    val lastSyncedTimestamp: Long = 0L,
    val downloadedVideoIds: Set<String> = emptySet(),
    val isEnabled: Boolean = true
)

class SubscriptionStorage(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun loadSubscriptions(): List<SubscriptionSource> {
        val raw = prefs.getString(KEY_SUBSCRIPTIONS_JSON, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val result = mutableListOf<SubscriptionSource>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val idsArray = obj.optJSONArray("downloadedVideoIds")
                val ids = mutableSetOf<String>()
                if (idsArray != null) {
                    for (j in 0 until idsArray.length()) {
                        val vId = idsArray.optString(j)
                        if (vId.isNotBlank()) ids.add(vId)
                    }
                }
                result.add(
                    SubscriptionSource(
                        id = obj.optString("id", UUID.randomUUID().toString()),
                        title = obj.optString("title", "Kanal / Liste"),
                        url = obj.optString("url", ""),
                        preferredFormatName = obj.optString(
                            "preferredFormatName",
                            DownloadFormatOption.AUDIO_M4A_HIGH.name
                        ),
                        lastSyncedTimestamp = obj.optLong("lastSyncedTimestamp", 0L),
                        downloadedVideoIds = ids,
                        isEnabled = obj.optBoolean("isEnabled", true)
                    )
                )
            }
            result
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveSubscriptions(subscriptions: List<SubscriptionSource>) {
        val arr = JSONArray()
        subscriptions.forEach { sub ->
            val idsArr = JSONArray()
            sub.downloadedVideoIds.forEach { idsArr.put(it) }
            val obj = JSONObject().apply {
                put("id", sub.id)
                put("title", sub.title)
                put("url", sub.url)
                put("preferredFormatName", sub.preferredFormatName)
                put("lastSyncedTimestamp", sub.lastSyncedTimestamp)
                put("downloadedVideoIds", idsArr)
                put("isEnabled", sub.isEnabled)
            }
            arr.put(obj)
        }
        prefs.edit().putString(KEY_SUBSCRIPTIONS_JSON, arr.toString()).apply()
    }

    fun addSubscription(title: String, url: String, formatName: String): List<SubscriptionSource> {
        val current = loadSubscriptions().toMutableList()
        current.add(
            0,
            SubscriptionSource(
                title = title.trim().ifEmpty { "YouTube Kanal / Liste" },
                url = url.trim(),
                preferredFormatName = formatName
            )
        )
        saveSubscriptions(current)
        return current
    }

    fun removeSubscription(id: String): List<SubscriptionSource> {
        val updated = loadSubscriptions().filterNot { it.id == id }
        saveSubscriptions(updated)
        return updated
    }

    fun toggleSubscription(id: String, enabled: Boolean): List<SubscriptionSource> {
        val updated = loadSubscriptions().map {
            if (it.id == id) it.copy(isEnabled = enabled) else it
        }
        saveSubscriptions(updated)
        return updated
    }

    fun markVideoDownloaded(subscriptionId: String, videoId: String) {
        val updated = loadSubscriptions().map { sub ->
            if (sub.id == subscriptionId) {
                sub.copy(
                    lastSyncedTimestamp = System.currentTimeMillis(),
                    downloadedVideoIds = sub.downloadedVideoIds + videoId
                )
            } else {
                sub
            }
        }
        saveSubscriptions(updated)
    }

    fun isAutoSyncWifiOnly(): Boolean = prefs.getBoolean(KEY_WIFI_ONLY, true)

    fun setAutoSyncWifiOnly(wifiOnly: Boolean) {
        prefs.edit().putBoolean(KEY_WIFI_ONLY, wifiOnly).apply()
    }

    fun getSyncIntervalMinutes(): Long {
        if (prefs.contains(KEY_INTERVAL_MINUTES)) {
            return prefs.getLong(KEY_INTERVAL_MINUTES, 360L).coerceAtLeast(15L)
        }
        val hours = prefs.getLong(KEY_INTERVAL_HOURS, 6L)
        return (hours * 60L).coerceAtLeast(15L)
    }

    fun setSyncIntervalMinutes(minutes: Long) {
        prefs.edit().putLong(KEY_INTERVAL_MINUTES, minutes.coerceAtLeast(15L)).apply()
    }

    fun getSyncIntervalHours(): Long {
        return (getSyncIntervalMinutes() / 60L).coerceAtLeast(1L)
    }

    fun setSyncIntervalHours(hours: Long) {
        setSyncIntervalMinutes(hours * 60L)
    }

    companion object {
        private const val PREFS_NAME = "sakura_subscriptions_prefs"
        private const val KEY_SUBSCRIPTIONS_JSON = "subscriptions_json"
        private const val KEY_WIFI_ONLY = "auto_sync_wifi_only"
        private const val KEY_INTERVAL_HOURS = "sync_interval_hours"
        private const val KEY_INTERVAL_MINUTES = "sync_interval_minutes"
    }
}

class AutoSyncWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val storage = SubscriptionStorage(applicationContext)
            val subscriptions = storage.loadSubscriptions().filter { it.isEnabled && it.url.isNotBlank() }
            if (subscriptions.isEmpty()) return@withContext Result.success()

            val cookieStorage = CookieStorageHelper(applicationContext)
            val (_, savedCookies) = cookieStorage.loadCookies()
            val ytdlpResolver = YTDlpResolver(applicationContext)
            val streamResolver = YouTubeStreamResolver(applicationContext)
            val metadataManager = MediaMetadataManager(applicationContext)
            val prefsManager = DownloadPreferencesManager(applicationContext)
            val downloadManager = YoutubeDLDownloadManager(
                context = applicationContext,
                metadataManager = metadataManager,
                streamResolver = streamResolver,
                preferencesManager = prefsManager
            )

            for (sub in subscriptions) {
                if (isStopped) break
                val playlistId = streamResolver.extractPlaylistId(sub.url)
                val tracks = if (!playlistId.isNullOrBlank()) {
                    streamResolver.resolvePlaylist(playlistId, savedCookies).tracks
                } else {
                    val info = ytdlpResolver.extractSingleMetadata(sub.url, savedCookies).getOrNull()
                    if (info != null) listOf(info) else emptyList()
                }

                val formatOption = DownloadFormatOption.fromName(sub.preferredFormatName)
                val newTracks = tracks.filter { it.id !in sub.downloadedVideoIds }.take(3)
                for (track in newTracks) {
                    if (isStopped) break
                    val state = downloadManager.downloadTrack(
                        url = track.sourceUrl.ifBlank { "https://www.youtube.com/watch?v=${track.id}" },
                        formatOption = formatOption,
                        cookies = savedCookies,
                        existingTrackInfo = track
                    )
                    if (state is YoutubeDLDownloadState.Success) {
                        storage.markVideoDownloaded(sub.id, track.id)
                    }
                }
            }
            Result.success()
        } catch (e: Exception) {
            Log.e("AutoSyncWorker", "Background sync failed", e)
            Result.retry()
        }
    }
}

object AutoSyncScheduler {
    const val PERIODIC_WORK_NAME = "sakura_auto_sync_periodic"
    const val IMMEDIATE_WORK_NAME = "sakura_auto_sync_immediate"

    fun schedulePeriodicSync(context: Context) {
        val storage = SubscriptionStorage(context)
        val wifiOnly = storage.isAutoSyncWifiOnly()
        val intervalMinutes = storage.getSyncIntervalMinutes().coerceAtLeast(15L)

        val constraints = Constraints.Builder()
            .setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
            .setRequiresBatteryNotLow(true)
            .build()

        val request = PeriodicWorkRequestBuilder<AutoSyncWorker>(intervalMinutes, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
            PERIODIC_WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun triggerImmediateSync(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = OneTimeWorkRequestBuilder<AutoSyncWorker>()
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context.applicationContext).enqueue(request)
    }

    fun observePeriodicSyncWork(context: Context): Flow<List<WorkInfo>> {
        return WorkManager.getInstance(context.applicationContext)
            .getWorkInfosForUniqueWorkFlow(PERIODIC_WORK_NAME)
    }
}
