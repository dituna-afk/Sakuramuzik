package com.example.downloader

import android.content.Context

enum class TranslationEngine(val displayName: String, val subtitle: String) {
    GOOGLE_TRANSLATE("Google Translate", "Hızlı ve ücretsiz küresel çeviri motoru"),
    DEEPL("DeepL Translate", "Yüksek kaliteli yapay zeka çeviri motoru (otomatik Google yedekli)")
}

class DownloadPreferencesManager(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var useAria2c: Boolean
        get() = prefs.getBoolean(KEY_USE_ARIA2C, false)
        set(value) = prefs.edit().putBoolean(KEY_USE_ARIA2C, value).apply()

    var useSponsorBlock: Boolean
        get() = prefs.getBoolean(KEY_USE_SPONSORBLOCK, false)
        set(value) = prefs.edit().putBoolean(KEY_USE_SPONSORBLOCK, value).apply()

    var sponsorBlockCategories: String
        get() = prefs.getString(KEY_SPONSORBLOCK_CATEGORIES, DEFAULT_SPONSORBLOCK_CATEGORIES)
            ?: DEFAULT_SPONSORBLOCK_CATEGORIES
        set(value) = prefs.edit().putString(KEY_SPONSORBLOCK_CATEGORIES, value).apply()

    var embedMetadataAndThumb: Boolean
        get() = prefs.getBoolean(KEY_EMBED_METADATA_THUMB, true)
        set(value) = prefs.edit().putBoolean(KEY_EMBED_METADATA_THUMB, value).apply()

    var writeAutoSubtitlesLrc: Boolean
        get() = prefs.getBoolean(KEY_WRITE_AUTO_SUBTITLES, true)
        set(value) = prefs.edit().putBoolean(KEY_WRITE_AUTO_SUBTITLES, value).apply()

    var isPlaylistsGridLayout: Boolean
        get() = prefs.getBoolean(KEY_PLAYLISTS_GRID_LAYOUT, false)
        set(value) = prefs.edit().putBoolean(KEY_PLAYLISTS_GRID_LAYOUT, value).apply()

    var concurrentFragments: Int
        get() = prefs.getInt(KEY_CONCURRENT_FRAGMENTS, 4).coerceIn(1, 16)
        set(value) = prefs.edit().putInt(KEY_CONCURRENT_FRAGMENTS, value.coerceIn(1, 16)).apply()

    var autoTranslateLyricsToTurkish: Boolean
        get() = prefs.getBoolean(KEY_AUTO_TRANSLATE_LYRICS, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_TRANSLATE_LYRICS, value).apply()

    var translationEngine: TranslationEngine
        get() {
            val saved = prefs.getString(KEY_TRANSLATION_ENGINE, TranslationEngine.GOOGLE_TRANSLATE.name)
            return TranslationEngine.entries.firstOrNull { it.name == saved } ?: TranslationEngine.GOOGLE_TRANSLATE
        }
        set(value) = prefs.edit().putString(KEY_TRANSLATION_ENGINE, value.name).apply()

    var defaultDownloadFormat: DownloadFormatOption
        get() {
            val saved = prefs.getString(KEY_DEFAULT_DOWNLOAD_FORMAT, DownloadFormatOption.AUDIO_OPUS_BEST.name)
            return DownloadFormatOption.fromName(saved)
        }
        set(value) = prefs.edit().putString(KEY_DEFAULT_DOWNLOAD_FORMAT, value.name).apply()

    companion object {
        private const val PREFS_NAME = "sakura_download_engine_prefs"
        private const val KEY_DEFAULT_DOWNLOAD_FORMAT = "default_download_format"
        private const val KEY_PLAYLISTS_GRID_LAYOUT = "playlists_grid_layout_saved"
        private const val KEY_USE_ARIA2C = "use_aria2c_downloader"
        private const val KEY_USE_SPONSORBLOCK = "use_sponsorblock"
        private const val KEY_SPONSORBLOCK_CATEGORIES = "sponsorblock_categories"
        private const val KEY_EMBED_METADATA_THUMB = "embed_metadata_and_thumb"
        private const val KEY_WRITE_AUTO_SUBTITLES = "write_auto_subtitles_lrc"
        private const val KEY_CONCURRENT_FRAGMENTS = "concurrent_fragments"
        private const val KEY_AUTO_TRANSLATE_LYRICS = "auto_translate_lyrics_tr"
        private const val KEY_TRANSLATION_ENGINE = "translation_engine_type"
        const val DEFAULT_SPONSORBLOCK_CATEGORIES = "sponsor,intro,outro,selfpromo,interaction,music_offtopic"
    }
}
