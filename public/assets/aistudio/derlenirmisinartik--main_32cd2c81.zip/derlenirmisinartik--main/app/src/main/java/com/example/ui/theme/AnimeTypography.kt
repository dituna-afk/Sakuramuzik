package com.example.ui.theme

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.example.R

val OswaldFontFamily = FontFamily(Font(R.font.oswald, FontWeight.Bold))
val CinzelFontFamily = FontFamily(Font(R.font.cinzel, FontWeight.Bold))
val BangersFontFamily = FontFamily(Font(R.font.bangers, FontWeight.Normal))
val RighteousFontFamily = FontFamily(Font(R.font.righteous, FontWeight.Normal))

fun AppTheme.getCustomFontFamily(enabled: Boolean = true): FontFamily? {
    if (!enabled) return null
    return when (this) {
        AppTheme.EVANGELION_01 -> OswaldFontFamily
        AppTheme.BERSERK_GUTS, AppTheme.BERSERK_GRIFFITH -> CinzelFontFamily
        AppTheme.CHAINSAW_MAN -> BangersFontFamily
        AppTheme.COWBOY_BEBOP_FAYE, AppTheme.COWBOY_BEBOP_SPIKE -> RighteousFontFamily
        else -> null
    }
}
