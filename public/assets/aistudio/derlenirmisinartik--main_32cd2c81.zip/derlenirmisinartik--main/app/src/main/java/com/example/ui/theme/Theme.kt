package com.example.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

enum class AppTheme(
    val displayName: String,
    val subtitle: String,
    val isDark: Boolean
) {
    SAKURA_LIGHT(
        displayName = "Sakura Açık (Klasik)",
        subtitle = "Zarif krem zemin, kiraz çiçeği pembesi ve sıcak gül vurgular",
        isDark = false
    ),
    SAKURA_DARK(
        displayName = "Sakura Koyu (Gece Çiçeği)",
        subtitle = "Derin gece anttrasiti üzerinde parlak sakura pembesi detaylar",
        isDark = true
    ),
    ROSE_QUARTZ(
        displayName = "Gül Kuvars (Romantik)",
        subtitle = "Yumuşak pastel gül tonları ve ipeksi geçişler",
        isDark = false
    ),
    CRIMSON_BLOSSOM(
        displayName = "Kızıl Kiraz (Gece Yarısı)",
        subtitle = "Koyu bordo-siyah atmosfer ve canlı mercan-pembe vurgular",
        isDark = true
    ),
    AMOLED_SAKURA(
        displayName = "Saf Siyah AMOLED Sakura",
        subtitle = "#000000 OLED pil tasarruflu zemin ve neon sakura kontrastı",
        isDark = true
    ),
    BERSERK_GUTS(
        displayName = "Berserk - Guts (Kurban Damgası)",
        subtitle = "Karanlık obsidyen çelik, ejderha katili kılıcı ve kan kızılı",
        isDark = true
    ),
    BERSERK_GRIFFITH(
        displayName = "Berserk - Griffith (Beyaz Şahin)",
        subtitle = "Asil platin gümüş, Şahin Takımı kobalt mavisi ve Behelit kırmızısı",
        isDark = true
    ),
    EVANGELION_01(
        displayName = "Evangelion - Unit-01 & Rei",
        subtitle = "EVA-01 derin moru, toksik neon yeşili ve Nerv acil durum turuncusu",
        isDark = true
    ),
    CHAINSAW_MAN(
        displayName = "Chainsaw Man - Denji (Testere Şeytanı)",
        subtitle = "Endüstriyel katran siyahı, testere turuncusu ve elektrik sarısı",
        isDark = true
    ),
    COWBOY_BEBOP_FAYE(
        displayName = "Cowboy Bebop - Faye Valentine",
        subtitle = "İkonik Faye sarısı, gece moru, kumarhane altını ve neon pembe",
        isDark = true
    ),
    COWBOY_BEBOP_SPIKE(
        displayName = "Cowboy Bebop - Spike Spiegel",
        subtitle = "Gece yarısı caz mavisi, retro saksafon kehribar altın ve uzay grisi",
        isDark = true
    );

    companion object {
        fun fromName(name: String?): AppTheme {
            return entries.find { it.name == name } ?: SAKURA_DARK
        }
    }
}

fun AppTheme.isSakuraTheme(): Boolean {
    return this == AppTheme.SAKURA_LIGHT ||
        this == AppTheme.SAKURA_DARK ||
        this == AppTheme.ROSE_QUARTZ ||
        this == AppTheme.CRIMSON_BLOSSOM ||
        this == AppTheme.AMOLED_SAKURA
}


data class AppThemePalette(
    val theme: AppTheme,
    val background: Color,
    val surface: Color,
    val surfaceContainer: Color,
    val surfaceVariant: Color,
    val primaryAccent: Color,
    val secondaryAccent: Color,
    val tertiaryAccent: Color,
    val onBackground: Color,
    val onSurface: Color,
    val onSurfaceMuted: Color,
    val onPrimary: Color,
    val dividerOrBorder: Color,
    val haloGlowPrimary: Color,
    val haloGlowSecondary: Color,
    val petalPrimary: Color,
    val petalSecondary: Color
)

fun AppTheme.toPalette(): AppThemePalette {
    return when (this) {
        AppTheme.SAKURA_LIGHT -> AppThemePalette(
            theme = this,
            background = Color(0xFFFFF8FA),
            surface = Color(0xFFFFF0F5),
            surfaceContainer = Color(0xFFFFE5EE),
            surfaceVariant = Color(0xFFFAD8E4),
            primaryAccent = Color(0xFFD84B7E),
            secondaryAccent = Color(0xFFF078A0),
            tertiaryAccent = Color(0xFFB53665),
            onBackground = Color(0xFF2B141D),
            onSurface = Color(0xFF331823),
            onSurfaceMuted = Color(0xFF7D5263),
            onPrimary = Color(0xFFFFFFFF),
            dividerOrBorder = Color(0xFFF2C2D4),
            haloGlowPrimary = Color(0xFFFF8CB6),
            haloGlowSecondary = Color(0xFFFFC1D8),
            petalPrimary = Color(0xFFFF9EBF),
            petalSecondary = Color(0xFFFFC8DD)
        )

        AppTheme.SAKURA_DARK -> AppThemePalette(
            theme = this,
            background = Color(0xFF130B10),
            surface = Color(0xFF1E121A),
            surfaceContainer = Color(0xFF291823),
            surfaceVariant = Color(0xFF382130),
            primaryAccent = Color(0xFFFF7AA8),
            secondaryAccent = Color(0xFFFFA3C4),
            tertiaryAccent = Color(0xFFE0487E),
            onBackground = Color(0xFFFFEEF4),
            onSurface = Color(0xFFFFE6EF),
            onSurfaceMuted = Color(0xFFC99BAE),
            onPrimary = Color(0xFF280614),
            dividerOrBorder = Color(0xFF472A3C),
            haloGlowPrimary = Color(0xFFFF6B9E),
            haloGlowSecondary = Color(0xFFB8396A),
            petalPrimary = Color(0xFFFF85B1),
            petalSecondary = Color(0xFFFFB5D0)
        )

        AppTheme.ROSE_QUARTZ -> AppThemePalette(
            theme = this,
            background = Color(0xFFFDF6F8),
            surface = Color(0xFFF8EBEF),
            surfaceContainer = Color(0xFFF2DDE4),
            surfaceVariant = Color(0xFFE8CCD6),
            primaryAccent = Color(0xFFC4517A),
            secondaryAccent = Color(0xFFDE7C9F),
            tertiaryAccent = Color(0xFF9C375B),
            onBackground = Color(0xFF2D1720),
            onSurface = Color(0xFF361C26),
            onSurfaceMuted = Color(0xFF7A5564),
            onPrimary = Color(0xFFFFFFFF),
            dividerOrBorder = Color(0xFFE3BDCB),
            haloGlowPrimary = Color(0xFFE886A9),
            haloGlowSecondary = Color(0xFFF5B8CE),
            petalPrimary = Color(0xFFF098B7),
            petalSecondary = Color(0xFFFAD0DF)
        )

        AppTheme.CRIMSON_BLOSSOM -> AppThemePalette(
            theme = this,
            background = Color(0xFF17080D),
            surface = Color(0xFF240D15),
            surfaceContainer = Color(0xFF32131E),
            surfaceVariant = Color(0xFF451B2A),
            primaryAccent = Color(0xFFFF5C8A),
            secondaryAccent = Color(0xFFFF8FA3),
            tertiaryAccent = Color(0xFFC9184A),
            onBackground = Color(0xFFFFEDF2),
            onSurface = Color(0xFFFFE3EC),
            onSurfaceMuted = Color(0xFFD193A6),
            onPrimary = Color(0xFF2B030E),
            dividerOrBorder = Color(0xFF592336),
            haloGlowPrimary = Color(0xFFFF4D7D),
            haloGlowSecondary = Color(0xFFA4133C),
            petalPrimary = Color(0xFFFF7597),
            petalSecondary = Color(0xFFFFB3C6)
        )

        AppTheme.AMOLED_SAKURA -> AppThemePalette(
            theme = this,
            background = Color(0xFF000000),
            surface = Color(0xFF0D070A),
            surfaceContainer = Color(0xFF180D13),
            surfaceVariant = Color(0xFF26151F),
            primaryAccent = Color(0xFFFF80B0),
            secondaryAccent = Color(0xFFFFAED0),
            tertiaryAccent = Color(0xFFE84A86),
            onBackground = Color(0xFFFFF2F7),
            onSurface = Color(0xFFFFEBF3),
            onSurfaceMuted = Color(0xFFBFA0AE),
            onPrimary = Color(0xFF240310),
            dividerOrBorder = Color(0xFF331C29),
            haloGlowPrimary = Color(0xFFFF70A6),
            haloGlowSecondary = Color(0xFF9E2A5B),
            petalPrimary = Color(0xFFFF8AB6),
            petalSecondary = Color(0xFFFFC2DA)
        )

        AppTheme.BERSERK_GUTS -> AppThemePalette(
            theme = this,
            background = Color(0xFF0A090B),
            surface = Color(0xFF141216),
            surfaceContainer = Color(0xFF1F1B22),
            surfaceVariant = Color(0xFF2C2730),
            primaryAccent = Color(0xFFE51D24),
            secondaryAccent = Color(0xFFFF4D4D),
            tertiaryAccent = Color(0xFF8B0000),
            onBackground = Color(0xFFF5F0F2),
            onSurface = Color(0xFFECE4E7),
            onSurfaceMuted = Color(0xFFA89CA2),
            onPrimary = Color(0xFFFFFFFF),
            dividerOrBorder = Color(0xFF3F3742),
            haloGlowPrimary = Color(0xFFE51D24),
            haloGlowSecondary = Color(0xFF5A0C10),
            petalPrimary = Color(0xFFFF3333),
            petalSecondary = Color(0xFF800000)
        )

        AppTheme.BERSERK_GRIFFITH -> AppThemePalette(
            theme = this,
            background = Color(0xFF090D14),
            surface = Color(0xFF101724),
            surfaceContainer = Color(0xFF182338),
            surfaceVariant = Color(0xFF22304C),
            primaryAccent = Color(0xFF3B82F6),
            secondaryAccent = Color(0xFFE2E8F0),
            tertiaryAccent = Color(0xFFDC2626),
            onBackground = Color(0xFFF8FAFC),
            onSurface = Color(0xFFE2E8F0),
            onSurfaceMuted = Color(0xFF94A3B8),
            onPrimary = Color(0xFFFFFFFF),
            dividerOrBorder = Color(0xFF2E4064),
            haloGlowPrimary = Color(0xFF60A5FA),
            haloGlowSecondary = Color(0xFF1D4ED8),
            petalPrimary = Color(0xFFF1F5F9),
            petalSecondary = Color(0xFF93C5FD)
        )

        AppTheme.EVANGELION_01 -> AppThemePalette(
            theme = this,
            background = Color(0xFF0D0614),
            surface = Color(0xFF170C24),
            surfaceContainer = Color(0xFF241336),
            surfaceVariant = Color(0xFF341C4C),
            primaryAccent = Color(0xFF00FF66),
            secondaryAccent = Color(0xFFA855F7),
            tertiaryAccent = Color(0xFFF97316),
            onBackground = Color(0xFFFAF5FF),
            onSurface = Color(0xFFF3E8FF),
            onSurfaceMuted = Color(0xFFC084FC),
            onPrimary = Color(0xFF081C0E),
            dividerOrBorder = Color(0xFF4C2770),
            haloGlowPrimary = Color(0xFF00FF66),
            haloGlowSecondary = Color(0xFF7E22CE),
            petalPrimary = Color(0xFF00FF66),
            petalSecondary = Color(0xFFC084FC)
        )

        AppTheme.CHAINSAW_MAN -> AppThemePalette(
            theme = this,
            background = Color(0xFF0C0A09),
            surface = Color(0xFF171310),
            surfaceContainer = Color(0xFF241D17),
            surfaceVariant = Color(0xFF332920),
            primaryAccent = Color(0xFFEA580C),
            secondaryAccent = Color(0xFFFACC15),
            tertiaryAccent = Color(0xFFDC2626),
            onBackground = Color(0xFFFFF7ED),
            onSurface = Color(0xFFFED7AA),
            onSurfaceMuted = Color(0xFFA88F78),
            onPrimary = Color(0xFF1C0A02),
            dividerOrBorder = Color(0xFF4D3B2D),
            haloGlowPrimary = Color(0xFFF97316),
            haloGlowSecondary = Color(0xFFEAB308),
            petalPrimary = Color(0xFFF97316),
            petalSecondary = Color(0xFFFDE047)
        )

        AppTheme.COWBOY_BEBOP_FAYE -> AppThemePalette(
            theme = this,
            background = Color(0xFF100717),
            surface = Color(0xFF1C0D26),
            surfaceContainer = Color(0xFF2B143B),
            surfaceVariant = Color(0xFF3B1C52),
            primaryAccent = Color(0xFFF59E0B),
            secondaryAccent = Color(0xFFEC4899),
            tertiaryAccent = Color(0xFF8B5CF6),
            onBackground = Color(0xFFFFFBEB),
            onSurface = Color(0xFFFEF3C7),
            onSurfaceMuted = Color(0xFFD1B58C),
            onPrimary = Color(0xFF261803),
            dividerOrBorder = Color(0xFF562875),
            haloGlowPrimary = Color(0xFFFBBF24),
            haloGlowSecondary = Color(0xFFF472B6),
            petalPrimary = Color(0xFFFCD34D),
            petalSecondary = Color(0xFFF472B6)
        )

        AppTheme.COWBOY_BEBOP_SPIKE -> AppThemePalette(
            theme = this,
            background = Color(0xFF070B14),
            surface = Color(0xFF0E1624),
            surfaceContainer = Color(0xFF162238),
            surfaceVariant = Color(0xFF20314F),
            primaryAccent = Color(0xFF38BDF8),
            secondaryAccent = Color(0xFFF59E0B),
            tertiaryAccent = Color(0xFF64748B),
            onBackground = Color(0xFFF0F9FF),
            onSurface = Color(0xFFE0F2FE),
            onSurfaceMuted = Color(0xFF8BB5CE),
            onPrimary = Color(0xFF032233),
            dividerOrBorder = Color(0xFF294066),
            haloGlowPrimary = Color(0xFF0284C7),
            haloGlowSecondary = Color(0xFFD97706),
            petalPrimary = Color(0xFF7DD3FC),
            petalSecondary = Color(0xFFFDE68A)
        )
    }
}

val LocalAppThemePalette = staticCompositionLocalOf {
    AppTheme.SAKURA_DARK.toPalette()
}

val Typography = Typography(
    headlineMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 26.sp,
        lineHeight = 32.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 26.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 19.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)

@Composable
fun MyApplicationTheme(
    appTheme: AppTheme = AppTheme.SAKURA_DARK,
    dynamicPaletteOverride: AppThemePalette? = null,
    content: @Composable () -> Unit
) {
    val targetPalette = dynamicPaletteOverride ?: appTheme.toPalette()
    val animSpec = tween<Color>(durationMillis = 420)

    val background by animateColorAsState(targetPalette.background, animSpec, label = "bg")
    val surface by animateColorAsState(targetPalette.surface, animSpec, label = "surface")
    val surfaceContainer by animateColorAsState(targetPalette.surfaceContainer, animSpec, label = "sc")
    val surfaceVariant by animateColorAsState(targetPalette.surfaceVariant, animSpec, label = "sv")
    val primary by animateColorAsState(targetPalette.primaryAccent, animSpec, label = "primary")
    val secondary by animateColorAsState(targetPalette.secondaryAccent, animSpec, label = "secondary")
    val tertiary by animateColorAsState(targetPalette.tertiaryAccent, animSpec, label = "tertiary")
    val onBackground by animateColorAsState(targetPalette.onBackground, animSpec, label = "onBg")
    val onSurface by animateColorAsState(targetPalette.onSurface, animSpec, label = "onSurface")
    val onSurfaceMuted by animateColorAsState(targetPalette.onSurfaceMuted, animSpec, label = "onMuted")
    val onPrimary by animateColorAsState(targetPalette.onPrimary, animSpec, label = "onPrimary")
    val divider by animateColorAsState(targetPalette.dividerOrBorder, animSpec, label = "divider")
    val glow1 by animateColorAsState(targetPalette.haloGlowPrimary, animSpec, label = "glow1")
    val glow2 by animateColorAsState(targetPalette.haloGlowSecondary, animSpec, label = "glow2")
    val petal1 by animateColorAsState(targetPalette.petalPrimary, animSpec, label = "petal1")
    val petal2 by animateColorAsState(targetPalette.petalSecondary, animSpec, label = "petal2")

    val animatedPalette = targetPalette.copy(
        background = background,
        surface = surface,
        surfaceContainer = surfaceContainer,
        surfaceVariant = surfaceVariant,
        primaryAccent = primary,
        secondaryAccent = secondary,
        tertiaryAccent = tertiary,
        onBackground = onBackground,
        onSurface = onSurface,
        onSurfaceMuted = onSurfaceMuted,
        onPrimary = onPrimary,
        dividerOrBorder = divider,
        haloGlowPrimary = glow1,
        haloGlowSecondary = glow2,
        petalPrimary = petal1,
        petalSecondary = petal2
    )

    val colorScheme = if (appTheme.isDark) {
        darkColorScheme(
            primary = animatedPalette.primaryAccent,
            onPrimary = animatedPalette.onPrimary,
            secondary = animatedPalette.secondaryAccent,
            tertiary = animatedPalette.tertiaryAccent,
            background = animatedPalette.background,
            onBackground = animatedPalette.onBackground,
            surface = animatedPalette.surface,
            onSurface = animatedPalette.onSurface,
            surfaceVariant = animatedPalette.surfaceVariant,
            onSurfaceVariant = animatedPalette.onSurfaceMuted,
            outline = animatedPalette.dividerOrBorder
        )
    } else {
        lightColorScheme(
            primary = animatedPalette.primaryAccent,
            onPrimary = animatedPalette.onPrimary,
            secondary = animatedPalette.secondaryAccent,
            tertiary = animatedPalette.tertiaryAccent,
            background = animatedPalette.background,
            onBackground = animatedPalette.onBackground,
            surface = animatedPalette.surface,
            onSurface = animatedPalette.onSurface,
            surfaceVariant = animatedPalette.surfaceVariant,
            onSurfaceVariant = animatedPalette.onSurfaceMuted,
            outline = animatedPalette.dividerOrBorder
        )
    }

    val customFont = appTheme.getCustomFontFamily(enabled = true)
    val typography = if (customFont != null) {
        Typography(
            headlineMedium = TextStyle(fontFamily = customFont, fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 32.sp),
            titleLarge = TextStyle(fontFamily = customFont, fontWeight = FontWeight.Bold, fontSize = 20.sp, lineHeight = 26.sp),
            titleMedium = TextStyle(fontFamily = customFont, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, lineHeight = 22.sp),
            bodyLarge = TextStyle(fontFamily = customFont, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 22.sp),
            bodyMedium = TextStyle(fontFamily = customFont, fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 19.sp),
            labelMedium = TextStyle(fontFamily = customFont, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp)
        )
    } else {
        Typography
    }

    CompositionLocalProvider(LocalAppThemePalette provides animatedPalette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = typography,
            content = content
        )
    }
}
