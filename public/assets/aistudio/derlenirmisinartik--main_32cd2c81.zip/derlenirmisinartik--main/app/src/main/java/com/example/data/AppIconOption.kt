package com.example.data

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log

enum class AppIconOption(
    val id: String,
    val aliasName: String,
    val displayName: String,
    val description: String
) {
    DEFAULT(
        id = "default",
        aliasName = "LauncherDefault",
        displayName = "Klasik Pembe Sakura (Varsayılan)",
        description = "Geleneksel pembe kiraz çiçeği launcher simgesi"
    ),
    NEON(
        id = "neon",
        aliasName = "LauncherNeon",
        displayName = "Neon Cyberpunk Sakura",
        description = "Elektrik pembe ve neon mavi temalı simge"
    ),
    DARK(
        id = "dark",
        aliasName = "LauncherDark",
        displayName = "Yozakura Gece Mehtabı",
        description = "Koyu mor ve gümüş ay ışığı simgesi"
    ),
    GOLDEN(
        id = "golden",
        aliasName = "LauncherGolden",
        displayName = "Altın Sonbahar Sakura",
        description = "Kehribar ve somon tonlarında sonbahar simgesi"
    ),
    BERSERK_GUTS(
        id = "berserk_guts",
        aliasName = "LauncherBerserkGuts",
        displayName = "Berserk - Kara Kılıçlı (Guts)",
        description = "Kurban Mührü ve Ejderhakatan kılıcı simgesi"
    ),
    BERSERK_GRIFFITH(
        id = "berserk_griffith",
        aliasName = "LauncherGriffith",
        displayName = "Berserk - Işığın Şahini (Griffith)",
        description = "Şahin kanatları ve gümüş zırh arması"
    ),
    EVANGELION_01(
        id = "evangelion_01",
        aliasName = "LauncherEvangelion",
        displayName = "Neon Genesis Evangelion (EVA-01)",
        description = "Mor, neon yeşil ve AT-Field mecha simgesi"
    ),
    CHAINSAW_MAN(
        id = "chainsaw_man",
        aliasName = "LauncherChainsaw",
        displayName = "Chainsaw Man (Denji)",
        description = "Testere dişi ve turuncu kıvılcımlar simgesi"
    ),
    COWBOY_BEBOP(
        id = "cowboy_bebop",
        aliasName = "LauncherCowboyBebop",
        displayName = "Cowboy Bebop (Spike & Faye)",
        description = "Retro siberpunk ve Swordfish II yıldız simgesi"
    );

    companion object {
        fun fromId(id: String?): AppIconOption {
            return entries.find { it.id == id } ?: DEFAULT
        }
    }
}

object AppIconManager {
    private const val TAG = "AppIconManager"
    private const val PREFS_NAME = "sakura_app_icon_prefs"
    private const val KEY_ICON = "selected_app_icon_id"

    fun loadSelectedIcon(context: Context): AppIconOption {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_ICON, AppIconOption.DEFAULT.id)
        return AppIconOption.fromId(raw)
    }

    fun applyAppIcon(context: Context, option: AppIconOption) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_ICON, option.id).apply()

        val pm = context.packageManager
        val pkgName = context.packageName

        AppIconOption.entries.forEach { opt ->
            val targetState = if (opt == option) {
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            } else {
                PackageManager.COMPONENT_ENABLED_STATE_DISABLED
            }

            val candidateComponents = listOf(
                ComponentName(pkgName, "com.example.${opt.aliasName}"),
                ComponentName(pkgName, "$pkgName.${opt.aliasName}"),
                ComponentName("com.example", "com.example.${opt.aliasName}")
            )

            var applied = false
            for (comp in candidateComponents) {
                try {
                    pm.setComponentEnabledSetting(
                        comp,
                        targetState,
                        PackageManager.DONT_KILL_APP
                    )
                    applied = true
                } catch (e: Exception) {
                    Log.v(TAG, "Component ${comp.className} setting attempt: ${e.message}")
                }
            }
            if (!applied) {
                Log.w(TAG, "Could not set component state for alias: ${opt.aliasName}")
            }
        }
    }
}
