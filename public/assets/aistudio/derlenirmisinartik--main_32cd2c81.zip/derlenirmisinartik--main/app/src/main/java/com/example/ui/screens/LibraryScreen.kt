package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.PlaylistAdd
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FeatureTogglesConfig
import com.example.data.PlayCountManager
import com.example.data.UserPlaylist
import com.example.downloader.LikedSongsSourceType
import com.example.downloader.SavedMediaResult
import com.example.ui.components.LibraryDoctorCard
import com.example.ui.components.OfflineTagEditorDialog
import com.example.ui.components.OptimizedThumbnailImage
import com.example.ui.components.SakuraMusicStatsCard
import com.example.ui.components.rememberProgressiveWindowState
import com.example.ui.theme.LocalAppThemePalette

@Composable
fun LibraryScreen(
    downloadedTracks: List<SavedMediaResult>,
    playlists: List<UserPlaylist>,
    currentPlayingTrackId: String?,
    featureToggles: FeatureTogglesConfig = FeatureTogglesConfig(),
    playCountManager: PlayCountManager? = null,
    onUpdateFeatureToggles: ((FeatureTogglesConfig) -> FeatureTogglesConfig) -> Unit = {},
    onPlaySavedTrack: (SavedMediaResult) -> Unit,
    onDeleteSavedTrack: (SavedMediaResult) -> Unit,
    onAddTrackToPlaylist: (String, SavedMediaResult) -> Unit,
    onUpdateTrackMetadata: (SavedMediaResult, String, String, String, String?) -> Unit = { _, _, _, _, _ -> },
    onAutoFetchYoutubeTitle: (SavedMediaResult, (String, String) -> Unit) -> Unit = { _, _ -> },
    onRunLibraryDoctor: () -> Unit = {},
    onRefreshLibrary: () -> Unit,
    onDownloadAccountLibraryWithCookies: (LikedSongsSourceType) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val palette = LocalAppThemePalette.current
    var trackForPlaylistModal by remember { mutableStateOf<SavedMediaResult?>(null) }
    var trackForTagEditor by remember { mutableStateOf<SavedMediaResult?>(null) }

    val listState = rememberLazyListState()
    val headerCount = 3 +
        (if (playCountManager != null && featureToggles.musicStatsEnabled) 1 else 0) +
        (if (featureToggles.libraryDoctorEnabled) 1 else 0)

    // İlk başta yalnızca 5 şarkı yüklenir, aşağı kaydırdıkça 5'er açılır ve yukarıda kalanlar bellekten düşürülür
    val windowState = rememberProgressiveWindowState(
        listState = listState,
        totalItemsCount = downloadedTracks.size,
        headerItemsOffset = headerCount,
        initialBatchSize = 5,
        stepBatchSize = 5,
        activeWindowBuffer = 1
    )

    val displayedTracks = remember(downloadedTracks, windowState.loadedCount) {
        downloadedTracks.take(windowState.loadedCount)
    }

    LazyColumn(
        state = listState,
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "lib_header", contentType = "header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Çevrimdışı Kitaplığım",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.onBackground
                    )
                    Text(
                        text = "${downloadedTracks.size} yerel ses dosyası (${displayedTracks.size} aktif yüklü)",
                        fontSize = 12.sp,
                        color = palette.onSurfaceMuted
                    )
                }

                IconButton(onClick = onRefreshLibrary) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Kitaplığı Yenile",
                        tint = palette.primaryAccent
                    )
                }
            }
        }

        // 3. Adım: Akıllı Kütüphane, İstatistik & Paylaşım Araçları (Aç / Kapa Hızlı Kontrol Paneli)
        item(key = "lib_step3_panel", contentType = "step3_panel") {
            var expandStep3Toggles by remember { mutableStateOf(false) }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.surfaceContainer)
                    .border(1.dp, palette.primaryAccent.copy(alpha = 0.45f), RoundedCornerShape(18.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expandStep3Toggles = !expandStep3Toggles },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "3. Adım: Akıllı Kütüphane & Araçlar (Aç / Kapa)",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.onSurface
                        )
                        Text(
                            text = if (expandStep3Toggles) "Modülleri aşağıdan tek dokunuşla açıp kapatabilirsiniz"
                            else "İstatistik, Kütüphane Doktoru, Etiket Düzenleyici, Auto-Play & Söz Kartı (Dokun: Aç/Kapa)",
                            fontSize = 11.sp,
                            color = palette.primaryAccent
                        )
                    }
                    TextButton(onClick = { expandStep3Toggles = !expandStep3Toggles }) {
                        Text(
                            text = if (expandStep3Toggles) "Gizle" else "Aç / Kapa",
                            fontWeight = FontWeight.Bold,
                            color = palette.primaryAccent
                        )
                    }
                }

                if (expandStep3Toggles) {
                    LibraryStep3ToggleRow(
                        title = "Müzik Dinleme İstatistikleri & Özet (Wrapped)",
                        checked = featureToggles.musicStatsEnabled,
                        onCheckedChange = { enabled ->
                            onUpdateFeatureToggles { it.copy(musicStatsEnabled = enabled) }
                        }
                    )
                    LibraryStep3ToggleRow(
                        title = "Kütüphane Doktoru (Kopya & 'Parça X' İsim Onarıcı)",
                        checked = featureToggles.libraryDoctorEnabled,
                        onCheckedChange = { enabled ->
                            onUpdateFeatureToggles { it.copy(libraryDoctorEnabled = enabled) }
                        }
                    )
                    LibraryStep3ToggleRow(
                        title = "Çevrimdışı ID3 Etiket, İsim & Kapak Düzenleyici",
                        checked = featureToggles.tagEditorEnabled,
                        onCheckedChange = { enabled ->
                            onUpdateFeatureToggles { it.copy(tagEditorEnabled = enabled) }
                        }
                    )
                    LibraryStep3ToggleRow(
                        title = "Akıllı Otomatik Sıradaki Şarkı (Smart Auto-Play)",
                        checked = featureToggles.smartAutoplayEnabled,
                        onCheckedChange = { enabled ->
                            onUpdateFeatureToggles { it.copy(smartAutoplayEnabled = enabled) }
                        }
                    )
                    LibraryStep3ToggleRow(
                        title = "Şarkı Sözü Kartı Oluşturucu & Paylaşım",
                        checked = featureToggles.lyricCardGeneratorEnabled,
                        onCheckedChange = { enabled ->
                            onUpdateFeatureToggles { it.copy(lyricCardGeneratorEnabled = enabled) }
                        }
                    )
                }
            }
        }

        // Sakura Müzik İstatistikleri (Wrapped) - Aç/Kapa
        if (playCountManager != null && featureToggles.musicStatsEnabled) {
            item(key = "lib_stats_card", contentType = "stats_card") {
                SakuraMusicStatsCard(
                    downloadedTracks = downloadedTracks,
                    playCountManager = playCountManager,
                    isEnabled = featureToggles.musicStatsEnabled,
                    onToggleEnabled = { enabled ->
                        onUpdateFeatureToggles { it.copy(musicStatsEnabled = enabled) }
                    }
                )
            }
        }

        // Kütüphane Doktoru & İsim Onarıcı - Aç/Kapa
        if (featureToggles.libraryDoctorEnabled) {
            item(key = "lib_doctor_card", contentType = "doctor_card") {
                LibraryDoctorCard(
                    downloadedTracks = downloadedTracks,
                    isEnabled = featureToggles.libraryDoctorEnabled,
                    onToggleEnabled = { enabled ->
                        onUpdateFeatureToggles { it.copy(libraryDoctorEnabled = enabled) }
                    },
                    onRunDoctorCleanup = onRunLibraryDoctor
                )
            }
        }

        item(key = "lib_cookie_sync_btn", contentType = "action_btn") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onDownloadAccountLibraryWithCookies(LikedSongsSourceType.YOUTUBE_MUSIC) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.primaryAccent)
                ) {
                    Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("YT Müzik (LM)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                Button(
                    onClick = { onDownloadAccountLibraryWithCookies(LikedSongsSourceType.YOUTUBE_VIDEOS) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.surfaceContainer)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp), tint = palette.onSurface)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("YT Videolar (LL)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = palette.onSurface)
                }
            }
        }

        if (downloadedTracks.isEmpty()) {
            item(key = "lib_empty", contentType = "empty") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(palette.surfaceContainer)
                        .padding(28.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Henüz çevrimdışı kitaplığınızda şarkı bulunmuyor.",
                        color = palette.onSurfaceMuted
                    )
                }
            }
        } else {
            itemsIndexed(
                items = displayedTracks,
                key = { _, saved -> saved.audioFile.absolutePath },
                contentType = { _, _ -> "library_track_row" }
            ) { index, saved ->
                val isPlayingThis = currentPlayingTrackId == saved.trackInfo.id
                val isInActiveWindow = windowState.isTrackInActiveMemoryWindow(index)
                val fileInfoLabel = remember(saved.audioFile.absolutePath) {
                    "${saved.audioFile.extension.uppercase()} • ${saved.audioFile.length() / 1024} KB"
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            if (isPlayingThis) palette.primaryAccent.copy(alpha = 0.16f)
                            else palette.surfaceContainer
                        )
                        .border(
                            width = 1.dp,
                            color = if (isPlayingThis) palette.primaryAccent else palette.dividerOrBorder,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable { onPlaySavedTrack(saved) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val coverModel = saved.coverFile ?: saved.trackInfo.thumbnailUrl
                    OptimizedThumbnailImage(
                        model = coverModel,
                        contentDescription = saved.trackInfo.title,
                        isWithinActiveWindow = isInActiveWindow,
                        fallbackIcon = Icons.Default.MusicNote,
                        fallbackTint = palette.primaryAccent,
                        backgroundColor = palette.surfaceVariant,
                        iconSize = 24.dp,
                        targetPixelSize = 128,
                        modifier = Modifier
                            .size(54.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = saved.trackInfo.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = saved.trackInfo.artist,
                            fontSize = 13.sp,
                            color = palette.onSurfaceMuted,
                            maxLines = 1
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = fileInfoLabel,
                            fontSize = 11.sp,
                            color = palette.primaryAccent
                        )
                    }

                    if (featureToggles.tagEditorEnabled) {
                        IconButton(onClick = { trackForTagEditor = saved }) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Etiket & İsim Düzenle",
                                tint = palette.primaryAccent
                            )
                        }
                    }

                    IconButton(onClick = { trackForPlaylistModal = saved }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.PlaylistAdd,
                            contentDescription = "Listeye Ekle",
                            tint = palette.secondaryAccent
                        )
                    }

                    IconButton(onClick = { onDeleteSavedTrack(saved) }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Sil",
                            tint = palette.tertiaryAccent
                        )
                    }

                    IconButton(onClick = { onPlaySavedTrack(saved) }) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Çal",
                            tint = palette.primaryAccent
                        )
                    }
                }
            }
        }
    }

    val editingTrack = trackForTagEditor
    if (editingTrack != null && featureToggles.tagEditorEnabled) {
        OfflineTagEditorDialog(
            saved = editingTrack,
            onSaveMetadata = { newTitle, newArtist, newAlbum, newCoverUrl ->
                onUpdateTrackMetadata(editingTrack, newTitle, newArtist, newAlbum, newCoverUrl)
            },
            onAutoFetchYoutubeTitle = onAutoFetchYoutubeTitle,
            onDismiss = { trackForTagEditor = null }
        )
    }

    val modalTrack = trackForPlaylistModal
    if (modalTrack != null) {
        AlertDialog(
            onDismissRequest = { trackForPlaylistModal = null },
            title = { Text("'${modalTrack.trackInfo.title}' Şarkısını Listeye Ekle") },
            text = {
                if (playlists.isEmpty()) {
                    Text("Henüz bir çalma listeniz yok. 'Listeler' sekmesinden yeni bir liste oluşturabilirsiniz.")
                } else {
                    LazyColumn(
                        modifier = Modifier.height(240.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(playlists, key = { it.id }, contentType = { "playlist_modal_btn" }) { playlist ->
                            Button(
                                onClick = {
                                    onAddTrackToPlaylist(playlist.id, modalTrack)
                                    trackForPlaylistModal = null
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("${playlist.name} (${playlist.tracks.size})")
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { trackForPlaylistModal = null }) {
                    Text("Kapat")
                }
            }
        )
    }
}

@Composable
private fun LibraryStep3ToggleRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalAppThemePalette.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.surfaceVariant.copy(alpha = 0.6f))
            .clickable { onCheckedChange(!checked) }
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = palette.onSurface,
            modifier = Modifier.weight(1f)
        )
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange
        )
    }
}
