package com.example

import android.app.Application
import android.util.Log
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.example.sync.AutoSyncScheduler
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File

class SakuraMusicApplication : Application(), ImageLoaderFactory {
    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    companion object {
        private const val TAG = "SakuraMusicApp"

        @Volatile
        var isYoutubeDLInitialized: Boolean = false
            private set

        @Volatile
        var isFFmpegInitialized: Boolean = false
            private set

        @Volatile
        var isAria2cInitialized: Boolean = false
            private set

        @Volatile
        var youtubeDLInitError: String? = null
            private set

        @Synchronized
        fun ensureYoutubeDLInitialized(appContext: android.content.Context): Boolean {
            if (isYoutubeDLInitialized) return true
            return try {
                YoutubeDL.getInstance().init(appContext)
                isYoutubeDLInitialized = true
                youtubeDLInitError = null
                try {
                    FFmpeg.getInstance().init(appContext)
                    isFFmpegInitialized = true
                } catch (e: Throwable) {
                    Log.w(TAG, "FFmpeg initialization failed: ${e.message}")
                    isFFmpegInitialized = false
                }
                try {
                    Aria2c.getInstance().init(appContext)
                    isAria2cInitialized = true
                } catch (e: Throwable) {
                    Log.w(TAG, "Aria2c initialization failed: ${e.message}")
                    isAria2cInitialized = false
                }
                true
            } catch (e: YoutubeDLException) {
                youtubeDLInitError = e.localizedMessage ?: "YoutubeDL initialization error"
                Log.e(TAG, "Failed to initialize youtubedl-android", e)
                false
            } catch (e: Throwable) {
                youtubeDLInitError = e.localizedMessage ?: "Native binary initialization error"
                Log.e(TAG, "Unexpected error initializing youtubedl-android", e)
                false
            }
        }
    }

    override fun newImageLoader(): ImageLoader {
        return ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.45) // 45% of available app RAM for ultra-fast instant bitmap retrieval
                    .strongReferencesEnabled(true)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(File(cacheDir, "sakura_artwork_cache"))
                    .maxSizeBytes(250L * 1024L * 1024L) // 250 MB high-speed disk cache
                    .build()
            }
            .crossfade(120)
            .allowHardware(true)
            .respectCacheHeaders(false)
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        com.example.downloader.LyricsProvider.init(this)
        applicationScope.launch {
            // İlk ekran çizimi ve yerel 5 şarkının yüklenmesi tamamlanana kadar ağır native binary açılımını sıraya koy
            kotlinx.coroutines.delay(650L)
            val initialized = ensureYoutubeDLInitialized(this@SakuraMusicApplication)
            if (initialized) {
                Log.i(
                    TAG,
                    "ytdlnis engine initialized (YoutubeDL=$isYoutubeDLInitialized, FFmpeg=$isFFmpegInitialized, Aria2c=$isAria2cInitialized)"
                )
            }
            kotlinx.coroutines.delay(400L)
            AutoSyncScheduler.schedulePeriodicSync(this@SakuraMusicApplication)
        }
    }
}

