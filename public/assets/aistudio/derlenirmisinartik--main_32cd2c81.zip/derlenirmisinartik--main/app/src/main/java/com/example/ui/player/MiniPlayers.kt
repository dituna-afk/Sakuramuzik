package com.example.ui.player

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.downloader.MediaTrackInfo
import com.example.player.PlayerState
import com.example.ui.theme.LocalAppThemePalette
import com.example.ui.theme.getCustomFontFamily
import kotlinx.coroutines.launch
import kotlin.math.abs

@Composable
fun MiniPlayerBar(
    track: MediaTrackInfo,
    isPlaying: Boolean,
    progressFraction: Float,
    onTogglePlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit = {},
    onExpandClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalAppThemePalette.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val dragOffsetY = remember { Animatable(0f) }
    val dragOffsetX = remember { Animatable(0f) }
    val expandThresholdPx = with(density) { 46.dp.toPx() }
    val swipeSkipThresholdPx = with(density) { 56.dp.toPx() }
    val maxUpwardLiftPx = with(density) { 72.dp.toPx() }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 4.dp)
            .graphicsLayer {
                translationY = dragOffsetY.value
                translationX = dragOffsetX.value * 0.35f
                val liftFraction = (-dragOffsetY.value / maxUpwardLiftPx).coerceIn(0f, 1f)
                val scale = 1f + (liftFraction * 0.025f)
                scaleX = scale
                scaleY = scale
            }
            .clip(RoundedCornerShape(18.dp))
            .background(palette.surfaceContainer.copy(alpha = 0.97f))
            .border(1.dp, palette.dividerOrBorder, RoundedCornerShape(18.dp))
            .pointerInput(Unit) {
                var totalX = 0f
                var totalY = 0f
                detectDragGestures(
                    onDragStart = {
                        totalX = 0f
                        totalY = 0f
                    },
                    onDragEnd = {
                        if (totalY < -expandThresholdPx && abs(totalY) > abs(totalX)) {
                            scope.launch {
                                dragOffsetY.snapTo(0f)
                                dragOffsetX.snapTo(0f)
                            }
                            onExpandClick()
                        } else {
                            if (totalX < -swipeSkipThresholdPx && abs(totalX) > abs(totalY)) {
                                onSkipNext()
                            } else if (totalX > swipeSkipThresholdPx && abs(totalX) > abs(totalY)) {
                                onSkipPrevious()
                            }
                            scope.launch {
                                dragOffsetY.animateTo(
                                    0f,
                                    spring(
                                        dampingRatio = Spring.DampingRatioMediumBouncy,
                                        stiffness = Spring.StiffnessMediumLow
                                    )
                                )
                            }
                            scope.launch {
                                dragOffsetX.animateTo(
                                    0f,
                                    spring(
                                        dampingRatio = Spring.DampingRatioNoBouncy,
                                        stiffness = Spring.StiffnessMedium
                                    )
                                )
                            }
                        }
                    },
                    onDragCancel = {
                        scope.launch { dragOffsetY.animateTo(0f, spring()) }
                        scope.launch { dragOffsetX.animateTo(0f, spring()) }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        totalX += dragAmount.x
                        totalY += dragAmount.y
                        scope.launch {
                            if (abs(totalY) >= abs(totalX)) {
                                val dampedY = (totalY * 0.65f).coerceIn(-maxUpwardLiftPx, 12f)
                                dragOffsetY.snapTo(dampedY)
                            } else {
                                dragOffsetX.snapTo(totalX.coerceIn(-maxUpwardLiftPx, maxUpwardLiftPx))
                            }
                        }
                    }
                )
            }
            .clickable { onExpandClick() }
            .testTag("mini_player_bar")
    ) {
        // Subtle pill handle indicator at the top of the mini-player for slide-up affordance
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 5.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .width(28.dp)
                    .height(3.dp)
                    .clip(CircleShape)
                    .background(palette.onSurfaceMuted.copy(alpha = 0.32f))
            )
        }

        val customFontFamily = remember(palette.theme) { palette.theme.getCustomFontFamily(enabled = true) }
        val animeMeta = remember(palette.theme) { com.example.ui.theme.AnimeArtRegistry.getMetadata(palette.theme) }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(palette.surfaceVariant)
                    .border(
                        width = if (isPlaying) 1.5.dp else 1.dp,
                        color = if (isPlaying) palette.primaryAccent else palette.dividerOrBorder,
                        shape = RoundedCornerShape(12.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (!track.thumbnailUrl.isNullOrBlank()) {
                    AsyncImage(
                        model = track.thumbnailUrl,
                        contentDescription = track.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(46.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = null,
                        tint = palette.primaryAccent
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                if (animeMeta != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(bottom = 2.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(palette.primaryAccent.copy(alpha = 0.20f))
                                .padding(horizontal = 6.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = animeMeta.japaneseTitle,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = customFontFamily,
                                color = palette.primaryAccent,
                                maxLines = 1
                            )
                        }
                    }
                }
                Text(
                    text = track.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = customFontFamily,
                    color = palette.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = track.artist,
                    fontSize = 12.sp,
                    fontFamily = customFontFamily,
                    color = palette.onSurfaceMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(onClick = onTogglePlayPause) {
                Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Duraklat" else "Oynat",
                    tint = palette.primaryAccent
                )
            }

            IconButton(onClick = onSkipNext) {
                Icon(
                    imageVector = Icons.Default.SkipNext,
                    contentDescription = "Sonraki",
                    tint = palette.onSurface
                )
            }

            IconButton(onClick = onExpandClick) {
                Icon(
                    imageVector = Icons.Default.KeyboardArrowUp,
                    contentDescription = "Tam Ekran Oynatıcı",
                    tint = palette.onSurfaceMuted
                )
            }
        }

        LinearProgressIndicator(
            progress = { progressFraction.coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp),
            color = palette.primaryAccent,
            trackColor = palette.surfaceVariant
        )
    }
}

@Composable
fun MiniPlayer(
    playerState: PlayerState,
    onTogglePlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onExpand: () -> Unit,
    modifier: Modifier = Modifier
) {
    val current = playerState.currentTrack ?: return
    val fraction = if (playerState.durationMs > 0L) {
        (playerState.currentPositionMs.toFloat() / playerState.durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    MiniPlayerBar(
        track = current.trackInfo,
        isPlaying = playerState.isPlaying,
        progressFraction = fraction,
        onTogglePlayPause = onTogglePlayPause,
        onSkipNext = onSkipNext,
        onSkipPrevious = onSkipPrevious,
        onExpandClick = onExpand,
        modifier = modifier
    )
}
