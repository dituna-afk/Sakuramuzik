package com.example.viewmodel

import android.app.Application
import android.media.AudioAttributes
import android.media.MediaPlayer
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.SakuraMusicApplication
import com.example.data.AnimationPreferencesManager
import com.example.data.CookieStorageHelper
import com.example.data.EffectIntensityLevel
import com.example.data.OfflinePlaylistRepository
import com.example.data.PetalDensityLevel
import com.example.data.PlayCountManager
import com.example.data.SakuraAnimationConfig
import com.example.data.SakuraAnimationProfile
import com.example.data.SakuraTreeForm
import com.example.data.SakuraTreeStyle
import com.example.data.ThemeStorageHelper
import com.example.data.TopPlayedItem
import com.example.data.TransitionSpeedLevel
import com.example.data.UserPlaylist
import com.example.downloader.DownloadFormatOption
import com.example.downloader.LikedSongsSourceType
import com.example.downloader.DownloadListener
import com.example.downloader.DownloadPreferencesManager
import com.example.downloader.DownloadProgress
import com.example.downloader.LyricsProvider
import com.example.downloader.LyricsTranslator
import com.example.downloader.MediaMetadataManager
import com.example.downloader.MediaTrackInfo
import com.example.downloader.MultiThreadChunkedDownloader
import com.example.downloader.NetscapeCookieHelper
import com.example.downloader.PlatformSupportStatus
import com.example.downloader.SavedMediaResult
import com.example.downloader.StreamResolutionResult
import com.example.downloader.YTDlpResolver
import com.example.downloader.YouTubeStreamResolver
import com.example.downloader.YoutubeDLDownloadManager
import com.example.downloader.YoutubeDLDownloadState
import com.example.downloader.YoutubeDLUpdateResult
import com.example.downloader.YoutubeDLUpdater
import com.example.model.LrcParser
import com.example.model.LyricLine
import com.example.player.LocalDownloadsPlayer
import com.example.player.PlayerState
import com.example.sync.AutoSyncScheduler
import com.example.sync.SubscriptionSource
import com.example.sync.SubscriptionStorage
import com.example.ui.theme.AppTheme
import com.example.vault.VaultItem
import com.example.vault.VaultRepository
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

import com.example.downloader.TranslationEngine

enum class YtMusicTab {
    HOME,
    SEARCH,
    LIBRARY,
    PLAYLISTS,
    VAULT,
    COOKIES,
    SETTINGS
}

data class MusicUiState(
    val selectedTab: YtMusicTab = YtMusicTab.HOME,
    val selectedTheme: AppTheme = AppTheme.SAKURA_DARK,
    val animationConfig: SakuraAnimationConfig = SakuraAnimationConfig(),
    val youtubeUrlInput: String = "",
    val isResolvingStream: Boolean = false,
    val isFetchingLyrics: Boolean = false,
    val currentTrack: MediaTrackInfo? = null,
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val downloadProgress: DownloadProgress = DownloadProgress(),
    val youtubeDLState: YoutubeDLDownloadState = YoutubeDLDownloadState.Idle,
    val selectedDownloadFormat: DownloadFormatOption = DownloadFormatOption.AUDIO_M4A_HIGH,
    val isUpdatingYoutubeDL: Boolean = false,
    val youtubeDLVersion: String = "Yükleniyor...",
    val isYtdlpEngineReady: Boolean = false,
    val isFFmpegReady: Boolean = false,
    val isAria2cReady: Boolean = false,
    val currentUrlSupportStatus: PlatformSupportStatus? = null,
    val useAria2c: Boolean = false,
    val useSponsorBlock: Boolean = false,
    val embedMetadataAndThumb: Boolean = true,
    val writeAutoSubtitlesLrc: Boolean = true,
    val concurrentFragments: Int = 4,
    val lastSavedMedia: SavedMediaResult? = null,
    val downloadedTracks: List<SavedMediaResult> = emptyList(),
    val playlists: List<UserPlaylist> = emptyList(),
    val selectedPlaylistId: String? = null,
    val isPlaylistsGridView: Boolean = false,
    val searchQuery: String = "",
    val isSearchingCatalog: Boolean = false,
    val catalogSearchResults: List<MediaTrackInfo> = emptyList(),
    val resolvedPlaylistTitle: String? = null,
    val resolvedPlaylistTracks: List<MediaTrackInfo> = emptyList(),
    val selectedPlaylistTrackIds: Set<String> = emptySet(),
    val activeLikedSongsSource: LikedSongsSourceType = LikedSongsSourceType.YOUTUBE_MUSIC,
    val isBatchDownloadingPlaylist: Boolean = false,
    val batchDownloadCompletedCount: Int = 0,
    val batchDownloadTotalCount: Int = 0,
    val lrcRawText: String = LrcParser.SAMPLE_LRC,
    val parsedLyrics: List<LyricLine> = LrcParser.parse(LrcParser.SAMPLE_LRC),
    val activeLyricIndex: Int = -1,
    val isNowPlayingExpanded: Boolean = false,
    val statusBannerMessage: String? = null,
    val errorMessage: String? = null,
    val vaultItems: List<VaultItem> = emptyList(),
    val activeVaultItemForPlayback: VaultItem? = null,
    val subscriptions: List<SubscriptionSource> = emptyList(),
    val isAutoSyncWifiOnly: Boolean = true,
    val autoSyncIntervalHours: Long = 6L,
    val autoSyncIntervalMinutes: Long = 360L,
    val selectedTreeStyle: SakuraTreeStyle = SakuraTreeStyle.TRADITIONAL_SAKURA,
    val selectedTreeForm: SakuraTreeForm = SakuraTreeForm.CLASSIC_SWEEPING,
    val autoTranslateLyricsToTurkish: Boolean = true,
    val translationEngine: TranslationEngine = TranslationEngine.GOOGLE_TRANSLATE,
    val selectedAppIcon: com.example.data.AppIconOption = com.example.data.AppIconOption.DEFAULT,
    val volumeBoostPercent: Int = 100,
    val isVolumeBoosterEnabled: Boolean = false,
    val featureToggles: com.example.data.FeatureTogglesConfig = com.example.data.FeatureTogglesConfig(),
    val studioDspConfig: com.example.player.StudioDspConfig = com.example.player.StudioDspConfig(),
    val abLoopPointAMs: Long? = null,
    val abLoopPointBMs: Long? = null
)

class MusicPlayerViewModel(application: Application) : AndroidViewModel(application) {
    private val appContext = application.applicationContext
    private val themeStorage = ThemeStorageHelper(appContext)
    private val animationPrefs = AnimationPreferencesManager(appContext)
    private val cookieStorage = CookieStorageHelper(appContext)
    private val metadataManager = MediaMetadataManager(appContext)
    private val ytdlpResolver = YTDlpResolver(appContext)
    private val streamResolver = YouTubeStreamResolver(appContext)
    private val downloadPrefs = DownloadPreferencesManager(appContext)
    private val youtubeDLDownloadManager = YoutubeDLDownloadManager(
        context = appContext,
        metadataManager = metadataManager,
        streamResolver = streamResolver,
        preferencesManager = downloadPrefs
    )
    private val youtubeDLUpdater = YoutubeDLUpdater(appContext)
    private val chunkedDownloader = MultiThreadChunkedDownloader(threadCount = 4)
    private val playlistRepository = OfflinePlaylistRepository(appContext)
    private val vaultRepository = VaultRepository(appContext)
    private val subscriptionStorage = SubscriptionStorage(appContext)
    val playCountManager = PlayCountManager(appContext)
    val localDownloadsPlayer = LocalDownloadsPlayer(appContext)

    private var onlineMediaPlayer: MediaPlayer? = null
    private var onlineProgressJob: Job? = null
    private var catalogSearchJob: Job? = null
    private var activeDownloadJob: Job? = null
    private var activeStreamResolutionJob: Job? = null
    private var activeLyricsJob: Job? = null
    private var prewarmNextTrackJob: Job? = null
    private var lastObservedTrackId: String? = null
    private var countedPlayForTrackId: String? = null
    private var lastOnlineTickUptimeMs: Long = 0L
    private var lastOfflineTickUptimeMs: Long = 0L

    private fun checkAndRecordPlayCount(trackId: String, currentPositionMs: Long) {
        if (trackId.isBlank()) return
        if (currentPositionMs >= 3_000L && countedPlayForTrackId != trackId) {
            countedPlayForTrackId = trackId
            playCountManager.recordPlay(trackId)
        }
    }

    private val volumeBoostStorage = com.example.data.VolumeBoostStorageHelper(appContext)
    private val featureTogglesStorage = com.example.data.FeatureTogglesStorageHelper(appContext)
    private val studioDspStorage = com.example.player.StudioDspStorageHelper(appContext)

    private val _uiState = MutableStateFlow(
        MusicUiState(
            selectedTheme = themeStorage.loadTheme(),
            selectedTreeStyle = themeStorage.loadTreeStyle(),
            selectedTreeForm = themeStorage.loadTreeForm(),
            animationConfig = animationPrefs.loadConfig(),
            useAria2c = downloadPrefs.useAria2c,
            useSponsorBlock = downloadPrefs.useSponsorBlock,
            embedMetadataAndThumb = downloadPrefs.embedMetadataAndThumb,
            writeAutoSubtitlesLrc = downloadPrefs.writeAutoSubtitlesLrc,
            concurrentFragments = downloadPrefs.concurrentFragments,
            autoTranslateLyricsToTurkish = downloadPrefs.autoTranslateLyricsToTurkish,
            translationEngine = downloadPrefs.translationEngine,
            subscriptions = subscriptionStorage.loadSubscriptions(),
            isAutoSyncWifiOnly = subscriptionStorage.isAutoSyncWifiOnly(),
            autoSyncIntervalHours = subscriptionStorage.getSyncIntervalHours(),
            autoSyncIntervalMinutes = subscriptionStorage.getSyncIntervalMinutes(),
            selectedAppIcon = com.example.data.AppIconManager.loadSelectedIcon(appContext),
            volumeBoostPercent = volumeBoostStorage.getVolumeBoostPercent(),
            isVolumeBoosterEnabled = volumeBoostStorage.isVolumeBoosterEnabled(),
            featureToggles = featureTogglesStorage.loadConfig(),
            studioDspConfig = studioDspStorage.loadConfig(),
            selectedDownloadFormat = downloadPrefs.defaultDownloadFormat,
            isPlaylistsGridView = downloadPrefs.isPlaylistsGridLayout
        )
    )
    val uiState: StateFlow<MusicUiState> = _uiState.asStateFlow()

    fun setPlaylistsGridView(isGrid: Boolean) {
        downloadPrefs.isPlaylistsGridLayout = isGrid
        _uiState.update { it.copy(isPlaylistsGridView = isGrid) }
    }

    fun updateFeatureToggles(transform: (com.example.data.FeatureTogglesConfig) -> com.example.data.FeatureTogglesConfig) {
        val oldToggles = _uiState.value.featureToggles
        val updated = transform(oldToggles)
        featureTogglesStorage.saveConfig(updated)

        var dsp = _uiState.value.studioDspConfig
        var dspChanged = false
        if (updated.equalizerEnabled && !oldToggles.equalizerEnabled && !dsp.isEqualizerActive) {
            dsp = dsp.copy(isEqualizerActive = true)
            dspChanged = true
        }
        if (updated.pitchAndReverbEnabled && !oldToggles.pitchAndReverbEnabled && !dsp.isPitchReverbActive) {
            dsp = if (dsp.pitchReverbPreset == "Normal") {
                dsp.copy(
                    isPitchReverbActive = true,
                    pitchReverbPreset = "Slowed + Reverb",
                    tempoSpeed = 0.84f,
                    pitchFactor = 0.86f,
                    reverbLevel = 3
                )
            } else {
                dsp.copy(isPitchReverbActive = true)
            }
            dspChanged = true
        }
        if (updated.spatial8DAudioEnabled && !oldToggles.spatial8DAudioEnabled && !dsp.isSpatial8DActive) {
            dsp = dsp.copy(isSpatial8DActive = true)
            dspChanged = true
        }
        if (updated.vocalReducerEnabled && !oldToggles.vocalReducerEnabled && !dsp.isVocalReducerActive) {
            dsp = dsp.copy(isVocalReducerActive = true)
            dspChanged = true
        }
        if (updated.ambientMixerEnabled && !oldToggles.ambientMixerEnabled && !dsp.isAmbientMixerActive) {
            dsp = dsp.copy(isAmbientMixerActive = true)
            dspChanged = true
        }
        if (dspChanged) {
            studioDspStorage.saveConfig(dsp)
        }

        _uiState.update { state ->
            state.copy(
                featureToggles = updated,
                studioDspConfig = dsp,
                abLoopPointAMs = if (!updated.abLoopEnabled) null else state.abLoopPointAMs,
                abLoopPointBMs = if (!updated.abLoopEnabled) null else state.abLoopPointBMs
            )
        }
        com.example.player.StudioDspController.updateState(dsp, updated)
    }

    fun updateStudioDspConfig(transform: (com.example.player.StudioDspConfig) -> com.example.player.StudioDspConfig) {
        val updated = transform(_uiState.value.studioDspConfig)
        studioDspStorage.saveConfig(updated)
        _uiState.update { it.copy(studioDspConfig = updated) }
        com.example.player.StudioDspController.updateState(updated, _uiState.value.featureToggles)
    }

    fun setAbLoopPointA() {
        val pos = _uiState.value.currentPositionMs.coerceAtLeast(0L)
        _uiState.update {
            it.copy(
                abLoopPointAMs = pos,
                abLoopPointBMs = if (it.abLoopPointBMs != null && it.abLoopPointBMs <= pos) null else it.abLoopPointBMs,
                statusBannerMessage = "A-B Döngüsü A noktası ayarlandı (${LrcParser.formatTimestamp(pos)})."
            )
        }
    }

    fun setAbLoopPointB() {
        val pointA = _uiState.value.abLoopPointAMs ?: return
        val pos = _uiState.value.currentPositionMs.coerceAtLeast(pointA + 1000L)
        _uiState.update {
            it.copy(
                abLoopPointBMs = pos,
                statusBannerMessage = "A-B Döngüsü aktif: ${LrcParser.formatTimestamp(pointA)} - ${LrcParser.formatTimestamp(pos)}"
            )
        }
    }

    fun clearAbLoop() {
        _uiState.update {
            it.copy(
                abLoopPointAMs = null,
                abLoopPointBMs = null,
                statusBannerMessage = "A-B Nakarat Döngüsü temizlendi."
            )
        }
    }

    fun setVolumeBoost(percent: Int, enabled: Boolean) {
        val effectivePercent = if (enabled && percent <= 100) 160 else percent.coerceIn(100, 300)
        volumeBoostStorage.saveVolumeBoostPercent(effectivePercent)
        volumeBoostStorage.saveVolumeBoosterEnabled(enabled)

        _uiState.update {
            it.copy(
                volumeBoostPercent = effectivePercent,
                isVolumeBoosterEnabled = enabled,
                statusBannerMessage = if (enabled) "Ses yükseltici +${effectivePercent - 100}% ($effectivePercent%) olarak aktif edildi." else "Ses yükseltici kapatıldı."
            )
        }

        com.example.player.StudioDspController.updateVolumeBoostState(effectivePercent, enabled)
        onlineMediaPlayer?.audioSessionId?.let { session ->
            com.example.player.AudioEffectManager.applyOnlineVolumeBoost(session, effectivePercent, enabled)
        }
        localDownloadsPlayer.setVolumeBoost(effectivePercent, enabled)
    }

    fun selectAppIcon(option: com.example.data.AppIconOption) {
        com.example.data.AppIconManager.applyAppIcon(appContext, option)
        _uiState.update {
            it.copy(
                selectedAppIcon = option,
                statusBannerMessage = "Uygulama simgesi '${option.displayName}' olarak değiştirildi."
            )
        }
    }

    val offlinePlayerState: StateFlow<PlayerState> = localDownloadsPlayer.playerState
    val fftMagnitudes: StateFlow<FloatArray> = localDownloadsPlayer.fftMagnitudes

    init {
        // Sıralı (Staggered) Başlangıç Yükleme Hattı: İlk açılışta kasmayı önlemek için işlemler sırayla yüklenir
        viewModelScope.launch(Dispatchers.IO) {
            // 1. Aşama (0ms): Sadece yerel indirilen şarkıların önbellek/sidecar bilgisini hızlıca yükle
            val savedList = metadataManager.loadSavedDownloads()
            localDownloadsPlayer.syncQueue(savedList)
            _uiState.update { it.copy(downloadedTracks = savedList) }

            // 2. Aşama (+180ms): Çalma listeleri ve kasa öğelerini yükle
            delay(180L)
            playlistRepository.initializeAndMigrateIfNeeded()
            val vaultList = vaultRepository.loadVaultItems()
            _uiState.update { it.copy(vaultItems = vaultList) }

            // 3. Aşama (+450ms): ytdlnis / yt-dlp / FFmpeg native motor durumunu kontrol et
            delay(450L)
            val engineReady = SakuraMusicApplication.ensureYoutubeDLInitialized(appContext)
            val version = youtubeDLUpdater.getCurrentVersion()
            _uiState.update {
                it.copy(
                    isYtdlpEngineReady = engineReady,
                    isFFmpegReady = SakuraMusicApplication.isFFmpegInitialized,
                    isAria2cReady = SakuraMusicApplication.isAria2cInitialized,
                    youtubeDLVersion = version
                )
            }
        }

        viewModelScope.launch {
            youtubeDLDownloadManager.downloadState.collect { ytdlState ->
                _uiState.update { it.copy(youtubeDLState = ytdlState) }
                if (ytdlState is YoutubeDLDownloadState.Success) {
                    refreshDownloadedTracks()
                }
            }
        }

        viewModelScope.launch {
            chunkedDownloader.progressFlow.collect { progress ->
                _uiState.update { it.copy(downloadProgress = progress) }
            }
        }

        viewModelScope.launch {
            playlistRepository.playlistsFlow.collect { playlists ->
                _uiState.update { it.copy(playlists = playlists) }
            }
        }

        viewModelScope.launch {
            localDownloadsPlayer.playerState.collect { pState ->
                val savedMedia = pState.currentTrack
                val offlineTrack = savedMedia?.trackInfo
                if (savedMedia != null && offlineTrack != null) {
                    val currentId = offlineTrack.id.ifBlank { savedMedia.audioFile.absolutePath }
                    val isTrackChanged = (currentId != lastObservedTrackId)

                    if (pState.isPlaying) {
                        checkAndRecordPlayCount(currentId, pState.currentPositionMs)
                        val now = android.os.SystemClock.elapsedRealtime()
                        if (lastOfflineTickUptimeMs > 0L) {
                            val deltaMs = (now - lastOfflineTickUptimeMs).coerceIn(0L, 2000L)
                            if (deltaMs > 0L) {
                                playCountManager.addListeningTime(currentId, deltaMs)
                            }
                        }
                        lastOfflineTickUptimeMs = now
                    } else {
                        lastOfflineTickUptimeMs = 0L
                    }

                    if (isTrackChanged) {
                        lastObservedTrackId = currentId
                        countedPlayForTrackId = null
                        _uiState.update {
                            it.copy(
                                currentTrack = offlineTrack,
                                lastSavedMedia = savedMedia,
                                isPlaying = pState.isPlaying,
                                isBuffering = false,
                                currentPositionMs = pState.currentPositionMs,
                                durationMs = pState.durationMs,
                                abLoopPointAMs = null,
                                abLoopPointBMs = null
                            )
                        }
                        fetchLyricsForTrack(offlineTrack, savedMedia.audioFile)
                        prewarmNextQueueTrack(pState)
                    } else {
                        val curState = _uiState.value
                        val pointA = curState.abLoopPointAMs
                        val pointB = curState.abLoopPointBMs
                        if (curState.featureToggles.abLoopEnabled && pointA != null && pointB != null && pState.currentPositionMs >= pointB) {
                            localDownloadsPlayer.seekTo(pointA)
                        }
                        val lyricIdx = findActiveLyricIndex(curState.parsedLyrics, pState.currentPositionMs)
                        val posDelta = kotlin.math.abs(curState.currentPositionMs - pState.currentPositionMs)
                        if (curState.isPlaying != pState.isPlaying ||
                            posDelta >= 200L ||
                            curState.durationMs != pState.durationMs ||
                            curState.activeLyricIndex != lyricIdx
                        ) {
                            _uiState.update {
                                it.copy(
                                    currentTrack = offlineTrack,
                                    lastSavedMedia = savedMedia,
                                    isPlaying = pState.isPlaying,
                                    currentPositionMs = pState.currentPositionMs,
                                    durationMs = pState.durationMs,
                                    activeLyricIndex = lyricIdx
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    fun selectTab(tab: YtMusicTab) {
        _uiState.update { it.copy(selectedTab = tab) }
        if (tab == YtMusicTab.LIBRARY || tab == YtMusicTab.VAULT) {
            refreshDownloadedTracks()
        }
    }

    fun selectTheme(theme: AppTheme) {
        themeStorage.saveTheme(theme)
        // Tema değiştirildiğinde ağacın altın renginde veya eski stilde takılı kalmaması için otomatik temayla uyumlu moda geçirilir
        themeStorage.saveTreeStyle(SakuraTreeStyle.TRADITIONAL_SAKURA)
        _uiState.update {
            it.copy(
                selectedTheme = theme,
                selectedTreeStyle = SakuraTreeStyle.TRADITIONAL_SAKURA,
                statusBannerMessage = "Tema '${theme.displayName}' olarak güncellendi (Ağaç rengi temayla eşitlendi)."
            )
        }
    }

    fun selectTreeStyle(treeStyle: SakuraTreeStyle) {
        themeStorage.saveTreeStyle(treeStyle)
        _uiState.update {
            it.copy(
                selectedTreeStyle = treeStyle,
                statusBannerMessage = "Sakura Renk Stili '${treeStyle.displayName}' olarak ayarlandı."
            )
        }
    }

    fun selectTreeForm(treeForm: SakuraTreeForm) {
        themeStorage.saveTreeForm(treeForm)
        _uiState.update {
            it.copy(
                selectedTreeForm = treeForm,
                statusBannerMessage = "Sakura Ağaç Formu '${treeForm.displayName}' olarak ayarlandı."
            )
        }
    }

    fun selectAnimationProfile(profile: SakuraAnimationProfile) {
        val current = _uiState.value.animationConfig
        val updated = current.copy(
            profile = profile,
            petalDensity = profile.defaultDensity,
            transitionSpeed = profile.defaultSpeed,
            effectIntensity = profile.defaultIntensity
        )
        animationPrefs.saveConfig(updated)
        _uiState.update { it.copy(animationConfig = updated) }
    }

    fun setAnimationsMasterEnabled(enabled: Boolean) {
        val updated = _uiState.value.animationConfig.copy(masterEnabled = enabled)
        animationPrefs.saveConfig(updated)
        _uiState.update { it.copy(animationConfig = updated) }
    }

    fun selectPetalDensity(density: PetalDensityLevel) {
        val updated = _uiState.value.animationConfig.copy(petalDensity = density)
        animationPrefs.saveConfig(updated)
        _uiState.update { it.copy(animationConfig = updated) }
    }

    fun selectTransitionSpeed(speed: TransitionSpeedLevel) {
        val updated = _uiState.value.animationConfig.copy(transitionSpeed = speed)
        animationPrefs.saveConfig(updated)
        _uiState.update { it.copy(animationConfig = updated) }
    }

    fun selectEffectIntensity(intensity: EffectIntensityLevel) {
        val updated = _uiState.value.animationConfig.copy(effectIntensity = intensity)
        animationPrefs.saveConfig(updated)
        _uiState.update { it.copy(animationConfig = updated) }
    }

    fun setFloatingPetalsEnabled(enabled: Boolean) {
        val updated = _uiState.value.animationConfig.copy(floatingPetalsEnabled = enabled)
        animationPrefs.saveConfig(updated)
        _uiState.update { it.copy(animationConfig = updated) }
    }

    fun setAudioReactiveWavesEnabled(enabled: Boolean) {
        val updated = _uiState.value.animationConfig.copy(audioReactiveWavesEnabled = enabled)
        animationPrefs.saveConfig(updated)
        _uiState.update { it.copy(animationConfig = updated) }
    }

    fun setInteractiveBurstEnabled(enabled: Boolean) {
        val updated = _uiState.value.animationConfig.copy(interactiveBurstEnabled = enabled)
        animationPrefs.saveConfig(updated)
        _uiState.update { it.copy(animationConfig = updated) }
    }

    fun setScreenTransitionsEnabled(enabled: Boolean) {
        val updated = _uiState.value.animationConfig.copy(screenTransitionsEnabled = enabled)
        animationPrefs.saveConfig(updated)
        _uiState.update { it.copy(animationConfig = updated) }
    }

    fun setPowerSaveAutoReduce(enabled: Boolean) {
        val updated = _uiState.value.animationConfig.copy(powerSaveAutoReduce = enabled)
        animationPrefs.saveConfig(updated)
        _uiState.update { it.copy(animationConfig = updated) }
    }

    fun updateYoutubeUrlInput(input: String) {
        val support = if (input.isNotBlank()) ytdlpResolver.evaluateUrlSupport(input) else null
        _uiState.update {
            it.copy(
                youtubeUrlInput = input,
                currentUrlSupportStatus = support,
                errorMessage = null
            )
        }
    }

    fun selectDownloadFormat(format: DownloadFormatOption) {
        downloadPrefs.defaultDownloadFormat = format
        _uiState.update { it.copy(selectedDownloadFormat = format) }
    }

    fun setUseAria2c(enabled: Boolean) {
        downloadPrefs.useAria2c = enabled
        _uiState.update { it.copy(useAria2c = enabled) }
    }

    fun setUseSponsorBlock(enabled: Boolean) {
        downloadPrefs.useSponsorBlock = enabled
        _uiState.update { it.copy(useSponsorBlock = enabled) }
    }

    fun setEmbedMetadataAndThumb(enabled: Boolean) {
        downloadPrefs.embedMetadataAndThumb = enabled
        _uiState.update { it.copy(embedMetadataAndThumb = enabled) }
    }

    fun setWriteAutoSubtitlesLrc(enabled: Boolean) {
        downloadPrefs.writeAutoSubtitlesLrc = enabled
        _uiState.update { it.copy(writeAutoSubtitlesLrc = enabled) }
    }

    fun setConcurrentFragments(count: Int) {
        val clamped = count.coerceIn(1, 16)
        downloadPrefs.concurrentFragments = clamped
        _uiState.update { it.copy(concurrentFragments = clamped) }
    }

    fun updateYoutubeDLBinary(useNightly: Boolean = false) {
        if (_uiState.value.isUpdatingYoutubeDL) return
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isUpdatingYoutubeDL = true,
                    statusBannerMessage = "yt-dlp motoru güncelleniyor..."
                )
            }
            when (val res = youtubeDLUpdater.updateEngine(useNightly)) {
                is YoutubeDLUpdateResult.Updated -> {
                    _uiState.update {
                        it.copy(
                            isUpdatingYoutubeDL = false,
                            youtubeDLVersion = res.version,
                            statusBannerMessage = res.message
                        )
                    }
                }
                is YoutubeDLUpdateResult.AlreadyUpToDate -> {
                    _uiState.update {
                        it.copy(
                            isUpdatingYoutubeDL = false,
                            youtubeDLVersion = res.version,
                            statusBannerMessage = res.message
                        )
                    }
                }
                is YoutubeDLUpdateResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isUpdatingYoutubeDL = false,
                            errorMessage = res.errorMessage
                        )
                    }
                }
            }
        }
    }

    fun handleIncomingSharedUrl(sharedText: String, autoDownload: Boolean = true) {
        val extractedUrl = extractFirstHttpUrl(sharedText) ?: sharedText.trim()
        if (extractedUrl.isBlank()) return
        updateYoutubeUrlInput(extractedUrl)
        _uiState.update {
            it.copy(
                selectedTab = YtMusicTab.HOME,
                statusBannerMessage = "Paylaşılan bağlantı algılandı: $extractedUrl"
            )
        }
        if (autoDownload) {
            startYoutubeDLDownload(extractedUrl)
        } else {
            resolveAndPlayYouTubeInput(autoDownload = false)
        }
    }

    private fun extractFirstHttpUrl(text: String): String? {
        val regex = Regex("""https?://[^\s"'<>]+""")
        return regex.find(text)?.value
    }

    fun resolveAndPlayYouTubeInput(
        rawInput: String = "",
        autoDownload: Boolean = false,
        existingTrack: MediaTrackInfo? = null
    ) {
        stopAllPlayback()

        val targetUrl = (rawInput.ifBlank { _uiState.value.youtubeUrlInput }).trim()
        if (targetUrl.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Lütfen bir bağlantı veya şarkı adı girin.") }
            return
        }

        val initialTrack = existingTrack ?: MediaTrackInfo(
            id = streamResolver.extractVideoId(targetUrl) ?: targetUrl,
            title = "Medya Yükleniyor...",
            artist = "Sakura Player",
            durationSeconds = 0,
            thumbnailUrl = null,
            sourceUrl = targetUrl,
            streamUrl = ""
        )

        _uiState.update {
            it.copy(
                youtubeUrlInput = targetUrl,
                currentTrack = initialTrack,
                isBuffering = true,
                isPlaying = false,
                currentPositionMs = 0L,
                lrcRawText = "",
                parsedLyrics = emptyList(),
                activeLyricIndex = -1,
                errorMessage = null,
                statusBannerMessage = "Çözümleniyor..."
            )
        }

        val support = ytdlpResolver.evaluateUrlSupport(targetUrl)
        if (!support.isSupported) {
            _uiState.update {
                it.copy(
                    isBuffering = false,
                    errorMessage = support.reasonMessage
                )
            }
            return
        }

        val playlistId = streamResolver.extractPlaylistId(targetUrl)
        val videoId = streamResolver.extractVideoId(targetUrl)
        if (!playlistId.isNullOrBlank() && videoId.isNullOrBlank()) {
            resolvePlaylistInput(targetUrl)
            return
        }

        activeStreamResolutionJob?.cancel()
        activeStreamResolutionJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isResolvingStream = true,
                    errorMessage = null,
                    statusBannerMessage = "${support.platform.displayName} çözümleniyor..."
                )
            }
            val (_, savedCookies) = cookieStorage.loadCookies()
            val cookies = NetscapeCookieHelper.resolveActiveCookies(appContext, savedCookies)
            when (val res = streamResolver.resolveInput(targetUrl, cookies)) {
                is StreamResolutionResult.Success -> {
                    val track = res.trackInfo
                    _uiState.update {
                        it.copy(
                            isResolvingStream = false,
                            currentTrack = track,
                            statusBannerMessage = "Hazır: ${track.artist} - ${track.title}"
                        )
                    }
                    fetchLyricsForTrack(track, localFile = null)
                    if (autoDownload) {
                        startYoutubeDLDownload(
                            customUrl = track.sourceUrl.ifBlank { targetUrl },
                            existingTrack = track
                        )
                    } else {
                        playOnlineStream(track)
                    }
                }
                is StreamResolutionResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isResolvingStream = false,
                            isBuffering = false,
                            errorMessage = res.message
                        )
                    }
                }
            }
        }
    }

    private fun resolvePlaylistInput(playlistUrlOrId: String) {
        activeStreamResolutionJob?.cancel()
        activeStreamResolutionJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isResolvingStream = true,
                    errorMessage = null,
                    statusBannerMessage = "Çalma listesi (ytdlnis + çerezler ile) çözümleniyor..."
                )
            }
            val (_, savedCookies) = cookieStorage.loadCookies()
            val cookies = NetscapeCookieHelper.resolveActiveCookies(appContext, savedCookies)
            NetscapeCookieHelper.writeNetscapeCookieFile(appContext, cookies)
            val result = streamResolver.resolvePlaylist(playlistUrlOrId, cookies)
            if (result.tracks.isEmpty()) {
                _uiState.update {
                    it.copy(
                        isResolvingStream = false,
                        errorMessage = "Çalma listesinde indirilebilir parça bulunamadı. Özel/Beğenilenler listesi ise Çerez Yöneticisi'nden oturum açtığınızdan emin olun."
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isResolvingStream = false,
                        resolvedPlaylistTitle = result.title,
                        resolvedPlaylistTracks = result.tracks,
                        selectedPlaylistTrackIds = result.tracks.map { t -> t.id }.toSet(),
                        statusBannerMessage = "'${result.title}' listesinden ${result.tracks.size} parça bulundu. İstemediğiniz şarkıları eleyip indirmeyi başlatabilirsiniz."
                    )
                }
            }
        }
    }

    fun clearResolvedPlaylist() {
        _uiState.update {
            it.copy(
                resolvedPlaylistTitle = null,
                resolvedPlaylistTracks = emptyList(),
                selectedPlaylistTrackIds = emptySet(),
                isBatchDownloadingPlaylist = false
            )
        }
    }

    fun togglePlaylistTrackSelection(trackId: String) {
        _uiState.update { current ->
            val updated = current.selectedPlaylistTrackIds.toMutableSet()
            if (updated.contains(trackId)) {
                updated.remove(trackId)
            } else {
                updated.add(trackId)
            }
            current.copy(selectedPlaylistTrackIds = updated)
        }
    }

    fun selectAllPlaylistTracks(selectAll: Boolean) {
        _uiState.update { current ->
            val updated = if (selectAll) {
                current.resolvedPlaylistTracks.map { it.id }.toSet()
            } else {
                emptySet()
            }
            current.copy(selectedPlaylistTrackIds = updated)
        }
    }

    fun downloadAccountLibraryWithCookies(sourceType: LikedSongsSourceType = LikedSongsSourceType.YOUTUBE_MUSIC) {
        activeStreamResolutionJob?.cancel()
        activeStreamResolutionJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isResolvingStream = true,
                    errorMessage = null,
                    activeLikedSongsSource = sourceType,
                    statusBannerMessage = "ytdlnis ve çerezler ile ${sourceType.displayName} listesi taranıyor..."
                )
            }
            val (_, savedCookies) = cookieStorage.loadCookies()
            val cookies = NetscapeCookieHelper.resolveActiveCookies(appContext, savedCookies)
            if (cookies.isEmpty()) {
                _uiState.update {
                    it.copy(
                        isResolvingStream = false,
                        errorMessage = "Beğenilenler listesini görmek için lütfen önce Çerezler sekmesinden YouTube hesabınıza giriş yapın."
                    )
                }
                return@launch
            }

            NetscapeCookieHelper.writeNetscapeCookieFile(appContext, cookies)

            val combinedTracks = mutableListOf<MediaTrackInfo>()
            val seenIds = mutableSetOf<String>()

            val playlistTargets = if (sourceType == LikedSongsSourceType.YOUTUBE_MUSIC) {
                listOf(
                    "https://music.youtube.com/playlist?list=LM",
                    "VLLM",
                    "FEmusic_liked_videos"
                )
            } else {
                listOf(
                    "https://www.youtube.com/playlist?list=LL",
                    "VLLL"
                )
            }

            for (target in playlistTargets) {
                val res = streamResolver.resolvePlaylist(target, cookies)
                for (track in res.tracks) {
                    if (seenIds.add(track.id)) {
                        combinedTracks.add(track)
                    }
                }
                if (combinedTracks.isNotEmpty()) break
            }

            if (combinedTracks.isNotEmpty()) {
                val title = "${sourceType.displayName} (${combinedTracks.size} Parça)"
                _uiState.update {
                    it.copy(
                        isResolvingStream = false,
                        resolvedPlaylistTitle = title,
                        resolvedPlaylistTracks = combinedTracks,
                        selectedPlaylistTrackIds = combinedTracks.map { t -> t.id }.toSet(),
                        statusBannerMessage = "$title hazırlandı. İndirmek istemediklerinizi listeden çıkarıp 'Seçilenleri İndir' butonuna dokunun."
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        isResolvingStream = false,
                        errorMessage = "${sourceType.displayName} listesinde içerik bulunamadı. Lütfen Çerezler sekmesinden hesabınızı kontrol edip 'Çerezleri Yenile' butonuna dokunun."
                    )
                }
            }
        }
    }

    fun downloadSelectedPlaylistTracks() {
        val allTracks = _uiState.value.resolvedPlaylistTracks
        val selectedIds = _uiState.value.selectedPlaylistTrackIds
        val tracksToDownload = allTracks.filter { it.id in selectedIds }
        if (tracksToDownload.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "Lütfen indirmek için listeden en az bir şarkı seçin.") }
            return
        }
        if (_uiState.value.isBatchDownloadingPlaylist) return

        viewModelScope.launch {
            val (_, savedCookies) = cookieStorage.loadCookies()
            val cookies = NetscapeCookieHelper.resolveActiveCookies(appContext, savedCookies)
            NetscapeCookieHelper.writeNetscapeCookieFile(appContext, cookies)
            val format = _uiState.value.selectedDownloadFormat
            _uiState.update {
                it.copy(
                    isBatchDownloadingPlaylist = true,
                    batchDownloadCompletedCount = 0,
                    batchDownloadTotalCount = tracksToDownload.size,
                    statusBannerMessage = "Seçili ${tracksToDownload.size} parça indiriliyor (${format.displayName})..."
                )
            }

            var completed = 0
            for (track in tracksToDownload) {
                val rawUrl = track.sourceUrl.ifBlank { "https://www.youtube.com/watch?v=${track.id}" }
                val cleanUrl = if (track.id.length == 11) {
                    "https://www.youtube.com/watch?v=${track.id}"
                } else if (rawUrl.contains("watch?v=") && rawUrl.contains("&list=")) {
                    rawUrl.substringBefore("&list=")
                } else {
                    rawUrl
                }

                val state = youtubeDLDownloadManager.downloadTrack(
                    url = cleanUrl,
                    formatOption = format,
                    cookies = cookies,
                    existingTrackInfo = track
                )
                if (state is YoutubeDLDownloadState.Cancelled) {
                    break
                }
                if (state is YoutubeDLDownloadState.Success) {
                    completed++
                }
                _uiState.update {
                    it.copy(batchDownloadCompletedCount = completed)
                }
            }

            refreshDownloadedTracks()
            _uiState.update {
                it.copy(
                    isBatchDownloadingPlaylist = false,
                    statusBannerMessage = "Toplu indirme tamamlandı: $completed / ${tracksToDownload.size} parça cihazınıza kaydedildi."
                )
            }
        }
    }

    fun downloadAllResolvedPlaylistTracks() = downloadSelectedPlaylistTracks()

    fun startYoutubeDLDownload(
        customUrl: String? = null,
        existingTrack: MediaTrackInfo? = null
    ) {
        val targetUrl = (customUrl ?: _uiState.value.youtubeUrlInput.ifBlank {
            _uiState.value.currentTrack?.sourceUrl.orEmpty()
        }).trim()

        if (targetUrl.isEmpty()) {
            _uiState.update {
                it.copy(errorMessage = "İndirmek için önce bir bağlantı girin veya bir şarkı seçin.")
            }
            return
        }

        val playlistId = streamResolver.extractPlaylistId(targetUrl)
        val videoId = streamResolver.extractVideoId(targetUrl)
        val isPurePlaylist = (!playlistId.isNullOrBlank() && videoId.isNullOrBlank()) ||
            targetUrl.contains("playlist?list=") ||
            targetUrl.contains("music.youtube.com/playlist")

        if (isPurePlaylist) {
            activeStreamResolutionJob?.cancel()
            activeStreamResolutionJob = viewModelScope.launch {
                _uiState.update {
                    it.copy(
                        isResolvingStream = true,
                        statusBannerMessage = "Çalma listesi indirilmek üzere çözümleniyor..."
                    )
                }
                val (_, savedCookies) = cookieStorage.loadCookies()
                val cookies = NetscapeCookieHelper.resolveActiveCookies(appContext, savedCookies)
                NetscapeCookieHelper.writeNetscapeCookieFile(appContext, cookies)
                val result = streamResolver.resolvePlaylist(targetUrl, cookies)
                if (result.tracks.isNotEmpty()) {
                    _uiState.update {
                        it.copy(
                            isResolvingStream = false,
                            resolvedPlaylistTitle = result.title,
                            resolvedPlaylistTracks = result.tracks
                        )
                    }
                    downloadAllResolvedPlaylistTracks()
                } else {
                    _uiState.update {
                        it.copy(
                            isResolvingStream = false,
                            errorMessage = "Çalma listesindeki parçalar çözümlenemedi."
                        )
                    }
                }
            }
            return
        }

        val currentState = youtubeDLDownloadManager.downloadState.value
        val isAlreadyDownloading = currentState is YoutubeDLDownloadState.Initializing ||
            currentState is YoutubeDLDownloadState.FetchingInfo ||
            currentState is YoutubeDLDownloadState.Downloading ||
            currentState is YoutubeDLDownloadState.SavingMetadata

        if (activeDownloadJob?.isActive == true && isAlreadyDownloading) {
            return
        }

        activeDownloadJob?.cancel()
        activeDownloadJob = viewModelScope.launch {
            val (_, savedCookies) = cookieStorage.loadCookies()
            val cookies = NetscapeCookieHelper.resolveActiveCookies(appContext, savedCookies)
            NetscapeCookieHelper.writeNetscapeCookieFile(appContext, cookies)
            val format = _uiState.value.selectedDownloadFormat
            val trackToUse = existingTrack ?: _uiState.value.currentTrack?.takeIf {
                it.sourceUrl == targetUrl || it.id == targetUrl
            }

            val cleanSingleUrl = if (targetUrl.contains("watch?v=") && targetUrl.contains("&list=")) {
                targetUrl.substringBefore("&list=")
            } else targetUrl

            val finalState = youtubeDLDownloadManager.downloadTrack(
                url = cleanSingleUrl,
                formatOption = format,
                cookies = cookies,
                existingTrackInfo = trackToUse
            )

            when (finalState) {
                is YoutubeDLDownloadState.Success -> {
                    val saved = finalState.savedMedia
                    refreshDownloadedTracks()
                    val actualExt = saved.audioFile.extension.uppercase()
                    val opusFallbackNotice = if (format == DownloadFormatOption.AUDIO_OPUS_BEST &&
                        !saved.audioFile.extension.equals("opus", ignoreCase = true)
                    ) {
                        " • Bilgi: Bu videoda doğal Opus bulunamadı, en iyi $actualExt akışına geçildi (Tercihiniz Opus olarak korundu)."
                    } else ""

                    _uiState.update {
                        it.copy(
                            currentTrack = saved.trackInfo,
                            lastSavedMedia = saved,
                            statusBannerMessage = "İndirildi: ${saved.trackInfo.artist} - ${saved.trackInfo.title} ($actualExt)$opusFallbackNotice"
                        )
                    }
                    fetchLyricsForTrack(saved.trackInfo, saved.audioFile)
                }
                is YoutubeDLDownloadState.Error -> {
                    _uiState.update {
                        it.copy(
                            errorMessage = finalState.message +
                                (finalState.technicalDetails?.let { d -> "\nDetay: $d" } ?: "")
                        )
                    }
                }
                else -> Unit
            }
        }
    }

    fun cancelYoutubeDLDownload() {
        activeDownloadJob?.cancel()
        activeDownloadJob = null
        activeStreamResolutionJob?.cancel()
        activeStreamResolutionJob = null
        youtubeDLDownloadManager.cancelActiveDownload()
        chunkedDownloader.cancel()
        _uiState.update {
            it.copy(
                isResolvingStream = false,
                isBatchDownloadingPlaylist = false,
                isBuffering = false,
                statusBannerMessage = "İndirme ve çözümleme işlemi iptal edildi."
            )
        }
    }

    fun startCurrentTrackDownload() {
        val current = _uiState.value.currentTrack
        if (current != null) {
            startYoutubeDLDownload(
                customUrl = current.sourceUrl.ifBlank { "https://www.youtube.com/watch?v=${current.id}" },
                existingTrack = current
            )
        } else {
            startYoutubeDLDownload()
        }
    }

    fun cancelActiveDownload() {
        cancelYoutubeDLDownload()
    }

    fun startSampleDownload() {
        val current = _uiState.value.currentTrack
        if (current == null || !current.streamUrl.startsWith("http")) {
            startCurrentTrackDownload()
            return
        }

        viewModelScope.launch {
            val (_, cookies) = cookieStorage.loadCookies()
            val cookieHeader = NetscapeCookieHelper.buildCookieHeaderString(cookies)
            val musicDir = metadataManager.getAppMusicDirectory()
            val baseName = metadataManager.buildTrackBaseFileName(current)
            val destFile = File(musicDir, "$baseName.m4a")

            val result = chunkedDownloader.downloadFileSuspend(
                fileUrl = current.streamUrl,
                destinationFile = destFile,
                cookieHeader = cookieHeader,
                listener = object : DownloadListener {
                    override fun onProgress(progress: DownloadProgress) {
                        _uiState.update { it.copy(downloadProgress = progress) }
                    }

                    override fun onComplete(outputFile: File) = Unit
                    override fun onError(errorMessage: String) {
                        _uiState.update { it.copy(errorMessage = errorMessage) }
                    }
                }
            )

            result.onSuccess { file ->
                val savedRes = metadataManager.finalizeDownloadedMedia(file, current)
                savedRes.onSuccess { saved ->
                    refreshDownloadedTracks()
                    _uiState.update {
                        it.copy(
                            lastSavedMedia = saved,
                            statusBannerMessage = "Çoklu kanal indirmesi tamamlandı: ${saved.audioFile.name}"
                        )
                    }
                }
            }
        }
    }

    private fun stopOnlinePlaybackOnly() {
        onlineProgressJob?.cancel()
        onlineProgressJob = null
        val oldMp = onlineMediaPlayer
        onlineMediaPlayer = null
        if (oldMp != null) {
            viewModelScope.launch(Dispatchers.IO) {
                try {
                    com.example.player.AudioEffectManager.releaseOnlineEffects()
                } catch (_: Throwable) {
                }
                try {
                    com.example.player.StudioDspController.unbindMediaPlayer(oldMp)
                } catch (_: Throwable) {
                }
                try {
                    oldMp.reset()
                } catch (_: Exception) {
                }
                try {
                    oldMp.release()
                } catch (_: Exception) {
                }
            }
        }
    }

    fun stopAllPlayback() {
        countedPlayForTrackId = null
        stopOnlinePlaybackOnly()

        try {
            localDownloadsPlayer.stopPlayback()
        } catch (_: Exception) {
        }

        _uiState.update {
            it.copy(
                isPlaying = false,
                isBuffering = false,
                currentPositionMs = 0L,
                lrcRawText = "",
                parsedLyrics = emptyList(),
                activeLyricIndex = -1
            )
        }
    }

    fun playSavedTrack(saved: SavedMediaResult) {
        stopOnlinePlaybackOnly()
        val currentId = saved.trackInfo.id.ifBlank { saved.audioFile.absolutePath }
        lastObservedTrackId = currentId
        countedPlayForTrackId = null

        val allDownloads = _uiState.value.downloadedTracks
        val idx = allDownloads.indexOfFirst {
            it.audioFile.absolutePath == saved.audioFile.absolutePath
        }
        if (idx >= 0) {
            localDownloadsPlayer.playQueue(allDownloads, idx)
        } else {
            localDownloadsPlayer.playQueue(listOf(saved), 0)
        }
        _uiState.update {
            it.copy(
                currentTrack = saved.trackInfo,
                lastSavedMedia = saved,
                isPlaying = true,
                isBuffering = false,
                currentPositionMs = 0L,
                durationMs = (saved.trackInfo.durationSeconds * 1000L).coerceAtLeast(1L),
                abLoopPointAMs = null,
                abLoopPointBMs = null,
                errorMessage = null
            )
        }
        fetchLyricsForTrack(saved.trackInfo, saved.audioFile)
    }

    fun playTopPlayedTrack(item: TopPlayedItem) {
        val saved = item.savedMedia
        if (saved != null) {
            playSavedTrack(saved)
        } else if (!item.streamUrl.isNullOrBlank()) {
            val streamTrack = MediaTrackInfo(
                id = item.id,
                title = item.title,
                artist = item.artist,
                durationSeconds = 180,
                thumbnailUrl = item.thumbnailUrl,
                streamUrl = item.streamUrl,
                sourceUrl = item.streamUrl
            )
            playOnlineStream(streamTrack)
        } else {
            val streamTrack = MediaTrackInfo(
                id = item.id,
                title = item.title,
                artist = item.artist,
                durationSeconds = 180,
                thumbnailUrl = item.thumbnailUrl,
                sourceUrl = "https://www.youtube.com/watch?v=${item.id}",
                streamUrl = ""
            )
            resolveAndPlayYouTubeInput(rawInput = streamTrack.sourceUrl, autoDownload = false, existingTrack = streamTrack)
        }
    }

    fun playPlaylistQueue(tracks: List<SavedMediaResult>, startIndex: Int) {
        if (tracks.isEmpty()) return
        stopOnlinePlaybackOnly()
        val safeIdx = startIndex.coerceIn(0, tracks.lastIndex)
        val chosen = tracks[safeIdx]
        val currentId = chosen.trackInfo.id.ifBlank { chosen.audioFile.absolutePath }
        lastObservedTrackId = currentId
        countedPlayForTrackId = null

        localDownloadsPlayer.playQueue(tracks, safeIdx)
        _uiState.update {
            it.copy(
                currentTrack = chosen.trackInfo,
                lastSavedMedia = chosen,
                isPlaying = true,
                isBuffering = false,
                currentPositionMs = 0L,
                durationMs = (chosen.trackInfo.durationSeconds * 1000L).coerceAtLeast(1L),
                abLoopPointAMs = null,
                abLoopPointBMs = null,
                errorMessage = null
            )
        }
        fetchLyricsForTrack(chosen.trackInfo, chosen.audioFile)
    }

    fun playCatalogTrack(track: MediaTrackInfo, autoDownload: Boolean = false) {
        val existingLocal = _uiState.value.downloadedTracks.firstOrNull {
            it.trackInfo.id == track.id && it.audioFile.exists() && it.audioFile.length() >= MediaMetadataManager.MIN_VALID_AUDIO_BYTES
        }
        if (existingLocal != null && !autoDownload) {
            playSavedTrack(existingLocal)
            return
        }

        stopAllPlayback()
        val url = track.sourceUrl.ifBlank { "https://www.youtube.com/watch?v=${track.id}" }
        _uiState.update {
            it.copy(
                youtubeUrlInput = url,
                currentTrack = track,
                isBuffering = true
            )
        }
        if (autoDownload) {
            startYoutubeDLDownload(customUrl = url, existingTrack = track)
        } else {
            resolveAndPlayYouTubeInput(rawInput = url, autoDownload = false, existingTrack = track)
        }
    }

    private fun playOnlineStream(track: MediaTrackInfo) {
        val streamUrl = track.streamUrl
        if (!streamUrl.startsWith("http")) {
            _uiState.update {
                it.copy(errorMessage = "Çevrimiçi ses akışı adresi geçerli değil.")
            }
            return
        }

        stopAllPlayback()

        _uiState.update {
            it.copy(
                currentTrack = track,
                isBuffering = true,
                isPlaying = false,
                currentPositionMs = 0L,
                durationMs = track.durationSeconds * 1000L,
                errorMessage = null
            )
        }

        try {
            val (_, savedCookies) = cookieStorage.loadCookies()
            val activeCookies = NetscapeCookieHelper.resolveActiveCookies(appContext, savedCookies)
            val cookieHeader = NetscapeCookieHelper.buildCookieHeaderString(activeCookies, appContext)
            val headers = mutableMapOf(
                "User-Agent" to "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
                "Origin" to "https://music.youtube.com",
                "Referer" to "https://music.youtube.com/"
            )
            if (!cookieHeader.isNullOrBlank()) {
                headers["Cookie"] = cookieHeader
            }

            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(appContext, android.net.Uri.parse(streamUrl), headers)
                setOnPreparedListener { player ->
                    try {
                        val dur = player.duration.toLong().coerceAtLeast(track.durationSeconds * 1000L)
                        com.example.player.AudioEffectManager.applyOnlineVolumeBoost(
                            audioSessionId = player.audioSessionId,
                            percent = _uiState.value.volumeBoostPercent,
                            enabled = _uiState.value.isVolumeBoosterEnabled,
                            forceRecreate = true
                        )
                        com.example.player.StudioDspController.updateState(
                            _uiState.value.studioDspConfig,
                            _uiState.value.featureToggles
                        )
                        com.example.player.StudioDspController.bindMediaPlayer(player, player.audioSessionId)
                        player.start()
                        _uiState.update {
                            it.copy(
                                isBuffering = false,
                                isPlaying = true,
                                durationMs = dur
                            )
                        }
                        startOnlineProgressLoop()
                    } catch (_: Throwable) {
                    }
                }
                setOnCompletionListener {
                    _uiState.update {
                        it.copy(
                            isPlaying = false,
                            currentPositionMs = it.durationMs
                        )
                    }
                    onlineProgressJob?.cancel()
                    if (_uiState.value.featureToggles.smartAutoplayEnabled) {
                        triggerSmartAutoPlayAfterTrack(track)
                    }
                }
                setOnErrorListener { _, what, extra ->
                    _uiState.update {
                        it.copy(
                            isBuffering = false,
                            isPlaying = false,
                            errorMessage = "Çevrimiçi akış hatası ($what / $extra). İndirerek çevrimdışı dinleyebilirsiniz."
                        )
                    }
                    true
                }
                prepareAsync()
            }
            onlineMediaPlayer = mp
        } catch (e: Throwable) {
            _uiState.update {
                it.copy(
                    isBuffering = false,
                    isPlaying = false,
                    errorMessage = "Çevrimiçi oynatıcı başlatılamadı: ${e.localizedMessage}"
                )
            }
        }
    }

    private fun triggerSmartAutoPlayAfterTrack(finishedTrack: MediaTrackInfo) {
        viewModelScope.launch {
            val allDownloads = _uiState.value.downloadedTracks
            val candidateOffline = allDownloads.filter { it.trackInfo.id != finishedTrack.id }
            val sameArtistLocal = candidateOffline.firstOrNull {
                it.trackInfo.artist.equals(finishedTrack.artist, ignoreCase = true)
            } ?: candidateOffline.randomOrNull()

            if (sameArtistLocal != null) {
                _uiState.update {
                    it.copy(statusBannerMessage = "Akıllı Otomatik Oynatma: ${sameArtistLocal.trackInfo.artist} - ${sameArtistLocal.trackInfo.title}")
                }
                playSavedTrack(sameArtistLocal)
                return@launch
            }

            val (_, savedCookies) = cookieStorage.loadCookies()
            val cookies = NetscapeCookieHelper.resolveActiveCookies(appContext, savedCookies)
            val query = "${finishedTrack.artist} mix"
            val catalogCandidates = streamResolver.searchCatalog(query, cookies, maxResults = 6)
                .filter { it.id != finishedTrack.id }
            val nextOnline = catalogCandidates.firstOrNull()
            if (nextOnline != null) {
                _uiState.update {
                    it.copy(statusBannerMessage = "Akıllı Otomatik Oynatma: ${nextOnline.artist} - ${nextOnline.title}")
                }
                playCatalogTrack(nextOnline, autoDownload = false)
            }
        }
    }

    private fun startOnlineProgressLoop() {
        onlineProgressJob?.cancel()
        lastOnlineTickUptimeMs = android.os.SystemClock.elapsedRealtime()
        onlineProgressJob = viewModelScope.launch {
            while (isActive && onlineMediaPlayer != null) {
                val mp = onlineMediaPlayer
                if (mp != null) {
                    try {
                        if (mp.isPlaying) {
                            val now = android.os.SystemClock.elapsedRealtime()
                            val deltaMs = (now - lastOnlineTickUptimeMs).coerceIn(0L, 2000L)
                            lastOnlineTickUptimeMs = now

                            val pos = mp.currentPosition.toLong().coerceAtLeast(0L)
                            val curState = _uiState.value
                            val currentTrackId = curState.currentTrack?.id.orEmpty()

                            if (deltaMs > 0L) {
                                playCountManager.addListeningTime(currentTrackId, deltaMs)
                            }

                            val pointA = curState.abLoopPointAMs
                            val pointB = curState.abLoopPointBMs
                            if (curState.featureToggles.abLoopEnabled && pointA != null && pointB != null && pos >= pointB) {
                                mp.seekTo(pointA.toInt())
                            }
                            checkAndRecordPlayCount(currentTrackId, pos)
                            val lyricIdx = findActiveLyricIndex(curState.parsedLyrics, pos)
                            _uiState.update {
                                it.copy(
                                    currentPositionMs = pos,
                                    activeLyricIndex = lyricIdx
                                )
                            }
                        } else {
                            lastOnlineTickUptimeMs = android.os.SystemClock.elapsedRealtime()
                        }
                    } catch (_: Throwable) {
                    }
                }
                delay(250L)
            }
        }
    }

    private fun releaseOnlineMediaPlayer() {
        stopAllPlayback()
    }

    fun togglePlayPause() {
        val mp = onlineMediaPlayer
        if (mp != null) {
            try {
                if (mp.isPlaying) {
                    mp.pause()
                    _uiState.update { it.copy(isPlaying = false) }
                } else {
                    mp.start()
                    _uiState.update { it.copy(isPlaying = true) }
                    startOnlineProgressLoop()
                }
            } catch (_: Throwable) {
                stopOnlinePlaybackOnly()
            }
            return
        }
        localDownloadsPlayer.togglePlayPause()
    }

    fun seekTo(positionMs: Long) {
        val mp = onlineMediaPlayer
        if (mp != null) {
            try {
                val safe = positionMs.coerceIn(0L, _uiState.value.durationMs.coerceAtLeast(1L))
                mp.seekTo(safe.toInt())
                val lyricIdx = findActiveLyricIndex(_uiState.value.parsedLyrics, safe)
                _uiState.update {
                    it.copy(
                        currentPositionMs = safe,
                        activeLyricIndex = lyricIdx
                    )
                }
            } catch (_: Throwable) {
            }
            return
        }
        localDownloadsPlayer.seekTo(positionMs)
    }

    fun skipToNext() {
        localDownloadsPlayer.skipToNext()
    }

    fun skipToPrevious() {
        localDownloadsPlayer.skipToPrevious()
    }

    fun toggleShuffle() {
        localDownloadsPlayer.toggleShuffle()
    }

    fun cycleRepeatMode() {
        localDownloadsPlayer.cycleRepeatMode()
    }

    fun setPlaybackSpeed(speed: Float) {
        val clamped = speed.coerceIn(0.5f, 2.0f)
        com.example.player.StudioDspController.setBasePlaybackSpeed(clamped)
        onlineMediaPlayer?.let { mp ->
            try {
                val wasPlaying = mp.isPlaying
                mp.playbackParams = mp.playbackParams.setSpeed(clamped)
                if (!wasPlaying && mp.isPlaying) {
                    mp.pause()
                }
            } catch (_: Exception) {
            }
        }
        localDownloadsPlayer.setPlaybackSpeed(clamped)
    }

    fun setSleepTimer(minutes: Int?) {
        localDownloadsPlayer.setSleepTimer(minutes)
        _uiState.update {
            it.copy(
                statusBannerMessage = if (minutes != null) {
                    "Uyku zamanlayıcısı $minutes dakikaya ayarlandı."
                } else {
                    "Uyku zamanlayıcısı kapatıldı."
                }
            )
        }
    }

    fun updateSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
        catalogSearchJob?.cancel()
        if (query.trim().length >= 2) {
            catalogSearchJob = viewModelScope.launch {
                delay(450L)
                triggerCatalogSearch(query)
            }
        } else {
            _uiState.update { it.copy(catalogSearchResults = emptyList(), isSearchingCatalog = false) }
        }
    }

    fun triggerCatalogSearch(customQuery: String? = null) {
        val q = (customQuery ?: _uiState.value.searchQuery).trim()
        if (q.isEmpty()) return

        viewModelScope.launch {
            _uiState.update { it.copy(isSearchingCatalog = true) }
            val (_, cookies) = cookieStorage.loadCookies()
            val results = streamResolver.searchCatalog(q, cookies, maxResults = 15)
            _uiState.update {
                it.copy(
                    isSearchingCatalog = false,
                    catalogSearchResults = results
                )
            }
        }
    }

    fun refreshDownloadedTracks() {
        viewModelScope.launch {
            val savedList = metadataManager.loadSavedDownloads()
            val vaultList = vaultRepository.loadVaultItems()
            localDownloadsPlayer.syncQueue(savedList)
            _uiState.update {
                it.copy(
                    downloadedTracks = savedList,
                    vaultItems = vaultList
                )
            }
        }
    }

    fun updateSavedTrackMetadata(
        saved: SavedMediaResult,
        newTitle: String,
        newArtist: String,
        newAlbum: String,
        newCoverUrl: String?
    ) {
        viewModelScope.launch {
            val res = metadataManager.updateTrackMetadataAndRename(
                saved = saved,
                newTitle = newTitle,
                newArtist = newArtist,
                newAlbum = newAlbum,
                newCoverUrl = newCoverUrl
            )
            res.onSuccess { updated ->
                refreshDownloadedTracks()
                _uiState.update {
                    it.copy(
                        currentTrack = if (it.currentTrack?.id == saved.trackInfo.id) updated.trackInfo else it.currentTrack,
                        statusBannerMessage = "Etiket ve dosya adı güncellendi: ${updated.trackInfo.artist} - ${updated.trackInfo.title}"
                    )
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(errorMessage = "Etiket güncellenemedi: ${err.localizedMessage}")
                }
            }
        }
    }

    fun autoFetchYoutubeTitleForTrack(
        saved: SavedMediaResult,
        onResult: (String, String) -> Unit
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val idCandidate = saved.trackInfo.id.takeIf { it.length == 11 }
                ?: Regex("""\(([a-zA-Z0-9_-]{11})\)""").find(saved.trackInfo.title)?.groupValues?.getOrNull(1)
                ?: Regex("""\[([a-zA-Z0-9_-]{11})]""").find(saved.audioFile.name)?.groupValues?.getOrNull(1)

            val pair = if (idCandidate != null) {
                metadataManager.fetchOembedTitleAndArtist(idCandidate)
            } else {
                null
            }
            kotlinx.coroutines.withContext(Dispatchers.Main) {
                if (pair != null) {
                    onResult(pair.first, pair.second)
                } else {
                    onResult("", "")
                    _uiState.update {
                        it.copy(statusBannerMessage = "Bu dosya için YouTube kimliği bulunamadı, ismi elle düzenleyebilirsiniz.")
                    }
                }
            }
        }
    }

    fun runLibraryDoctor() {
        viewModelScope.launch {
            _uiState.update {
                it.copy(statusBannerMessage = "Kütüphane Doktoru taraması ve isim onarımı başlatıldı...")
            }
            val report = metadataManager.runLibraryDoctorCleanup()
            refreshDownloadedTracks()
            val freedKb = report.freedBytes / 1024L
            _uiState.update {
                it.copy(
                    statusBannerMessage = "Kütüphane Doktoru tamamlandı: ${report.repairedTitlesCount} isimsiz parça onarıldı, ${report.removedDuplicateCount} kopya ve ${report.removedCorruptedCount} bozuk dosya temizlendi ($freedKb KB boşaltıldı)."
                )
            }
        }
    }

    fun deleteDownloadedTrack(saved: SavedMediaResult) {
        viewModelScope.launch {
            val deleted = metadataManager.deleteSavedTrack(saved)
            if (deleted) {
                refreshDownloadedTracks()
                _uiState.update {
                    it.copy(statusBannerMessage = "'${saved.trackInfo.title}' silindi.")
                }
            }
        }
    }

    fun deleteVaultItem(item: VaultItem) {
        viewModelScope.launch {
            val deleted = vaultRepository.deleteVaultItem(item)
            if (deleted) {
                refreshDownloadedTracks()
                _uiState.update {
                    it.copy(
                        activeVaultItemForPlayback = if (it.activeVaultItemForPlayback?.id == item.id) null else it.activeVaultItemForPlayback,
                        statusBannerMessage = "'${item.title}' kasadan silindi."
                    )
                }
            }
        }
    }

    fun openVaultItemInExoPlayer(item: VaultItem) {
        releaseOnlineMediaPlayer()
        if (localDownloadsPlayer.playerState.value.isPlaying) {
            localDownloadsPlayer.togglePlayPause()
        }
        _uiState.update { it.copy(activeVaultItemForPlayback = item) }
    }

    fun closeVaultExoPlayer() {
        _uiState.update { it.copy(activeVaultItemForPlayback = null) }
    }

    fun createPlaylist(name: String, description: String, coverUri: String?) {
        viewModelScope.launch {
            val updated = playlistRepository.createPlaylist(name, description, coverUri)
            _uiState.update {
                it.copy(
                    playlists = updated,
                    statusBannerMessage = "'$name' çalma listesi oluşturuldu."
                )
            }
        }
    }

    fun updatePlaylistCover(playlistId: String, coverUri: String?) {
        viewModelScope.launch {
            val updated = playlistRepository.updatePlaylistCover(playlistId, coverUri)
            _uiState.update {
                it.copy(
                    playlists = updated,
                    statusBannerMessage = "Çalma listesi kapağı güncellendi."
                )
            }
        }
    }

    fun deletePlaylist(playlistId: String) {
        viewModelScope.launch {
            val updated = playlistRepository.deletePlaylist(playlistId)
            _uiState.update {
                it.copy(
                    playlists = updated,
                    selectedPlaylistId = if (it.selectedPlaylistId == playlistId) null else it.selectedPlaylistId,
                    statusBannerMessage = "Çalma listesi silindi."
                )
            }
        }
    }

    fun openPlaylistDetail(playlistId: String) {
        _uiState.update { it.copy(selectedPlaylistId = playlistId) }
    }

    fun closePlaylistDetail() {
        _uiState.update { it.copy(selectedPlaylistId = null) }
    }

    fun addTrackToPlaylist(playlistId: String, track: SavedMediaResult) {
        viewModelScope.launch {
            val updated = playlistRepository.addTrackToPlaylist(playlistId, track)
            _uiState.update {
                it.copy(
                    playlists = updated,
                    statusBannerMessage = "'${track.trackInfo.title}' listeye eklendi."
                )
            }
        }
    }

    fun removeTrackFromPlaylist(playlistId: String, audioFilePath: String) {
        viewModelScope.launch {
            val updated = playlistRepository.removeTrackFromPlaylist(playlistId, audioFilePath)
            _uiState.update {
                it.copy(
                    playlists = updated,
                    statusBannerMessage = "Şarkı listeden çıkarıldı."
                )
            }
        }
    }

    fun addSubscription(title: String, url: String, formatOption: DownloadFormatOption) {
        val updated = subscriptionStorage.addSubscription(title, url, formatOption.name)
        AutoSyncScheduler.schedulePeriodicSync(appContext)
        _uiState.update {
            it.copy(
                subscriptions = updated,
                statusBannerMessage = "'$title' otomatik senkronizasyona eklendi."
            )
        }
    }

    fun removeSubscription(id: String) {
        val updated = subscriptionStorage.removeSubscription(id)
        _uiState.update {
            it.copy(
                subscriptions = updated,
                statusBannerMessage = "Abonelik kaldırıldı."
            )
        }
    }

    fun toggleSubscription(id: String, enabled: Boolean) {
        val updated = subscriptionStorage.toggleSubscription(id, enabled)
        _uiState.update { it.copy(subscriptions = updated) }
    }

    fun setAutoSyncWifiOnly(wifiOnly: Boolean) {
        subscriptionStorage.setAutoSyncWifiOnly(wifiOnly)
        AutoSyncScheduler.schedulePeriodicSync(appContext)
        _uiState.update { it.copy(isAutoSyncWifiOnly = wifiOnly) }
    }

    fun setAutoSyncIntervalMinutes(minutes: Long) {
        val safeMinutes = minutes.coerceAtLeast(15L)
        subscriptionStorage.setSyncIntervalMinutes(safeMinutes)
        AutoSyncScheduler.schedulePeriodicSync(appContext)
        _uiState.update {
            it.copy(
                autoSyncIntervalMinutes = safeMinutes,
                autoSyncIntervalHours = (safeMinutes / 60L).coerceAtLeast(1L)
            )
        }
    }

    fun setAutoSyncIntervalHours(hours: Long) {
        setAutoSyncIntervalMinutes(hours * 60L)
    }

    fun triggerImmediateSubscriptionSync() {
        AutoSyncScheduler.triggerImmediateSync(appContext)
        _uiState.update {
            it.copy(statusBannerMessage = "Arka plan senkronizasyonu başlatıldı.")
        }
    }

    private fun prewarmNextQueueTrack(pState: PlayerState) {
        val queue = pState.queue
        if (queue.size <= 1) return
        val nextIdx = (pState.currentIndex + 1) % queue.size
        val nextSaved = queue.getOrNull(nextIdx) ?: return

        prewarmNextTrackJob?.cancel()
        prewarmNextTrackJob = viewModelScope.launch(Dispatchers.IO) {
            delay(350L)
            val curState = _uiState.value
            if (curState.featureToggles.dynamicCoverPaletteEnabled) {
                com.example.ui.theme.DynamicSakuraPaletteExtractor.prewarmPalette(
                    imageUrl = nextSaved.coverFile?.absolutePath ?: nextSaved.trackInfo.thumbnailUrl,
                    baseTheme = curState.selectedTheme
                )
            }
            val nextLrc = LyricsProvider.fetchSyncedLyrics(
                title = nextSaved.trackInfo.title,
                artist = nextSaved.trackInfo.artist,
                durationSeconds = nextSaved.trackInfo.durationSeconds,
                localAudioFile = nextSaved.audioFile
            )
            if (!nextLrc.isNullOrBlank() && downloadPrefs.autoTranslateLyricsToTurkish) {
                val parsed = LrcParser.parse(nextLrc)
                LyricsTranslator.translateLyricLinesToTurkish(parsed, downloadPrefs.translationEngine)
            }
        }
    }

    private fun fetchLyricsForTrack(track: MediaTrackInfo, localFile: File?) {
        activeLyricsJob?.cancel()

        // Fast-path: 0ms in-memory cache check before launching network/disk work
        val cachedRaw = LyricsProvider.getCachedRawLyrics(track.title, track.artist, localFile)
        if (!cachedRaw.isNullOrBlank()) {
            val baseParsed = LrcParser.parse(cachedRaw)
            val cachedTranslated = if (downloadPrefs.autoTranslateLyricsToTurkish) {
                LyricsTranslator.getCachedTranslation(baseParsed, downloadPrefs.translationEngine)
            } else null

            val immediateLines = cachedTranslated ?: baseParsed
            _uiState.update {
                it.copy(
                    isFetchingLyrics = false,
                    lrcRawText = cachedRaw,
                    parsedLyrics = immediateLines,
                    activeLyricIndex = findActiveLyricIndex(immediateLines, it.currentPositionMs)
                )
            }
            if (downloadPrefs.autoTranslateLyricsToTurkish && cachedTranslated == null) {
                activeLyricsJob = viewModelScope.launch(Dispatchers.IO) {
                    val translated = LyricsTranslator.translateLyricLinesToTurkish(baseParsed, downloadPrefs.translationEngine)
                    _uiState.update { state ->
                        if (state.currentTrack?.id == track.id) {
                            state.copy(
                                parsedLyrics = translated,
                                activeLyricIndex = findActiveLyricIndex(translated, state.currentPositionMs)
                            )
                        } else state
                    }
                }
            }
            return
        }

        activeLyricsJob = viewModelScope.launch(Dispatchers.IO) {
            _uiState.update {
                it.copy(
                    isFetchingLyrics = true,
                    lrcRawText = "",
                    parsedLyrics = emptyList(),
                    activeLyricIndex = -1
                )
            }
            val lrc = LyricsProvider.fetchSyncedLyrics(
                title = track.title,
                artist = track.artist,
                durationSeconds = track.durationSeconds,
                localAudioFile = localFile
            )
            if (!isActive) return@launch

            if (!lrc.isNullOrBlank()) {
                val initialParsed = LrcParser.parse(lrc)
                val cachedTr = if (downloadPrefs.autoTranslateLyricsToTurkish) {
                    LyricsTranslator.getCachedTranslation(initialParsed, downloadPrefs.translationEngine)
                } else null

                val firstStageLines = cachedTr ?: initialParsed
                // Stage 1: Show synced lyrics immediately without waiting for network translation
                _uiState.update { state ->
                    if (state.currentTrack?.id == track.id) {
                        state.copy(
                            isFetchingLyrics = false,
                            lrcRawText = lrc,
                            parsedLyrics = firstStageLines,
                            activeLyricIndex = findActiveLyricIndex(firstStageLines, state.currentPositionMs)
                        )
                    } else state
                }

                // Stage 2: Stream in Turkish translation asynchronously if not already cached
                if (downloadPrefs.autoTranslateLyricsToTurkish && cachedTr == null && isActive) {
                    val translated = LyricsTranslator.translateLyricLinesToTurkish(
                        initialParsed,
                        downloadPrefs.translationEngine
                    )
                    if (isActive) {
                        _uiState.update { state ->
                            if (state.currentTrack?.id == track.id) {
                                state.copy(
                                    parsedLyrics = translated,
                                    activeLyricIndex = findActiveLyricIndex(translated, state.currentPositionMs)
                                )
                            } else state
                        }
                    }
                }
            } else {
                _uiState.update { state ->
                    if (state.currentTrack?.id == track.id) {
                        state.copy(
                            isFetchingLyrics = false,
                            lrcRawText = "Söz bulunamadı.",
                            parsedLyrics = emptyList(),
                            activeLyricIndex = -1
                        )
                    } else state
                }
            }
        }
    }

    fun setAutoTranslateLyricsToTurkish(enabled: Boolean) {
        downloadPrefs.autoTranslateLyricsToTurkish = enabled
        _uiState.update {
            it.copy(
                autoTranslateLyricsToTurkish = enabled,
                statusBannerMessage = if (enabled) "Şarkı sözleri Türkçe'ye çevrilecek." else "Otomatik çeviri kapatıldı."
            )
        }
        val currentTrack = _uiState.value.currentTrack
        val currentMedia = _uiState.value.lastSavedMedia
        if (currentTrack != null) {
            fetchLyricsForTrack(currentTrack, currentMedia?.audioFile)
        }
    }

    fun setTranslationEngine(engine: TranslationEngine) {
        downloadPrefs.translationEngine = engine
        _uiState.update {
            it.copy(
                translationEngine = engine,
                statusBannerMessage = "Çeviri motoru '${engine.displayName}' olarak seçildi."
            )
        }
        val currentTrack = _uiState.value.currentTrack
        val currentMedia = _uiState.value.lastSavedMedia
        if (currentTrack != null) {
            fetchLyricsForTrack(currentTrack, currentMedia?.audioFile)
        }
    }

    fun updateLrcText(rawLrc: String) {
        val currentTrack = _uiState.value.currentTrack
        val currentMedia = _uiState.value.lastSavedMedia ?: _uiState.value.downloadedTracks.firstOrNull {
            it.trackInfo.id == currentTrack?.id ||
                (it.trackInfo.title.equals(currentTrack?.title, ignoreCase = true) &&
                    it.trackInfo.artist.equals(currentTrack?.artist, ignoreCase = true))
        }
        val audioFile = currentMedia?.audioFile

        if (currentTrack != null) {
            LyricsProvider.saveCustomLyrics(
                title = currentTrack.title,
                artist = currentTrack.artist,
                lrcText = rawLrc,
                localAudioFile = audioFile
            )
        }

        val parsed = LrcParser.parse(rawLrc)
        _uiState.update {
            it.copy(
                lrcRawText = rawLrc,
                parsedLyrics = parsed,
                activeLyricIndex = findActiveLyricIndex(parsed, it.currentPositionMs),
                statusBannerMessage = "Şarkı sözleri kalıcı olarak kaydedildi."
            )
        }

        if (downloadPrefs.autoTranslateLyricsToTurkish && currentTrack != null) {
            activeLyricsJob?.cancel()
            activeLyricsJob = viewModelScope.launch(Dispatchers.IO) {
                val translated = LyricsTranslator.translateLyricLinesToTurkish(parsed, downloadPrefs.translationEngine)
                _uiState.update { state ->
                    if (state.currentTrack?.id == currentTrack.id) {
                        state.copy(
                            parsedLyrics = translated,
                            activeLyricIndex = findActiveLyricIndex(translated, state.currentPositionMs)
                        )
                    } else state
                }
            }
        }
    }

    private fun findActiveLyricIndex(lyrics: List<LyricLine>, positionMs: Long): Int {
        if (lyrics.isEmpty()) return -1
        var low = 0
        var high = lyrics.lastIndex
        var result = -1
        while (low <= high) {
            val mid = (low + high) ushr 1
            if (lyrics[mid].timeMs <= positionMs) {
                result = mid
                low = mid + 1
            } else {
                high = mid - 1
            }
        }
        return result
    }

    fun setNowPlayingExpanded(expanded: Boolean) {
        _uiState.update { it.copy(isNowPlayingExpanded = expanded) }
    }

    fun dismissMessages() {
        _uiState.update {
            it.copy(
                statusBannerMessage = null,
                errorMessage = null
            )
        }
    }

    override fun onCleared() {
        releaseOnlineMediaPlayer()
        localDownloadsPlayer.release()
        super.onCleared()
    }
}
