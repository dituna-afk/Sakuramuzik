package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.downloader.MediaTrackInfo
import com.example.downloader.SavedMediaResult
import java.io.File
import java.util.UUID
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

data class UserPlaylist(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String = "",
    val coverUri: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val tracks: List<SavedMediaResult> = emptyList()
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val coverUri: String?,
    val createdAt: Long,
    val tracksJson: String
)

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun observeAllPlaylists(): Flow<List<PlaylistEntity>>

    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    suspend fun getAllPlaylists(): List<PlaylistEntity>

    @Query("SELECT * FROM playlists WHERE id = :playlistId LIMIT 1")
    suspend fun getPlaylistById(playlistId: String): PlaylistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdatePlaylist(playlist: PlaylistEntity)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylistById(playlistId: String)
}

@Database(entities = [PlaylistEntity::class], version = 1, exportSchema = false)
abstract class PlaylistDatabase : RoomDatabase() {
    abstract fun playlistDao(): PlaylistDao

    companion object {
        @Volatile
        private var INSTANCE: PlaylistDatabase? = null

        fun getInstance(context: Context): PlaylistDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    PlaylistDatabase::class.java,
                    "sakura_playlists.db"
                ).fallbackToDestructiveMigration().build().also { INSTANCE = it }
            }
        }
    }
}

class OfflinePlaylistRepository(context: Context) {
    private val appContext = context.applicationContext
    private val playlistDao = PlaylistDatabase.getInstance(appContext).playlistDao()
    private val legacyPrefs = appContext.getSharedPreferences(LEGACY_PREFS_NAME, Context.MODE_PRIVATE)

    val playlistsFlow: Flow<List<UserPlaylist>> = playlistDao.observeAllPlaylists().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun initializeAndMigrateIfNeeded() = withContext(Dispatchers.IO) {
        if (!legacyPrefs.getBoolean(KEY_MIGRATED_TO_ROOM, false)) {
            val rawLegacy = legacyPrefs.getString(KEY_PLAYLISTS_JSON, null)
            if (!rawLegacy.isNullOrBlank()) {
                try {
                    val arr = JSONArray(rawLegacy)
                    for (i in 0 until arr.length()) {
                        val obj = arr.optJSONObject(i) ?: continue
                        val playlist = parsePlaylistJson(obj)
                        playlistDao.insertOrUpdatePlaylist(playlist.toEntity())
                    }
                } catch (_: Exception) {
                }
            }
            legacyPrefs.edit().putBoolean(KEY_MIGRATED_TO_ROOM, true).apply()
        }
    }

    suspend fun loadPlaylists(): List<UserPlaylist> = withContext(Dispatchers.IO) {
        initializeAndMigrateIfNeeded()
        playlistDao.getAllPlaylists().map { it.toDomain() }
    }

    suspend fun createPlaylist(
        name: String,
        description: String,
        coverImageUri: String?
    ): List<UserPlaylist> = withContext(Dispatchers.IO) {
        val persistedCoverPath = persistCoverImageIfNeeded(coverImageUri)
        val newPlaylist = UserPlaylist(
            id = UUID.randomUUID().toString(),
            name = name.trim().ifEmpty { "Yeni Liste" },
            description = description.trim(),
            coverUri = persistedCoverPath,
            createdAt = System.currentTimeMillis(),
            tracks = emptyList()
        )
        playlistDao.insertOrUpdatePlaylist(newPlaylist.toEntity())
        loadPlaylists()
    }

    suspend fun updatePlaylistCover(
        playlistId: String,
        newCoverUri: String?
    ): List<UserPlaylist> = withContext(Dispatchers.IO) {
        val existing = playlistDao.getPlaylistById(playlistId)?.toDomain() ?: return@withContext loadPlaylists()
        val persistedCoverPath = persistCoverImageIfNeeded(newCoverUri)
        val updated = existing.copy(coverUri = persistedCoverPath)
        playlistDao.insertOrUpdatePlaylist(updated.toEntity())
        loadPlaylists()
    }

    suspend fun deletePlaylist(playlistId: String): List<UserPlaylist> = withContext(Dispatchers.IO) {
        playlistDao.deletePlaylistById(playlistId)
        loadPlaylists()
    }

    suspend fun addTrackToPlaylist(
        playlistId: String,
        track: SavedMediaResult
    ): List<UserPlaylist> = withContext(Dispatchers.IO) {
        val existing = playlistDao.getPlaylistById(playlistId)?.toDomain() ?: return@withContext loadPlaylists()
        val alreadyExists = existing.tracks.any {
            it.audioFile.absolutePath == track.audioFile.absolutePath ||
                (it.trackInfo.id.isNotBlank() && it.trackInfo.id == track.trackInfo.id)
        }
        if (!alreadyExists) {
            val updated = existing.copy(tracks = existing.tracks + track)
            playlistDao.insertOrUpdatePlaylist(updated.toEntity())
        }
        loadPlaylists()
    }

    suspend fun removeTrackFromPlaylist(
        playlistId: String,
        audioFilePath: String
    ): List<UserPlaylist> = withContext(Dispatchers.IO) {
        val existing = playlistDao.getPlaylistById(playlistId)?.toDomain() ?: return@withContext loadPlaylists()
        val updated = existing.copy(
            tracks = existing.tracks.filterNot { it.audioFile.absolutePath == audioFilePath }
        )
        playlistDao.insertOrUpdatePlaylist(updated.toEntity())
        loadPlaylists()
    }

    private fun persistCoverImageIfNeeded(uriString: String?): String? {
        if (uriString.isNullOrBlank()) return null
        if (uriString.startsWith("http://") || uriString.startsWith("https://")) return uriString
        val directFile = File(uriString)
        if (directFile.exists()) return directFile.absolutePath
        return try {
            val parsedUri = android.net.Uri.parse(uriString)
            val coversDir = File(appContext.filesDir, "playlist_covers").apply { mkdirs() }
            val destFile = File(coversDir, "cover_${System.currentTimeMillis()}.jpg")
            appContext.contentResolver.openInputStream(parsedUri)?.use { input ->
                destFile.outputStream().use { output ->
                    input.copyTo(output)
                }
            }
            if (destFile.exists() && destFile.length() > 0L) destFile.absolutePath else uriString
        } catch (_: Exception) {
            uriString
        }
    }

    private fun PlaylistEntity.toDomain(): UserPlaylist {
        return UserPlaylist(
            id = id,
            name = name,
            description = description,
            coverUri = coverUri,
            createdAt = createdAt,
            tracks = deserializeTracks(tracksJson)
        )
    }

    private fun UserPlaylist.toEntity(): PlaylistEntity {
        return PlaylistEntity(
            id = id,
            name = name,
            description = description,
            coverUri = coverUri,
            createdAt = createdAt,
            tracksJson = serializeTracks(tracks)
        )
    }

    private fun serializeTracks(tracks: List<SavedMediaResult>): String {
        val arr = JSONArray()
        tracks.forEach { saved ->
            val obj = JSONObject().apply {
                put("audioPath", saved.audioFile.absolutePath)
                put("coverPath", saved.coverFile?.absolutePath ?: "")
                put("mediaStoreUri", saved.mediaStoreUri ?: "")
                put("id", saved.trackInfo.id)
                put("title", saved.trackInfo.title)
                put("artist", saved.trackInfo.artist)
                put("album", saved.trackInfo.album)
                put("durationSec", saved.trackInfo.durationSeconds)
                put("thumbnailUrl", saved.trackInfo.thumbnailUrl ?: "")
                put("sourceUrl", saved.trackInfo.sourceUrl)
                put("streamUrl", saved.trackInfo.streamUrl)
                put("mimeType", saved.trackInfo.mimeType)
                put("bitrateKbps", saved.trackInfo.bitrateKbps)
            }
            arr.put(obj)
        }
        return arr.toString()
    }

    private fun deserializeTracks(json: String): List<SavedMediaResult> {
        if (json.isBlank()) return emptyList()
        return try {
            val internalDir = File(appContext.filesDir, "SakuraDownloads")
            val internalCoversDir = File(internalDir, "Covers")
            val arr = JSONArray(json)
            val list = mutableListOf<SavedMediaResult>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val rawAudioPath = obj.optString("audioPath", "")
                if (rawAudioPath.isBlank()) continue
                val originalAudioFile = File(rawAudioPath)
                val resolvedAudioFile = if (originalAudioFile.exists()) {
                    originalAudioFile
                } else {
                    val migratedCandidate = File(internalDir, originalAudioFile.name)
                    if (migratedCandidate.exists()) migratedCandidate else originalAudioFile
                }
                val audioPath = resolvedAudioFile.absolutePath

                val rawCoverPath = obj.optString("coverPath", "")
                val coverFile = if (rawCoverPath.isNotBlank()) {
                    val origCover = File(rawCoverPath)
                    when {
                        origCover.exists() -> origCover
                        File(internalCoversDir, origCover.name).exists() -> File(internalCoversDir, origCover.name)
                        else -> null
                    }
                } else null

                val trackInfo = MediaTrackInfo(
                    id = obj.optString("id", audioPath.hashCode().toString()),
                    title = obj.optString("title", resolvedAudioFile.nameWithoutExtension),
                    artist = obj.optString("artist", "Sakura Music"),
                    album = obj.optString("album", "Sakura Music"),
                    durationSeconds = obj.optLong("durationSec", 0L),
                    thumbnailUrl = coverFile?.absolutePath ?: obj.optString("thumbnailUrl", "").ifBlank { null },
                    sourceUrl = obj.optString("sourceUrl", audioPath),
                    streamUrl = audioPath,
                    mimeType = obj.optString("mimeType", "audio/mp4"),
                    bitrateKbps = obj.optInt("bitrateKbps", 128)
                )
                list.add(
                    SavedMediaResult(
                        audioFile = resolvedAudioFile,
                        coverFile = coverFile,
                        mediaStoreUri = resolvedAudioFile.toURI().toString(),
                        trackInfo = trackInfo
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parsePlaylistJson(obj: JSONObject): UserPlaylist {
        val tracksJson = obj.optJSONArray("tracks")?.toString() ?: "[]"
        return UserPlaylist(
            id = obj.optString("id", UUID.randomUUID().toString()),
            name = obj.optString("name", "Liste"),
            description = obj.optString("description", ""),
            coverUri = obj.optString("coverUri", "").ifBlank { null },
            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
            tracks = deserializeTracks(tracksJson)
        )
    }

    companion object {
        private const val LEGACY_PREFS_NAME = "sakura_offline_playlists"
        private const val KEY_PLAYLISTS_JSON = "playlists_json"
        private const val KEY_MIGRATED_TO_ROOM = "migrated_to_room_v1"
    }
}
