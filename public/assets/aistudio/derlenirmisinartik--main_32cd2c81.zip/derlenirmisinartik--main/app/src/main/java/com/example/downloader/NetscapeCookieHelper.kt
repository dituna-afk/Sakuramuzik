package com.example.downloader

import android.content.Context
import android.webkit.CookieManager
import com.example.data.CookieStorageHelper
import com.example.model.CookieItem
import com.example.model.CookieParser
import java.io.File
import java.security.MessageDigest
import java.util.Locale

object NetscapeCookieHelper {

    private val YOUTUBE_COOKIE_URLS = listOf(
        "https://music.youtube.com",
        "https://www.youtube.com",
        "https://m.youtube.com",
        "https://youtube.com",
        "https://accounts.google.com"
    )

    private val AUTH_COOKIE_NAMES = setOf(
        "SAPISID",
        "__Secure-3PAPISID",
        "__Secure-1PAPISID",
        "SID",
        "__Secure-1PSID",
        "__Secure-3PSID",
        "HSID",
        "SSID",
        "APISID",
        "LOGIN_INFO",
        "__Secure-1PSIDTS",
        "__Secure-3PSIDTS"
    )

    fun resolveActiveCookies(
        context: Context,
        explicitCookies: List<CookieItem> = emptyList()
    ): List<CookieItem> {
        val mergedByKey = LinkedHashMap<String, CookieItem>()

        fun putAllCookies(list: List<CookieItem>) {
            for (item in list) {
                val cleanName = item.name.trim()
                val cleanValue = item.value.trim()
                if (cleanName.isEmpty() || cleanValue.isEmpty()) continue
                val key = cleanName
                mergedByKey[key] = item.copy(
                    name = cleanName,
                    value = cleanValue,
                    domain = item.domain.trim().ifBlank { ".youtube.com" },
                    path = item.path.trim().ifBlank { "/" }
                )
            }
        }

        // 1. Saved cookies in encrypted storage
        try {
            val (_, saved) = CookieStorageHelper(context.applicationContext).loadCookies()
            putAllCookies(saved)
        } catch (_: Throwable) {
        }

        // 2. Explicit cookies passed from UI state
        putAllCookies(explicitCookies)

        // 3. Live WebView CookieManager cookies across YouTube Music & YouTube domains
        var harvestedFromWebView = false
        try {
            val cookieManager = CookieManager.getInstance()
            for (url in YOUTUBE_COOKIE_URLS) {
                val raw = try {
                    cookieManager.getCookie(url)
                } catch (_: Throwable) {
                    null
                }
                if (!raw.isNullOrBlank()) {
                    val parsed = CookieParser.parseRawCookies(raw, url)
                    if (parsed.isNotEmpty()) {
                        harvestedFromWebView = true
                        putAllCookies(parsed)
                    }
                }
            }
        } catch (_: Throwable) {
        }

        val finalCookies = mergedByKey.values.toList()
        if (harvestedFromWebView && finalCookies.isNotEmpty()) {
            try {
                CookieStorageHelper(context.applicationContext).saveCookies(
                    "https://music.youtube.com",
                    finalCookies
                )
            } catch (_: Throwable) {
            }
        }
        return finalCookies
    }

    fun hasYouTubeAuthCookies(cookies: List<CookieItem>): Boolean {
        return cookies.any { it.name.trim() in AUTH_COOKIE_NAMES && it.value.isNotBlank() }
    }

    fun writeNetscapeCookieFile(
        context: Context,
        cookies: List<CookieItem> = emptyList()
    ): File? {
        val activeCookies = resolveActiveCookies(context, cookies)
        if (activeCookies.isEmpty()) return null

        return try {
            val cookieDir = File(context.cacheDir, "ytdl_cookies").apply { mkdirs() }
            val cookieFile = File(cookieDir, "cookies_netscape.txt")
            val expirationEpoch = (System.currentTimeMillis() / 1000L) + 31_536_000L

            val sb = StringBuilder()
            sb.appendLine("# Netscape HTTP Cookie File")
            sb.appendLine("# https://curl.se/docs/http-cookies.html")
            sb.appendLine("# This is a generated file! Do not edit.")
            sb.appendLine()

            val writtenEntries = HashSet<String>()

            fun appendNetscapeRow(
                domain: String,
                path: String,
                isSecure: Boolean,
                name: String,
                value: String
            ) {
                val cleanName = name.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim()
                val cleanVal = value.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ').trim()
                if (cleanName.isEmpty()) return

                val normalizedDomain = if (domain.startsWith(".")) domain else ".$domain"
                val dedupKey = "$normalizedDomain|$path|$cleanName"
                if (!writtenEntries.add(dedupKey)) return

                val secureFlag = if (isSecure || cleanName.startsWith("__Secure-") || cleanName.startsWith("__Host-")) {
                    "TRUE"
                } else {
                    "FALSE"
                }

                sb.append(normalizedDomain).append('\t')
                    .append("TRUE").append('\t')
                    .append(path.ifBlank { "/" }).append('\t')
                    .append(secureFlag).append('\t')
                    .append(expirationEpoch).append('\t')
                    .append(cleanName).append('\t')
                    .append(cleanVal).appendLine()
            }

            for (cookie in activeCookies) {
                val name = cookie.name.trim()
                val value = cookie.value.trim()
                if (name.isEmpty()) continue

                val rawDomain = cookie.domain.trim().lowercase(Locale.US).removePrefix(".")
                val path = cookie.path.trim().ifEmpty { "/" }

                if (rawDomain.isEmpty() ||
                    rawDomain.contains("youtube.com") ||
                    rawDomain.contains("youtu.be")
                ) {
                    // Write for both .youtube.com and .music.youtube.com so ytdlnis (yt-dlp)
                    // sends authentication cookies on both www.youtube.com and music.youtube.com
                    appendNetscapeRow(".youtube.com", path, cookie.isSecure, name, value)
                    appendNetscapeRow(".music.youtube.com", path, cookie.isSecure, name, value)
                } else if (rawDomain.contains("google.com")) {
                    appendNetscapeRow(".google.com", path, cookie.isSecure, name, value)
                    appendNetscapeRow(".youtube.com", path, cookie.isSecure, name, value)
                } else {
                    appendNetscapeRow(".$rawDomain", path, cookie.isSecure, name, value)
                }
            }

            cookieFile.writeText(sb.toString(), Charsets.UTF_8)
            if (cookieFile.exists() && cookieFile.length() > 0L) cookieFile else null
        } catch (_: Throwable) {
            null
        }
    }

    fun buildCookieHeaderString(
        cookies: List<CookieItem>,
        context: Context? = null
    ): String? {
        val source = if (context != null) {
            resolveActiveCookies(context, cookies)
        } else {
            cookies
        }
        if (source.isEmpty()) return null
        val uniqueByName = LinkedHashMap<String, String>()
        for (c in source) {
            val n = c.name.trim()
            val v = c.value.trim()
            if (n.isNotEmpty() && v.isNotEmpty()) {
                uniqueByName[n] = v
            }
        }
        if (uniqueByName.isEmpty()) return null
        return uniqueByName.entries.joinToString("; ") { "${it.key}=${it.value}" }
    }

    fun buildSapisidHashHeader(
        cookies: List<CookieItem>,
        origin: String = "https://music.youtube.com"
    ): String? {
        val sapisid = cookies.firstOrNull { it.name.equals("SAPISID", ignoreCase = true) && it.value.isNotBlank() }?.value
            ?: cookies.firstOrNull { it.name.equals("__Secure-3PAPISID", ignoreCase = true) && it.value.isNotBlank() }?.value
            ?: cookies.firstOrNull { it.name.equals("__Secure-1PAPISID", ignoreCase = true) && it.value.isNotBlank() }?.value
            ?: return null

        return try {
            val timestamp = System.currentTimeMillis() / 1000L
            val input = "$timestamp ${sapisid.trim()} $origin"
            val digest = MessageDigest.getInstance("SHA-1").digest(input.toByteArray(Charsets.UTF_8))
            val sha1Hex = digest.joinToString("") { "%02x".format(it) }
            "SAPISIDHASH ${timestamp}_$sha1Hex"
        } catch (_: Throwable) {
            null
        }
    }
}
