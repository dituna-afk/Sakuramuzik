package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.CachePolicy
import coil.request.ImageRequest
import coil.size.Precision
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * Sliding Viewport & Progressive Windowing state for LazyColumn.
 * - Starts by mounting only [initialBatchSize] items (e.g., 5 songs on Home screen).
 * - Progressively unlocks [stepBatchSize] more items when the user scrolls near the bottom.
 * - Tracks the active visible item window so items scrolled above (or far below) are
 *   forgotten/unloaded from GPU/RAM while keeping scroll position stable.
 */
@Stable
class ProgressiveWindowState(
    val loadedCount: Int,
    private val firstActiveTrackIndex: Int,
    private val lastActiveTrackIndex: Int
) {
    fun isTrackInActiveMemoryWindow(trackIndex: Int): Boolean {
        return trackIndex in firstActiveTrackIndex..lastActiveTrackIndex
    }
}

@Composable
fun rememberProgressiveWindowState(
    listState: LazyListState,
    totalItemsCount: Int,
    headerItemsOffset: Int = 1,
    initialBatchSize: Int = 15,
    stepBatchSize: Int = 15,
    activeWindowBuffer: Int = 15
): ProgressiveWindowState {
    var loadedCount by remember(totalItemsCount, initialBatchSize) {
        mutableIntStateOf(minOf(initialBatchSize, totalItemsCount))
    }

    // Clamp if totalItemsCount shrinks
    val effectiveLoadedCount = minOf(loadedCount, totalItemsCount)

    // Progressive expansion when scrolling down
    LaunchedEffect(listState, totalItemsCount, stepBatchSize, headerItemsOffset) {
        snapshotFlow {
            val layoutInfo = listState.layoutInfo
            val lastVisibleIndex = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            lastVisibleIndex - headerItemsOffset
        }
            .distinctUntilChanged()
            .collect { lastVisibleTrackIndex ->
                if (lastVisibleTrackIndex >= loadedCount - 4 && loadedCount < totalItemsCount) {
                    loadedCount = minOf(totalItemsCount, loadedCount + stepBatchSize)
                }
            }
    }

    // Sliding window calculation: generous buffer keeps items in memory during scrolling
    val activeRange by remember(listState, headerItemsOffset, activeWindowBuffer) {
        derivedStateOf {
            val visibleItems = listState.layoutInfo.visibleItemsInfo
            if (visibleItems.isEmpty()) {
                0..(initialBatchSize + activeWindowBuffer)
            } else {
                val firstVisibleLazyIndex = visibleItems.first().index
                val lastVisibleLazyIndex = visibleItems.last().index
                val firstTrackIdx = (firstVisibleLazyIndex - headerItemsOffset - activeWindowBuffer).coerceAtLeast(0)
                val lastTrackIdx = (lastVisibleLazyIndex - headerItemsOffset + activeWindowBuffer).coerceAtLeast(firstTrackIdx + initialBatchSize)
                firstTrackIdx..lastTrackIdx
            }
        }
    }

    return remember(effectiveLoadedCount, activeRange) {
        ProgressiveWindowState(
            loadedCount = effectiveLoadedCount,
            firstActiveTrackIndex = activeRange.first,
            lastActiveTrackIndex = activeRange.last
        )
    }
}

@Composable
fun rememberGridProgressiveWindowState(
    gridState: LazyGridState,
    totalItemsCount: Int,
    headerItemsOffset: Int = 1,
    initialBatchSize: Int = 18,
    stepBatchSize: Int = 18,
    activeWindowBuffer: Int = 18
): ProgressiveWindowState {
    var loadedCount by remember(totalItemsCount, initialBatchSize) {
        mutableIntStateOf(minOf(initialBatchSize, totalItemsCount))
    }

    val effectiveLoadedCount = minOf(loadedCount, totalItemsCount)

    LaunchedEffect(gridState, totalItemsCount, stepBatchSize, headerItemsOffset) {
        snapshotFlow {
            val layoutInfo = gridState.layoutInfo
            val lastVisibleIndex = layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            lastVisibleIndex - headerItemsOffset
        }
            .distinctUntilChanged()
            .collect { lastVisibleTrackIndex ->
                if (lastVisibleTrackIndex >= loadedCount - 4 && loadedCount < totalItemsCount) {
                    loadedCount = minOf(totalItemsCount, loadedCount + stepBatchSize)
                }
            }
    }

    val activeRange by remember(gridState, headerItemsOffset, activeWindowBuffer) {
        derivedStateOf {
            val visibleItems = gridState.layoutInfo.visibleItemsInfo
            if (visibleItems.isEmpty()) {
                0..(initialBatchSize + activeWindowBuffer)
            } else {
                val firstVisibleLazyIndex = visibleItems.first().index
                val lastVisibleLazyIndex = visibleItems.last().index
                val firstTrackIdx = (firstVisibleLazyIndex - headerItemsOffset - activeWindowBuffer).coerceAtLeast(0)
                val lastTrackIdx = (lastVisibleLazyIndex - headerItemsOffset + activeWindowBuffer).coerceAtLeast(firstTrackIdx + initialBatchSize)
                firstTrackIdx..lastTrackIdx
            }
        }
    }

    return remember(effectiveLoadedCount, activeRange) {
        ProgressiveWindowState(
            loadedCount = effectiveLoadedCount,
            firstActiveTrackIndex = activeRange.first,
            lastActiveTrackIndex = activeRange.last
        )
    }
}

/**
 * Ultra-smooth, downsampled thumbnail loader that leverages RAM memory cache for butter-smooth scrolling.
 */
@Composable
fun OptimizedThumbnailImage(
    model: Any?,
    contentDescription: String?,
    isWithinActiveWindow: Boolean = true,
    fallbackIcon: ImageVector = Icons.Default.MusicNote,
    fallbackTint: Color,
    backgroundColor: Color,
    iconSize: Dp = 24.dp,
    targetPixelSize: Int = 128,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Box(
        modifier = modifier.background(backgroundColor),
        contentAlignment = Alignment.Center
    ) {
        if (model != null) {
            val imageRequest = remember(model, targetPixelSize) {
                ImageRequest.Builder(context)
                    .data(model)
                    .size(targetPixelSize, targetPixelSize)
                    .precision(Precision.INEXACT)
                    .crossfade(false)
                    .allowHardware(true)
                    .memoryCachePolicy(CachePolicy.ENABLED)
                    .diskCachePolicy(CachePolicy.ENABLED)
                    .build()
            }
            AsyncImage(
                model = imageRequest,
                contentDescription = contentDescription,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Icon(
                imageVector = fallbackIcon,
                contentDescription = null,
                tint = fallbackTint,
                modifier = Modifier.size(iconSize)
            )
        }
    }
}
