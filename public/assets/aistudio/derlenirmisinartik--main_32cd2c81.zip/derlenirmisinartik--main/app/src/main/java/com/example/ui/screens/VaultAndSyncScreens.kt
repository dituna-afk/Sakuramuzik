package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.downloader.DownloadFormatOption
import com.example.model.CookieItem
import com.example.model.CookieParser
import com.example.sync.SubscriptionSource
import com.example.ui.components.AddEditCookieDialog
import com.example.ui.components.CookieInspectorPanel
import com.example.ui.components.ExportJsonDialog
import com.example.ui.components.OptimizedThumbnailImage
import com.example.ui.components.WebViewComponent
import com.example.ui.components.rememberProgressiveWindowState
import com.example.ui.theme.LocalAppThemePalette
import com.example.vault.VaultItem
import com.example.viewmodel.CookieViewModel
import java.io.File

enum class VaultFilterType(val label: String) {
    ALL("Tümü"),
    AUDIO("Ses"),
    VIDEO("Video")
}

@Composable
fun VaultScreen(
    vaultItems: List<VaultItem>,
    onPlayVaultItem: (VaultItem) -> Unit,
    onDeleteVaultItem: (VaultItem) -> Unit,
    onRefreshVault: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val palette = LocalAppThemePalette.current
    var filter by remember { mutableStateOf(VaultFilterType.ALL) }

    val filtered = remember(vaultItems, filter) {
        when (filter) {
            VaultFilterType.ALL -> vaultItems
            VaultFilterType.AUDIO -> vaultItems.filter { !it.isVideo }
            VaultFilterType.VIDEO -> vaultItems.filter { it.isVideo }
        }
    }

    val listState = rememberLazyListState()
    val windowState = rememberProgressiveWindowState(
        listState = listState,
        totalItemsCount = filtered.size,
        headerItemsOffset = 2,
        initialBatchSize = 6,
        stepBatchSize = 6,
        activeWindowBuffer = 2
    )

    val displayedVaultItems = remember(filtered, windowState.loadedCount) {
        filtered.take(windowState.loadedCount)
    }

    LazyColumn(
        state = listState,
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item(key = "vault_header", contentType = "header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Sakura Medya Kasası",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = palette.onBackground
                    )
                    Text(
                        text = "ExoPlayer destekli çevrimdışı arşiv (${displayedVaultItems.size}/${filtered.size} aktif)",
                        fontSize = 12.sp,
                        color = palette.onSurfaceMuted
                    )
                }
                IconButton(onClick = onRefreshVault) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Yenile",
                        tint = palette.primaryAccent
                    )
                }
            }
        }

        item(key = "vault_filter_chips", contentType = "filters") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VaultFilterType.entries.forEach { f ->
                    FilterChip(
                        selected = filter == f,
                        onClick = { filter = f },
                        label = { Text(f.label) }
                    )
                }
            }
        }

        if (filtered.isEmpty()) {
            item(key = "vault_empty", contentType = "empty") {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(palette.surfaceContainer)
                        .padding(28.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Kasada bu filtreye uygun medya dosyası bulunamadı.",
                        color = palette.onSurfaceMuted
                    )
                }
            }
        } else {
            itemsIndexed(
                items = displayedVaultItems,
                key = { _, item -> item.id },
                contentType = { _, _ -> "vault_item_row" }
            ) { index, item ->
                val isInActiveWindow = windowState.isTrackInActiveMemoryWindow(index)
                val thumbFile = remember(item.thumbnailPath) {
                    item.thumbnailPath?.takeIf { it.isNotBlank() }?.let { File(it) }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(palette.surfaceContainer)
                        .border(1.dp, palette.dividerOrBorder, RoundedCornerShape(16.dp))
                        .clickable { onPlayVaultItem(item) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OptimizedThumbnailImage(
                        model = thumbFile,
                        contentDescription = item.title,
                        isWithinActiveWindow = isInActiveWindow,
                        fallbackIcon = if (item.isVideo) Icons.Default.Movie else Icons.Default.MusicNote,
                        fallbackTint = palette.primaryAccent,
                        backgroundColor = palette.surfaceVariant,
                        iconSize = 24.dp,
                        targetPixelSize = 128,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(12.dp))
                    )

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.title,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = palette.onSurface,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${item.artist} • ${item.resolutionOrBitrate} • ${item.fileSizeBytes / 1024} KB",
                            fontSize = 12.sp,
                            color = palette.onSurfaceMuted
                        )
                    }

                    IconButton(
                        onClick = {
                            try {
                                val f = File(item.filePath)
                                val uri = FileProvider.getUriForFile(
                                    context,
                                    "${context.packageName}.fileprovider",
                                    f
                                )
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = if (item.isVideo) "video/*" else "audio/*"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(Intent.createChooser(shareIntent, item.title))
                            } catch (_: Exception) {
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "Paylaş",
                            tint = palette.secondaryAccent
                        )
                    }

                    IconButton(onClick = { onDeleteVaultItem(item) }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Sil",
                            tint = palette.tertiaryAccent
                        )
                    }

                    IconButton(onClick = { onPlayVaultItem(item) }) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Oynat",
                            tint = palette.primaryAccent
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SubscriptionManagerScreen(
    subscriptions: List<SubscriptionSource>,
    isWifiOnly: Boolean,
    intervalHours: Long,
    intervalMinutes: Long = intervalHours * 60L,
    onAddSubscription: (String, String, DownloadFormatOption) -> Unit,
    onRemoveSubscription: (String) -> Unit,
    onToggleSubscription: (String, Boolean) -> Unit,
    onSetWifiOnly: (Boolean) -> Unit,
    onSetIntervalHours: (Long) -> Unit,
    onSetIntervalMinutes: (Long) -> Unit = { onSetIntervalHours((it / 60L).coerceAtLeast(1L)) },
    onTriggerImmediateSync: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val palette = LocalAppThemePalette.current
    var newTitle by remember { mutableStateOf("") }
    var newUrl by remember { mutableStateOf("") }
    var selectedFormat by remember { mutableStateOf(DownloadFormatOption.AUDIO_M4A_HIGH) }

    val presetIntervals = listOf(
        30L to "30 Dakika",
        60L to "1 Saat",
        180L to "3 Saat",
        360L to "6 Saat"
    )

    var isCustomSelected by remember(intervalMinutes) {
        mutableStateOf(presetIntervals.none { it.first == intervalMinutes })
    }
    var customMinutesInput by remember(intervalMinutes) {
        mutableStateOf(if (isCustomSelected) intervalMinutes.toString() else "45")
    }

    val subListState = rememberLazyListState()
    val subWindowState = rememberProgressiveWindowState(
        listState = subListState,
        totalItemsCount = subscriptions.size,
        headerItemsOffset = 4,
        initialBatchSize = 6,
        stepBatchSize = 6,
        activeWindowBuffer = 2
    )
    val displayedSubscriptions = remember(subscriptions, subWindowState.loadedCount) {
        subscriptions.take(subWindowState.loadedCount)
    }

    LazyColumn(
        state = subListState,
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item(key = "sub_header", contentType = "header") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Otomatik Kanal & Liste Senkronizasyonu",
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = palette.onBackground
                )
                OutlinedButton(onClick = onBack) {
                    Text("Geri")
                }
            }
        }

        // Wi-Fi Guarantee Informative Card
        item(key = "sub_wifi_card", contentType = "info_card") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.primaryAccent.copy(alpha = 0.12f))
                    .border(1.dp, palette.primaryAccent.copy(alpha = 0.3f), RoundedCornerShape(18.dp))
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = null,
                        tint = palette.primaryAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Wi-Fi Bağlantı & Kuyruk Garantisi (WorkManager)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = palette.primaryAccent
                    )
                }
                Text(
                    text = "Belirlenen kontrol vaktinde Wi-Fi bağlı değilse, senkronizasyon isteği KESİNLİKLE silinmez. Android İş Yöneticisi bu görevi hafızada tutar ve cihaza Wi-Fi bağlandığı ilk anda indirme kontrolünü otomatik başlatır.",
                    fontSize = 11.5.sp,
                    color = palette.onSurface,
                    lineHeight = 16.sp
                )
            }
        }

        // Controls & Interval Selector Card
        item(key = "sub_controls_card", contentType = "controls_card") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.surfaceContainer)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Yalnızca Wi-Fi Üzerinde Senkronize Et", color = palette.onSurface, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Hücresel veri kullanımını engeller", color = palette.onSurfaceMuted, fontSize = 11.sp)
                    }
                    Switch(checked = isWifiOnly, onCheckedChange = onSetWifiOnly)
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "Kontrol Sıklığı (Mevcut: ${if (intervalMinutes % 60L == 0L) "${intervalMinutes / 60L} Saat" else "$intervalMinutes Dakika"})",
                    color = palette.onSurface,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    presetIntervals.forEach { (mins, label) ->
                        val isSelected = !isCustomSelected && intervalMinutes == mins
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                isCustomSelected = false
                                onSetIntervalMinutes(mins)
                            },
                            label = { Text(label, fontSize = 11.sp) }
                        )
                    }
                    FilterChip(
                        selected = isCustomSelected,
                        onClick = { isCustomSelected = true },
                        label = { Text("Özel", fontSize = 11.sp) }
                    )
                }

                if (isCustomSelected) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = customMinutesInput,
                            onValueChange = { customMinutesInput = it.filter { char -> char.isDigit() } },
                            label = { Text("Özel Süre (Dakika, Min 15)") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(
                            onClick = {
                                val parsed = customMinutesInput.toLongOrNull() ?: 30L
                                onSetIntervalMinutes(parsed.coerceAtLeast(15L))
                            }
                        ) {
                            Text("Kaydet")
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(onClick = onTriggerImmediateSync) {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Şimdi Manuel Tetikle")
                    }
                }
            }
        }

        item(key = "sub_add_card", contentType = "add_card") {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(palette.surfaceContainer)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Yeni Kanal veya Çalma Listesi Aboneliği Ekle",
                    fontWeight = FontWeight.Bold,
                    color = palette.onSurface
                )
                OutlinedTextField(
                    value = newTitle,
                    onValueChange = { newTitle = it },
                    label = { Text("Başlık (Örn: Lo-Fi Sakura Kanalı)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newUrl,
                    onValueChange = { newUrl = it },
                    label = { Text("YouTube / SoundCloud Liste veya Kanal URL'si") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        if (newUrl.isNotBlank()) {
                            onAddSubscription(newTitle, newUrl, selectedFormat)
                            newTitle = ""
                            newUrl = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Aboneliği Kaydet")
                }
            }
        }

        itemsIndexed(
            items = displayedSubscriptions,
            key = { _, sub -> sub.id },
            contentType = { _, _ -> "subscription_row" }
        ) { _, sub ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(palette.surfaceContainer)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(sub.title, fontWeight = FontWeight.Bold, color = palette.onSurface)
                    Text(sub.url, fontSize = 11.sp, color = palette.onSurfaceMuted, maxLines = 1)
                    Text(
                        text = "${sub.downloadedVideoIds.size} parça otomatik indirildi",
                        fontSize = 11.sp,
                        color = palette.primaryAccent
                    )
                }
                Switch(
                    checked = sub.isEnabled,
                    onCheckedChange = { onToggleSubscription(sub.id, it) }
                )
                IconButton(onClick = { onRemoveSubscription(sub.id) }) {
                    Icon(Icons.Default.Delete, contentDescription = "Sil", tint = palette.tertiaryAccent)
                }
            }
        }
    }
}

@Composable
fun CookieInspectorScreen(
    cookieViewModel: CookieViewModel,
    modifier: Modifier = Modifier
) {
    val palette = LocalAppThemePalette.current
    val state by cookieViewModel.uiState.collectAsState()
    var urlInput by remember(state.currentUrl) { mutableStateOf(state.currentUrl) }
    var reloadTrigger by remember { mutableIntStateOf(0) }
    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingCookie by remember { mutableStateOf<CookieItem?>(null) }
    var showExportDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(bottom = 90.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = urlInput,
                onValueChange = { urlInput = it },
                placeholder = { Text("https://music.youtube.com") },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = { cookieViewModel.updateUrl(urlInput) }) {
                Text("Git")
            }
            OutlinedButton(onClick = { reloadTrigger++ }) {
                Text("Yenile")
            }
        }

        WebViewComponent(
            url = state.currentUrl,
            reloadTrigger = reloadTrigger,
            onPageStarted = { cookieViewModel.onPageStarted(it) },
            onPageFinished = { u, title -> cookieViewModel.onPageFinished(u, title) },
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.45f)
        )

        CookieInspectorPanel(
            cookies = state.filteredCookies,
            searchQuery = state.searchQuery,
            onSearchQueryChange = cookieViewModel::updateSearchQuery,
            logEntries = state.logEntries,
            onRefreshCookies = cookieViewModel::refreshCookiesForCurrentUrl,
            onAddCookieClick = {
                editingCookie = null
                showAddEditDialog = true
            },
            onEditCookieClick = { c ->
                editingCookie = c
                showAddEditDialog = true
            },
            onDeleteCookieClick = cookieViewModel::deleteCookie,
            onClearAllCookies = cookieViewModel::clearAllCookies,
            onSaveToStorage = cookieViewModel::saveCurrentCookiesToStorage,
            onExportJsonClick = { showExportDialog = true },
            onClearLogs = cookieViewModel::clearLogs,
            modifier = Modifier
                .fillMaxWidth()
                .weight(0.55f)
        )
    }

    if (showAddEditDialog) {
        AddEditCookieDialog(
            initialCookie = editingCookie,
            defaultDomain = CookieParser.extractDomain(state.currentUrl),
            onDismiss = { showAddEditDialog = false },
            onSave = { cookie ->
                cookieViewModel.addOrUpdateCookie(cookie)
                showAddEditDialog = false
            }
        )
    }

    if (showExportDialog) {
        ExportJsonDialog(
            jsonContent = cookieViewModel.exportCookiesAsJson(),
            onDismiss = { showExportDialog = false }
        )
    }
}
