package com.example.ui.theme

import com.example.R

data class AnimeThemeMetadata(
    val themeKey: String,
    val seriesTitle: String,
    val characterName: String,
    val japaneseTitle: String,
    val primaryAssetPath: String?,
    val secondaryAssetPath: String?,
    val systemVectorDrawableRes: Int?,
    val quote: String
)

object AnimeArtRegistry {
    const val ASSET_BERSERK_GUTS = "file:///android_asset/anime/berserk_guts_poster.jpg"
    const val ASSET_BERSERK_BEHELIT = "file:///android_asset/anime/berserk_behelit.jpg"
    const val ASSET_BERSERK_GRIFFITH_PORTRAIT = "file:///android_asset/anime/berserk_griffith_portrait.webp"
    const val ASSET_BERSERK_GRIFFITH_ARMOR = "file:///android_asset/anime/berserk_griffith_armor.png"
    const val ASSET_EVA_REI_MOON = "file:///android_asset/anime/eva_rei_moon.jpg"
    const val ASSET_EVA_END_OF_EVA = "file:///android_asset/anime/eva_end_of_eva.jpg"
    const val ASSET_EVA_SYNTHWAVE = "file:///android_asset/anime/eva_synthwave.jpg"
    const val ASSET_BEBOP_FAYE_YELLOW = "file:///android_asset/anime/bebop_faye_yellow.jpg"
    const val ASSET_BEBOP_FAYE_RETRO = "file:///android_asset/anime/bebop_faye_retro.jpg"

    fun getMetadata(theme: AppTheme): AnimeThemeMetadata? {
        return when (theme.name) {
            "BERSERK_GUTS" -> AnimeThemeMetadata(
                themeKey = "BERSERK_GUTS",
                seriesTitle = "Berserk (ベルセルク)",
                characterName = "Guts • The Black Swordsman",
                japaneseTitle = "黒い剣士 ガッツ",
                primaryAssetPath = ASSET_BERSERK_GUTS,
                secondaryAssetPath = ASSET_BERSERK_BEHELIT,
                systemVectorDrawableRes = R.drawable.ic_anime_hero_berserk,
                quote = "Kaderine boyun eğme; kılıcını savurmaya devam et."
            )
            "BERSERK_GRIFFITH" -> AnimeThemeMetadata(
                themeKey = "BERSERK_GRIFFITH",
                seriesTitle = "Berserk (ベルセルク)",
                characterName = "Griffith • Falcon of Light",
                japaneseTitle = "光の鷹 グリフィス",
                primaryAssetPath = ASSET_BERSERK_GRIFFITH_PORTRAIT,
                secondaryAssetPath = ASSET_BERSERK_GRIFFITH_ARMOR,
                systemVectorDrawableRes = R.drawable.ic_anime_hero_griffith,
                quote = "Bir hayali olan insan asla durdurulamaz."
            )
            "EVANGELION_01" -> AnimeThemeMetadata(
                themeKey = "EVANGELION_01",
                seriesTitle = "Neon Genesis Evangelion (新世紀エヴァンゲリオン)",
                characterName = "EVA-01 & Rei Ayanami",
                japaneseTitle = "汎用ヒト型決戦兵器 人造人間エヴァンゲリオン",
                primaryAssetPath = ASSET_EVA_REI_MOON,
                secondaryAssetPath = ASSET_EVA_END_OF_EVA,
                systemVectorDrawableRes = R.drawable.ic_anime_hero_evangelion,
                quote = "Sen kaçamazsın. Çünkü bu senin kaderin."
            )
            "CHAINSAW_MAN" -> AnimeThemeMetadata(
                themeKey = "CHAINSAW_MAN",
                seriesTitle = "Chainsaw Man (チェンソーマン)",
                characterName = "Denji • Chainsaw Devil",
                japaneseTitle = "デンジ チェンソーの悪魔",
                primaryAssetPath = ASSET_EVA_SYNTHWAVE,
                secondaryAssetPath = ASSET_BERSERK_BEHELIT,
                systemVectorDrawableRes = R.drawable.ic_anime_hero_chainsaw,
                quote = "Kafandaki motoru çalıştır ve parçala!"
            )
            "COWBOY_BEBOP_FAYE" -> AnimeThemeMetadata(
                themeKey = "COWBOY_BEBOP_FAYE",
                seriesTitle = "Cowboy Bebop (カウボーイビバップ)",
                characterName = "Faye Valentine • Red Tail",
                japaneseTitle = "フェイ・ヴァレンタイン",
                primaryAssetPath = ASSET_BEBOP_FAYE_YELLOW,
                secondaryAssetPath = ASSET_BEBOP_FAYE_RETRO,
                systemVectorDrawableRes = R.drawable.ic_anime_hero_bebop,
                quote = "Geçmişini hatırlamıyorsan geleceğini kendin yaratırsın."
            )
            "COWBOY_BEBOP_SPIKE" -> AnimeThemeMetadata(
                themeKey = "COWBOY_BEBOP_SPIKE",
                seriesTitle = "Cowboy Bebop (カウボーイビバップ)",
                characterName = "Spike Spiegel • Swordfish II",
                japaneseTitle = "スパイク・スピーゲル",
                primaryAssetPath = ASSET_BEBOP_FAYE_RETRO,
                secondaryAssetPath = ASSET_BEBOP_FAYE_YELLOW,
                systemVectorDrawableRes = R.drawable.ic_anime_hero_bebop,
                quote = "See You Space Cowboy..."
            )
            else -> null
        }
    }

    fun isAnimeTheme(theme: AppTheme): Boolean = getMetadata(theme) != null
}
