package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.SakuraTreeStyle
import com.example.ui.animation.LocalSakuraAnimationState
import com.example.ui.theme.LocalAppThemePalette
import com.example.ui.theme.isSakuraTheme
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private data class SakuraPetal(
    val xFraction: Float,
    val initialYFraction: Float,
    val sizeDp: Float,
    val speedFactor: Float,
    val swayAmplitude: Float,
    val swayPhase: Float,
    val rotationSpeed: Float,
    val alpha: Float,
    val useSecondaryColor: Boolean
)

private data class BurstPetal(
    val angleRad: Float,
    val distanceFactor: Float,
    val sizeDp: Float,
    val rotationDeg: Float,
    val useSecondaryColor: Boolean
)

@Composable
fun FloatingSakuraPetalsOverlay(
    modifier: Modifier = Modifier,
    petalCount: Int? = null,
    treeStyleOverride: SakuraTreeStyle? = null
) {
    val palette = LocalAppThemePalette.current
    val treeStyle = treeStyleOverride ?: com.example.data.LocalSakuraTreeStyle.current
    val animState = LocalSakuraAnimationState.current
    val effectiveCount = petalCount ?: animState.config.effectiveAmbientPetalCount(
        animState.isSystemPowerSaveMode
    )

    if (!palette.theme.isSakuraTheme() || effectiveCount <= 0) return

    val primaryPetalColor = if (treeStyle != com.example.data.SakuraTreeStyle.TRADITIONAL_SAKURA) {
        treeStyle.petalPrimary
    } else {
        palette.petalPrimary
    }

    val secondaryPetalColor = if (treeStyle != com.example.data.SakuraTreeStyle.TRADITIONAL_SAKURA) {
        treeStyle.petalSecondary
    } else {
        palette.petalSecondary
    }

    val petals = remember(effectiveCount) {
        val rng = Random(7721)
        List(effectiveCount) {
            SakuraPetal(
                xFraction = rng.nextFloat(),
                initialYFraction = rng.nextFloat(),
                sizeDp = 7f + rng.nextFloat() * 9f,
                speedFactor = 0.45f + rng.nextFloat() * 0.85f,
                swayAmplitude = 14f + rng.nextFloat() * 28f,
                swayPhase = rng.nextFloat() * (2f * PI.toFloat()),
                rotationSpeed = (rng.nextFloat() - 0.5f) * 260f,
                alpha = 0.22f + rng.nextFloat() * 0.36f,
                useSecondaryColor = rng.nextBoolean()
            )
        }
    }

    val transition = rememberInfiniteTransition(label = "sakura_petals_fall")
    val progress by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 22_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "petal_progress"
    )

    val swayMult = animState.config.effectIntensity.windSwayMultiplier
    val reusablePetalPath = remember { Path() }

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas

        for (i in 0 until petals.size) {
            val p = petals[i]
            val yNorm = (p.initialYFraction + progress * p.speedFactor) % 1f
            val y = yNorm * (h + 60f) - 30f
            val sway = sin((progress * 2f * PI.toFloat() * p.speedFactor) + p.swayPhase) *
                p.swayAmplitude * swayMult
            val x = (p.xFraction * w + sway + w) % w
            val angle = (progress * p.rotationSpeed) % 360f
            val color = if (p.useSecondaryColor) secondaryPetalColor else primaryPetalColor

            drawThemeParticleShape(
                theme = palette.theme,
                center = Offset(x, y),
                radius = p.sizeDp.dp.toPx(),
                rotationDegrees = angle,
                color = color.copy(alpha = p.alpha),
                secondaryColor = secondaryPetalColor,
                reusablePath = reusablePetalPath
            )
        }
    }
}

@Composable
fun SakuraBurstEffect(
    triggerKey: Int,
    modifier: Modifier = Modifier
) {
    val palette = LocalAppThemePalette.current
    val animState = LocalSakuraAnimationState.current
    val count = animState.config.effectiveBurstCount(animState.isSystemPowerSaveMode)
    if (!palette.theme.isSakuraTheme() || triggerKey <= 0 || count <= 0) return

    var burstProgress by remember(triggerKey) { mutableFloatStateOf(0f) }
    val particles = remember(triggerKey, count) {
        val rng = Random(triggerKey * 131)
        List(count) { i ->
            val baseAngle = (2.0 * PI * i / count).toFloat()
            BurstPetal(
                angleRad = baseAngle + (rng.nextFloat() - 0.5f) * 0.35f,
                distanceFactor = 0.55f + rng.nextFloat() * 0.65f,
                sizeDp = 6f + rng.nextFloat() * 6f,
                rotationDeg = rng.nextFloat() * 360f,
                useSecondaryColor = rng.nextBoolean()
            )
        }
    }

    LaunchedEffect(triggerKey) {
        val startNanos = withFrameNanos { it }
        val durationNanos = 650_000_000L
        while (burstProgress < 1f) {
            val now = withFrameNanos { it }
            burstProgress = ((now - startNanos).toFloat() / durationNanos.toFloat()).coerceIn(0f, 1f)
        }
    }

    if (burstProgress >= 1f) return
    val reusablePetalPath = remember { Path() }

    Canvas(modifier = modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val maxRadius = size.minDimension * 0.46f
        val alpha = (1f - burstProgress).coerceIn(0f, 1f)

        for (i in 0 until particles.size) {
            val p = particles[i]
            val dist = maxRadius * p.distanceFactor * burstProgress
            val pos = Offset(
                x = center.x + cos(p.angleRad) * dist,
                y = center.y + sin(p.angleRad) * dist
            )
            val color = if (p.useSecondaryColor) palette.petalSecondary else palette.primaryAccent
            drawThemeParticleShape(
                theme = palette.theme,
                center = pos,
                radius = p.sizeDp.dp.toPx() * (1f - burstProgress * 0.35f),
                rotationDegrees = p.rotationDeg + burstProgress * 160f,
                color = color.copy(alpha = alpha),
                secondaryColor = palette.secondaryAccent,
                reusablePath = reusablePetalPath
            )
        }
    }
}

@Composable
fun SakuraFlowerEmblem(
    modifier: Modifier = Modifier,
    size: Dp = 32.dp,
    tint: Color? = null
) {
    val palette = LocalAppThemePalette.current
    val primaryColor = tint ?: palette.primaryAccent
    val centerColor = palette.secondaryAccent
    val reusablePetalPath = remember { Path() }

    Canvas(modifier = modifier.size(size)) {
        val c = Offset(this.size.width / 2f, this.size.height / 2f)
        val petalLen = this.size.minDimension * 0.36f
        for (i in 0 until 5) {
            val angle = i * 72f - 90f
            withTransform({
                rotate(degrees = angle, pivot = c)
            }) {
                drawSakuraPetalShape(
                    center = Offset(c.x, c.y - petalLen * 0.65f),
                    radius = petalLen * 0.58f,
                    rotationDegrees = 0f,
                    color = primaryColor,
                    reusablePath = reusablePetalPath
                )
            }
        }
        drawCircle(
            color = centerColor,
            radius = this.size.minDimension * 0.11f,
            center = c
        )
    }
}

@Composable
fun SakuraBranchHeaderDecoration(
    modifier: Modifier = Modifier
) {
    val palette = LocalAppThemePalette.current
    val reusableBranchPath = remember { Path() }
    val reusablePetalPath = remember { Path() }
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        if (w <= 0f || h <= 0f) return@Canvas

        reusableBranchPath.reset()
        reusableBranchPath.moveTo(w * 0.98f, h * 0.12f)
        reusableBranchPath.cubicTo(
            w * 0.82f, h * 0.25f,
            w * 0.68f, h * 0.18f,
            w * 0.52f, h * 0.42f
        )
        drawPath(
            path = reusableBranchPath,
            color = palette.primaryAccent.copy(alpha = 0.26f),
            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
        )

        val blossomCenters = listOf(
            Offset(w * 0.88f, h * 0.20f),
            Offset(w * 0.74f, h * 0.24f),
            Offset(w * 0.60f, h * 0.34f)
        )
        blossomCenters.forEachIndexed { idx, pos ->
            drawSakuraPetalShape(
                center = pos,
                radius = (8 - idx).dp.toPx(),
                rotationDegrees = idx * 42f,
                color = palette.petalPrimary.copy(alpha = 0.45f),
                reusablePath = reusablePetalPath
            )
        }
    }
}

internal data class TouchBlossomParticle(
    val angleRad: Float,
    val speedPxPerSec: Float,
    val sizeDp: Float,
    val baseRotationDeg: Float,
    val spinDegPerSec: Float,
    val isFullFlower: Boolean,
    val useSecondaryColor: Boolean
)

internal data class TouchBlossomBurst(
    val id: Long,
    val originX: Float,
    val originY: Float,
    val startTimeNanos: Long,
    val particles: List<TouchBlossomParticle>
)

class TouchSakuraBurstController {
    internal val bursts = mutableStateListOf<TouchBlossomBurst>()
    private var nextId = 1L
    private var lastSpawnUptimeMs = 0L

    fun clear() {
        bursts.clear()
    }

    fun spawnAt(x: Float, y: Float, isDrag: Boolean = false) {
        if (isDrag) return // Disable drag spawning to prevent touch latency and scroll stutter
        val nowMs = android.os.SystemClock.uptimeMillis()
        if (nowMs - lastSpawnUptimeMs < 140L) return
        lastSpawnUptimeMs = nowMs

        val seed = (nextId * 997L) xor System.nanoTime()
        val rng = Random(seed)
        val count = 5
        val particleList = List(count) { idx ->
            val baseAngle = (2.0 * PI * idx / count).toFloat()
            TouchBlossomParticle(
                angleRad = baseAngle + (rng.nextFloat() - 0.5f) * 0.40f,
                speedPxPerSec = 70f + rng.nextFloat() * 110f,
                sizeDp = 6.5f + rng.nextFloat() * 4.0f,
                baseRotationDeg = rng.nextFloat() * 360f,
                spinDegPerSec = (rng.nextFloat() - 0.5f) * 240f,
                isFullFlower = (idx % 2 == 0),
                useSecondaryColor = rng.nextBoolean()
            )
        }

        if (bursts.size >= 3) {
            bursts.removeAt(0)
        }
        bursts.add(
            TouchBlossomBurst(
                id = nextId++,
                originX = x,
                originY = y,
                startTimeNanos = System.nanoTime(),
                particles = particleList
            )
        )
    }
}

@Composable
fun rememberTouchSakuraBurstController(): TouchSakuraBurstController {
    return remember { TouchSakuraBurstController() }
}

@Composable
fun TouchSakuraBlossomOverlay(
    controller: TouchSakuraBurstController,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    val palette = LocalAppThemePalette.current
    if (!palette.theme.isSakuraTheme() || !enabled) {
        if (controller.bursts.isNotEmpty()) {
            controller.clear()
        }
        return
    }
    if (controller.bursts.isEmpty()) return

    val treeStyle = com.example.data.LocalSakuraTreeStyle.current
    val primaryColor = if (treeStyle != SakuraTreeStyle.TRADITIONAL_SAKURA) {
        treeStyle.petalPrimary
    } else {
        palette.petalPrimary
    }
    val secondaryColor = if (treeStyle != SakuraTreeStyle.TRADITIONAL_SAKURA) {
        treeStyle.petalSecondary
    } else {
        palette.petalSecondary
    }
    val centerStamenColor = palette.secondaryAccent

    var frameTimeNanos by remember { androidx.compose.runtime.mutableLongStateOf(System.nanoTime()) }

    LaunchedEffect(controller.bursts.size, enabled) {
        if (!enabled) {
            controller.clear()
            return@LaunchedEffect
        }
        val maxDurationNanos = 600_000_000L
        while (enabled && controller.bursts.isNotEmpty()) {
            withFrameNanos { now ->
                frameTimeNanos = now
                controller.bursts.removeAll { burst ->
                    (now - burst.startTimeNanos) >= maxDurationNanos
                }
            }
        }
    }

    val reusablePetalPath = remember { Path() }

    Canvas(modifier = modifier.fillMaxSize()) {
        val durationSec = 0.85f
        val gravityPx = 95.dp.toPx()

        for (bIdx in 0 until controller.bursts.size) {
            val burst = controller.bursts[bIdx]
            val elapsedSec = ((frameTimeNanos - burst.startTimeNanos).coerceAtLeast(0L)) / 1_000_000_000f
            val progress = (elapsedSec / durationSec).coerceIn(0f, 1f)
            if (progress >= 1f) continue

            val easeOut = 1f - (1f - progress) * (1f - progress)
            val alpha = (1f - progress * progress).coerceIn(0f, 1f)

            // Draw central blooming element at the touch origin
            val centerScale = (0.35f + easeOut * 0.85f) * (1f - progress * 0.45f)
            val centerRadius = 12.dp.toPx() * centerScale
            drawThemeCentralBurst(
                theme = palette.theme,
                center = Offset(burst.originX, burst.originY),
                radius = centerRadius,
                rotationDeg = progress * 90f,
                primaryColor = primaryColor.copy(alpha = (alpha * 0.85f).coerceIn(0f, 1f)),
                secondaryColor = centerStamenColor.copy(alpha = alpha),
                reusablePath = reusablePetalPath
            )

            // Draw radiating theme particles & blossoms
            val particles = burst.particles
            for (pIdx in 0 until particles.size) {
                val p = particles[pIdx]
                val dist = p.speedPxPerSec * easeOut * durationSec
                val x = burst.originX + cos(p.angleRad) * dist
                val y = burst.originY + sin(p.angleRad) * dist + (gravityPx * progress * progress * 0.55f)
                val rot = p.baseRotationDeg + elapsedSec * p.spinDegPerSec
                val pColor = (if (p.useSecondaryColor) secondaryColor else primaryColor)
                    .copy(alpha = alpha)
                val radiusPx = p.sizeDp.dp.toPx() * (1f - progress * 0.3f)

                if (p.isFullFlower && palette.theme.isSakuraTheme()) {
                    drawFivePetalCherryBlossom(
                        center = Offset(x, y),
                        petalRadius = radiusPx * 0.65f,
                        rotationDeg = rot,
                        petalColor = pColor,
                        centerColor = centerStamenColor.copy(alpha = alpha * 0.9f),
                        reusablePath = reusablePetalPath
                    )
                } else {
                    drawThemeParticleShape(
                        theme = palette.theme,
                        center = Offset(x, y),
                        radius = radiusPx,
                        rotationDegrees = rot,
                        color = pColor,
                        secondaryColor = secondaryColor,
                        reusablePath = reusablePetalPath
                    )
                }
            }
        }
    }
}

internal fun DrawScope.drawThemeCentralBurst(
    theme: com.example.ui.theme.AppTheme,
    center: Offset,
    radius: Float,
    rotationDeg: Float,
    primaryColor: Color,
    secondaryColor: Color,
    reusablePath: Path
) {
    if (radius <= 0.5f) return
    if (theme.isSakuraTheme()) {
        drawFivePetalCherryBlossom(
            center = center,
            petalRadius = radius,
            rotationDeg = rotationDeg,
            petalColor = primaryColor,
            centerColor = secondaryColor,
            reusablePath = reusablePath
        )
    } else {
        drawThemeParticleShape(
            theme = theme,
            center = center,
            radius = radius * 1.35f,
            rotationDegrees = rotationDeg,
            color = primaryColor,
            secondaryColor = secondaryColor,
            reusablePath = reusablePath
        )
    }
}

internal fun DrawScope.drawThemeParticleShape(
    theme: com.example.ui.theme.AppTheme,
    center: Offset,
    radius: Float,
    rotationDegrees: Float,
    color: Color,
    secondaryColor: Color,
    reusablePath: Path
) {
    if (radius <= 0.5f) return
    when {
        theme.isSakuraTheme() -> {
            drawSakuraPetalShape(
                center = center,
                radius = radius,
                rotationDegrees = rotationDegrees,
                color = color,
                reusablePath = reusablePath
            )
        }
        theme == com.example.ui.theme.AppTheme.BERSERK_GUTS -> {
            // Berserk Guts: Burning crimson embers & fiery ash sparks
            rotate(degrees = rotationDegrees, pivot = center) {
                reusablePath.reset()
                val h = radius * 1.5f
                val w = radius * 0.65f
                reusablePath.moveTo(center.x, center.y - h)
                reusablePath.lineTo(center.x + w, center.y)
                reusablePath.lineTo(center.x, center.y + h * 0.7f)
                reusablePath.lineTo(center.x - w, center.y)
                reusablePath.close()
                drawPath(path = reusablePath, color = color)
                drawCircle(
                    color = Color(0xFFFF9E00).copy(alpha = color.alpha),
                    radius = radius * 0.35f,
                    center = center
                )
            }
        }
        theme == com.example.ui.theme.AppTheme.BERSERK_GRIFFITH -> {
            // Berserk Griffith: Celestial white & silver falcon feather
            rotate(degrees = rotationDegrees, pivot = center) {
                reusablePath.reset()
                val len = radius * 1.8f
                val width = radius * 0.55f
                reusablePath.moveTo(center.x, center.y - len)
                reusablePath.cubicTo(
                    center.x + width, center.y - len * 0.5f,
                    center.x + width * 0.9f, center.y + len * 0.3f,
                    center.x, center.y + len
                )
                reusablePath.cubicTo(
                    center.x - width * 0.6f, center.y + len * 0.3f,
                    center.x - width * 0.8f, center.y - len * 0.5f,
                    center.x, center.y - len
                )
                reusablePath.close()
                drawPath(path = reusablePath, color = color)
                drawLine(
                    color = Color.White.copy(alpha = color.alpha * 0.9f),
                    start = Offset(center.x, center.y - len * 0.88f),
                    end = Offset(center.x, center.y + len * 0.92f),
                    strokeWidth = (radius * 0.14f).coerceAtLeast(1f)
                )
            }
        }
        theme == com.example.ui.theme.AppTheme.EVANGELION_01 -> {
            // Evangelion: Hexagonal AT-Field energy barrier & lime core
            rotate(degrees = rotationDegrees, pivot = center) {
                reusablePath.reset()
                val r = radius * 1.15f
                for (step in 0 until 6) {
                    val angle = (step * 60.0 * PI / 180.0).toFloat()
                    val px = center.x + r * cos(angle)
                    val py = center.y + r * sin(angle)
                    if (step == 0) reusablePath.moveTo(px, py) else reusablePath.lineTo(px, py)
                }
                reusablePath.close()
                drawPath(path = reusablePath, color = color.copy(alpha = color.alpha * 0.50f))
                drawPath(
                    path = reusablePath,
                    color = secondaryColor.copy(alpha = color.alpha),
                    style = Stroke(width = (radius * 0.22f).coerceAtLeast(1.5f))
                )
                drawCircle(
                    color = Color(0xFF39FF14).copy(alpha = color.alpha),
                    radius = radius * 0.28f,
                    center = center
                )
            }
        }
        theme == com.example.ui.theme.AppTheme.CHAINSAW_MAN -> {
            // Chainsaw Man: Jagged electric cadmium orange sparks & teeth
            rotate(degrees = rotationDegrees, pivot = center) {
                reusablePath.reset()
                val len = radius * 1.6f
                val w = radius * 0.7f
                reusablePath.moveTo(center.x, center.y - len)
                reusablePath.lineTo(center.x + w, center.y + len * 0.4f)
                reusablePath.lineTo(center.x + w * 0.2f, center.y + len * 0.2f)
                reusablePath.lineTo(center.x, center.y + len)
                reusablePath.lineTo(center.x - w * 0.4f, center.y + len * 0.2f)
                reusablePath.lineTo(center.x - w, center.y - len * 0.2f)
                reusablePath.close()
                drawPath(path = reusablePath, color = color)
                drawCircle(
                    color = Color(0xFFFFEE55).copy(alpha = color.alpha),
                    radius = radius * 0.30f,
                    center = center
                )
            }
        }
        else -> {
            // Cowboy Bebop (Faye / Spike): Retro space cowboy 8-point starlight & gold casino shimmer
            rotate(degrees = rotationDegrees, pivot = center) {
                reusablePath.reset()
                val rOuter = radius * 1.5f
                val rInner = radius * 0.35f
                for (s in 0 until 8) {
                    val r = if (s % 2 == 0) rOuter else rInner
                    val ang = (s * 45.0 * PI / 180.0).toFloat()
                    val px = center.x + r * cos(ang)
                    val py = center.y + r * sin(ang)
                    if (s == 0) reusablePath.moveTo(px, py) else reusablePath.lineTo(px, py)
                }
                reusablePath.close()
                drawPath(path = reusablePath, color = color)
                drawCircle(
                    color = Color(0xFFFFF275).copy(alpha = color.alpha),
                    radius = radius * 0.35f,
                    center = center
                )
            }
        }
    }
}

private fun DrawScope.drawFivePetalCherryBlossom(
    center: Offset,
    petalRadius: Float,
    rotationDeg: Float,
    petalColor: Color,
    centerColor: Color,
    reusablePath: Path
) {
    if (petalRadius <= 0.5f) return
    for (i in 0 until 5) {
        val petalAngle = rotationDeg + i * 72f
        val rad = (petalAngle * PI / 180.0).toFloat()
        val offsetDist = petalRadius * 0.72f
        val petalCenter = Offset(
            x = center.x + cos(rad) * offsetDist,
            y = center.y + sin(rad) * offsetDist
        )
        drawSakuraPetalShape(
            center = petalCenter,
            radius = petalRadius * 0.62f,
            rotationDegrees = petalAngle + 90f,
            color = petalColor,
            reusablePath = reusablePath
        )
    }
    drawCircle(
        color = centerColor,
        radius = petalRadius * 0.22f,
        center = center
    )
}

private fun DrawScope.drawSakuraPetalShape(
    center: Offset,
    radius: Float,
    rotationDegrees: Float,
    color: Color,
    reusablePath: Path
) {
    rotate(degrees = rotationDegrees, pivot = center) {
        reusablePath.reset()
        reusablePath.moveTo(center.x, center.y + radius)
        reusablePath.cubicTo(
            center.x - radius * 0.95f, center.y + radius * 0.3f,
            center.x - radius * 0.85f, center.y - radius * 0.85f,
            center.x - radius * 0.22f, center.y - radius
        )
        reusablePath.lineTo(center.x, center.y - radius * 0.68f)
        reusablePath.lineTo(center.x + radius * 0.22f, center.y - radius)
        reusablePath.cubicTo(
            center.x + radius * 0.85f, center.y - radius * 0.85f,
            center.x + radius * 0.95f, center.y + radius * 0.3f,
            center.x, center.y + radius
        )
        reusablePath.close()
        drawPath(path = reusablePath, color = color)
    }
}
